# Building "Smart Daily Utility Pro" Android APK

This guide provides step-by-step instructions to export **Smart Daily Utility Pro** into a production-ready **Android APK** and **Google Play Android App Bundle (AAB)**.

---

## 📱 Method 0: Generate APK Directly on Your Android Phone (100% Free, No Computer Needed)

You do **NOT** need a laptop or paid software to turn this app into a true standalone `.apk` on your phone!

### Option A: Microsoft PWABuilder (Online Cloud Compiler to .apk)
1. **Get your App URL**:
   - In the app, tap the **Android APK** button in the header or in Settings, then tap **"Copy URL"**.
   - Your hosted app URL is: `https://ais-pre-it7jumymoti7pawxfpo2q2-574845682029.asia-southeast1.run.app` (or your custom domain).
2. **Open PWABuilder in Chrome on your Android phone**:
   - Visit [https://www.pwabuilder.com](https://www.pwabuilder.com).
3. **Analyze your App**:
   - Paste your app URL into the input field and tap **Start** (or **Build My PWA**).
   - PWABuilder automatically inspects the app. The project includes a PWA manifest, service-worker configuration, and maskable icons. You must first deploy the app to a public HTTPS URL; PWABuilder must then validate the live site. A successful validation is not guaranteed until the production build is tested.
4. **Generate the Android APK**:
   - Tap **"Package for Stores"**.
   - Tap **"Android"**.
   - Select **"Generate Package"** (Options allow you to download a standalone debug `.apk` for instant installation or an `.aab` for Google Play).
5. **Download and Install**:
   - A `.zip` containing your compiled `.apk` will download directly into your Android phone's **Downloads** folder.
   - Open your phone's File Manager app, open **Downloads**, extract the file, and tap on the `.apk` file.
   - Tap **Install** (if prompted, allow installation from this source in Android Settings).
   - Done! You now have a standalone, full-screen Android app installed on your phone.

---

### Option B: Google Chrome 1-Tap WebAPK (Zero Tools, Native Android System Package)
Android Chrome includes Google's built-in **WebAPK minting service**:
1. Open your live app URL in **Google Chrome on your Android Phone**.
2. Tap the Chrome three-dot menu icon `⋮` in the top-right corner.
3. Tap **"Install app"** (or **"Add to Home screen"**).
4. Chrome may offer an installable WebAPK/PWA shortcut depending on device and browser support. This is not the same as a standalone APK you can upload to the Play Store.
5. It runs in its own window, full-screen with offline support and camera access.

---

## Method 1: Using Capacitor (Recommended for Native Android App & Google Play)

### Prerequisites
- Node.js (v18+)
- Android Studio installed on your computer with Android SDK & Command Line Tools.

### Steps to Build APK:

1. **Build the production web bundle**:
   ```bash
   npm run build
   ```

2. **Install Capacitor CLI & Android dependencies**:
   ```bash
   npm install @capacitor/core @capacitor/android
   npm install -D @capacitor/cli
   ```

3. **Initialize the Android project** (a pre-configured `capacitor.config.json` is already provided in the root folder):
   ```bash
   npx cap init "Smart Daily Utility Pro" com.smartdailyutility.pro --web-dir dist
   npx cap add android
   ```

4. **Sync the built assets to Android**:
   ```bash
   npx cap sync
   ```

5. **Open in Android Studio**:
   ```bash
   npx cap open android
   ```

6. **Generate the APK or AAB**:
   - In Android Studio, go to **Build** > **Build Bundle(s) / APK(s)** > **Build APK(s)** for a debug/testing APK.
   - For Google Play submission, choose **Build** > **Generate Signed Bundle / APK** > select **Android App Bundle (.aab)**.

---

## Method 2: Google Bubblewrap (Trusted Web Activity CLI)

Bubblewrap uses Google's official open-source tool to wrap this PWA directly into an Android package without needing manual Gradle configuration:

1. **Install Bubblewrap**:
   ```bash
   npm install -g @bubblewrap/cli
   ```

2. **Initialize from your hosted URL or domain**:
   ```bash
   bubblewrap init --manifest https://<your-domain>/manifest.webmanifest
   ```

3. **Compile the release package**:
   ```bash
   bubblewrap build
   ```
   *Output: `app-release-signed.apk` and `app-release-bundle.aab`*

---

## Google AdMob Setup for Production

The source currently contains AdMob test-ID references and visual ad placeholders. These do not mean that the native AdMob SDK is integrated or that ads will render. Do not claim ad revenue or reward users until a real SDK integration is implemented and tested. Test IDs listed below are configuration references only:

- **AdMob App ID**: `ca-app-pub-3940256099942544~3347511713`
- **Banner Ad Unit**: `ca-app-pub-3940256099942544/6300978111`
- **Native Ad Unit**: `ca-app-pub-3940256099942544/2247690483`
- **Rewarded Ad Unit**: `ca-app-pub-3940256099942544/5224354917`

### When releasing to Google Play:
1. Log in to your [Google AdMob Console](https://apps.admob.com).
2. Create an Android app and create corresponding Banner, Native, and Rewarded ad units.
3. Replace the test App ID in `android/app/src/main/AndroidManifest.xml` and `capacitor.config.json`.
4. Replace the test Ad Unit IDs with your live Ad Unit IDs.
