# Smart Daily Utility Pro — audit and first repair pass

## Changes made in this repair pass

1. **Currency converter**
   - Added a refreshable exchange-rate fetch from the public `open.er-api.com` latest-rates endpoint.
   - Shows the provider's update time and an error message when live rates cannot be fetched.
   - Keeps the existing built-in rates as fallback values when offline or when the service fails.
   - Rates are indicative mid-market reference rates and are not guaranteed bank/remittance rates.

2. **Daily reminders**
   - Uses the device's local calendar date rather than UTC date, preventing date shifts in India and other time zones.
   - Adds per-reminder/per-day duplicate suppression.
   - Corrects repeat checks for one-time, daily, weekdays, and weekly reminders.
   - Important limitation: this web implementation checks reminders only while the app/screen is active. Browser timers and web notifications cannot guarantee delivery after the app is closed or the phone kills it. Native scheduled notifications still need a Capacitor Local Notifications integration and Android permission/testing.

3. **AdMob transparency**
   - The old rewarded-video screen was a 5-second visual simulation that granted a reward without showing a real ad. It now clearly identifies itself as a preview and no longer grants a reward.
   - Banner/native placements and the AdMob information panel now disclose that the native SDK is not connected. The displayed AdMob IDs are reference/test IDs only; they do not make ads appear by themselves.
   - Removed the unused AdMob plugin configuration from Capacitor config because no AdMob Capacitor plugin is installed.
   - Live ad serving requires an AdMob account, real app/ad-unit IDs, a compatible native SDK/plugin integration, consent/privacy handling, and testing. No live ad revenue is enabled by this ZIP.

4. **Android packaging preparation**
   - Added Capacitor Core, Android, and CLI dependencies and helper scripts to `package.json`.
   - The Android project directory and APK are still not included. Generate the native project with `npm install`, `npm run build`, `npx cap add android`, and `npx cap sync android` in a supported build environment.

## Not yet verified

- A production Vite build and TypeScript check have **not** completed. Dependency installation timed out in this environment, so it would be misleading to call this ZIP build-tested.
- The APK has not been generated.
- PDF/image tools, QR scanner, calculators, document manager, PWA offline behavior, and all screen flows still need runtime tests on a real Android device.
- Google Play Billing is not integrated. The existing Premium/Pro purchase flow must be treated as a UI/demo flow until real billing is implemented and verified.

## Suggested next test sequence

1. Install dependencies in a build environment (`npm install`).
2. Run `npm run lint` and `npm run build`; fix any reported errors.
3. Test the currency converter online and offline.
4. Test reminders for all repeat modes with the app open; separately implement native scheduled notifications for closed-app delivery.
5. Generate/sync the Capacitor Android project and build a debug APK.
6. Install the debug APK and test every tool on the target Android phone.
