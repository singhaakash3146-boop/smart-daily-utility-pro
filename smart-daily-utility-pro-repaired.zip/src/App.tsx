/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { AndroidStatusBar } from './components/layout/AndroidStatusBar';
import { Header } from './components/layout/Header';
import { BottomNav } from './components/layout/BottomNav';
import { HomeScreen } from './components/home/HomeScreen';
import { AllToolsScreen } from './components/home/AllToolsScreen';
import { DocumentManager } from './components/documents/DocumentManager';
import { SettingsScreen } from './components/settings/SettingsScreen';
import { ToolHost } from './components/tools/ToolHost';
import { AdMobBanner } from './components/ads/AdMobBanner';
import { PremiumModal } from './components/ads/PremiumModal';
import { RewardedAdModal } from './components/ads/RewardedAdModal';
import { AndroidApkGuideModal } from './components/android/AndroidApkGuideModal';
import { AdMobInfoModal } from './components/ads/AdMobInfoModal';
import { OfflineBanner } from './components/pwa/OfflineBanner';

const MainAppContent: React.FC = () => {
  const { activeTab, activeToolId, toast } = useApp();

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col transition-colors selection:bg-blue-600 selection:text-white">
      {/* Android Device Status Bar */}
      <AndroidStatusBar />

      {/* Main Top Header */}
      <Header />

      {/* Offline Toast Banner */}
      <OfflineBanner />

      {/* Primary Scrollable Viewport Canvas */}
      <main className="flex-1 w-full max-w-4xl mx-auto px-4 py-5 sm:py-6">
        {activeToolId ? (
          <ToolHost />
        ) : (
          <>
            {activeTab === 'home' && <HomeScreen />}
            {activeTab === 'tools' && <AllToolsScreen />}
            {activeTab === 'docs' && <DocumentManager />}
            {activeTab === 'settings' && <SettingsScreen />}
          </>
        )}
      </main>

      {/* Sticky Bottom AdMob Banner (Hidden if PRO) */}
      <AdMobBanner />

      {/* Mobile Fixed Ergonomic Bottom Tab Bar */}
      <BottomNav />

      {/* Modals & Dialogs */}
      <PremiumModal />
      <RewardedAdModal />
      <AndroidApkGuideModal />
      <AdMobInfoModal />

      {/* Global Toast Bubble */}
      {toast && (
        <div className="fixed bottom-20 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2 px-4 py-2 rounded-full bg-slate-900/90 dark:bg-slate-100/90 text-white dark:text-slate-900 text-xs font-semibold shadow-xl backdrop-blur-md animate-in fade-in slide-in-from-bottom-2">
          <span>{toast}</span>
        </div>
      )}
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainAppContent />
    </AppProvider>
  );
}
