export type Language = 'en' | 'hi';
export type Theme = 'light' | 'dark';

export type ToolCategory = 'pdf' | 'image' | 'calc' | 'qr' | 'daily' | 'doc';

export interface ToolDefinition {
  id: string;
  titleKey: string;
  descKey: string;
  category: ToolCategory;
  iconName: string;
  badge?: string;
  isPro?: boolean;
}

export interface UserDocument {
  id: string;
  name: string;
  type: 'pdf' | 'image' | 'note' | 'qr' | 'other';
  size: number; // in bytes
  createdAt: number;
  dataUrl?: string; // local preview or data
  tags?: string[];
  category: string;
}

export interface NoteItem {
  id: string;
  title: string;
  content: string;
  color: string;
  pinned: boolean;
  updatedAt: number;
}

export interface SaveNoteInput {
  id?: string;
  title: string;
  content: string;
  color: string;
  pinned: boolean;
}

export interface ReminderItem {
  id: string;
  title: string;
  notes?: string;
  time: string; // HH:mm
  date: string; // YYYY-MM-DD
  category: 'work' | 'personal' | 'health' | 'bills' | 'general';
  repeat: 'none' | 'daily' | 'weekdays' | 'weekly';
  completed: boolean;
  createdAt: number;
}

export interface SaveReminderInput {
  id?: string;
  title: string;
  notes?: string;
  time: string;
  date: string;
  category: 'work' | 'personal' | 'health' | 'bills' | 'general';
  repeat: 'none' | 'daily' | 'weekdays' | 'weekly';
  completed: boolean;
}

export interface AdMobConfig {
  appId: string;
  bannerTestId: string;
  nativeTestId: string;
  rewardedTestId: string;
  interstitialTestId: string;
}
