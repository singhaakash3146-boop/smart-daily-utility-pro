import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { ALL_TOOLS } from '../../data/tools';
import { ToolCard } from './ToolCard';
import { ToolCategory } from '../../types';
import { Search } from 'lucide-react';

export const AllToolsScreen: React.FC = () => {
  const { t } = useApp();
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [query, setQuery] = useState<string>('');

  const categories: { id: string; label: string }[] = [
    { id: 'all', label: 'All Tools (22)' },
    { id: 'pdf', label: 'PDF Tools (4)' },
    { id: 'image', label: 'Image Tools (4)' },
    { id: 'calc', label: 'Calculators (6)' },
    { id: 'qr', label: 'QR Tools (2)' },
    { id: 'daily', label: 'Daily Essentials (5)' },
    { id: 'doc', label: 'Documents (1)' },
  ];

  const tools = ALL_TOOLS.filter(tool => {
    const matchCat = filterCategory === 'all' || tool.category === filterCategory;
    const title = t(tool.titleKey).toLowerCase();
    const desc = t(tool.descKey).toLowerCase();
    const q = query.toLowerCase();
    const matchQuery = !query || title.includes(q) || desc.includes(q);
    return matchCat && matchQuery;
  });

  return (
    <div className="space-y-6 pb-20">
      <div>
        <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">
          {t('navTools')}
        </h3>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
          Browse all utilities by category
        </p>
      </div>

      {/* Search Input */}
      <div className="relative">
        <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
        <input
          type="text"
          value={query}
          onChange={e => setQuery(e.target.value)}
          placeholder="Filter tools..."
          className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-xs focus:ring-2 focus:ring-blue-500"
        />
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
        {categories.map(cat => (
          <button
            key={cat.id}
            onClick={() => setFilterCategory(cat.id)}
            className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition ${
              filterCategory === cat.id
                ? 'bg-blue-600 text-white shadow-sm'
                : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-50'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Tools Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {tools.map(tool => (
          <ToolCard key={tool.id} tool={tool} />
        ))}
      </div>
    </div>
  );
};
