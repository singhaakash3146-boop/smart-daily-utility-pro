import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { ALL_TOOLS } from '../../data/tools';
import { ToolCard } from './ToolCard';
import { AdMobNative } from '../ads/AdMobNative';
import {
  Search,
  Star,
  Clock,
  Sparkles,
  Files,
  Image as ImageIcon,
  Calculator,
  QrCode,
  CalendarCheck,
  FolderArchive,
  ChevronRight,
  Flame,
} from 'lucide-react';

export const HomeScreen: React.FC = () => {
  const {
    favorites,
    recentlyUsed,
    searchQuery,
    setSearchQuery,
    openTool,
    setActiveTab,
    t,
    language,
  } = useApp();

  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  // Search filter
  const isSearching = searchQuery.trim().length > 0;
  const filteredTools = ALL_TOOLS.filter(tool => {
    const title = t(tool.titleKey).toLowerCase();
    const desc = t(tool.descKey).toLowerCase();
    const query = searchQuery.toLowerCase();
    return title.includes(query) || desc.includes(query) || tool.id.includes(query);
  });

  // Favorite tools objects
  const favoriteTools = ALL_TOOLS.filter(t => favorites.includes(t.id));

  // Recent tools objects
  const recentTools = recentlyUsed
    .map(id => ALL_TOOLS.find(t => t.id === id))
    .filter(Boolean) as typeof ALL_TOOLS;

  const categories = [
    { id: 'all', nameKey: 'allCategories', icon: Flame },
    { id: 'pdf', nameKey: 'catPdf', icon: Files },
    { id: 'image', nameKey: 'catImage', icon: ImageIcon },
    { id: 'calc', nameKey: 'catCalc', icon: Calculator },
    { id: 'qr', nameKey: 'catQr', icon: QrCode },
    { id: 'daily', nameKey: 'catDaily', icon: CalendarCheck },
  ];

  return (
    <div className="space-y-6 pb-20">
      {/* Hero Welcome Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-blue-600 via-blue-700 to-indigo-800 text-white p-6 shadow-xl">
        <div className="relative z-10 max-w-md">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-white/15 backdrop-blur-md text-[11px] font-bold tracking-wide uppercase mb-3">
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>Smart Daily Utility Pro</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-extrabold tracking-tight">
            {language === 'hi' ? 'दैनिक जीवन के सभी जरूरी टूल्स' : 'Your Everyday All-in-One Utility Suite'}
          </h2>
          <p className="text-xs text-blue-100 mt-1.5 leading-relaxed">
            {language === 'hi'
              ? 'पीडीएफ, इमेज, ईएमआई, जीएसटी, क्यूआर कोड और दैनिक फाइलों का संपूर्ण समाधान।'
              : 'Fast, secure, offline-first utilities for PDF processing, image tools, finance, and QR.'}
          </p>
        </div>

        {/* Ambient background blur circles */}
        <div className="absolute -right-12 -bottom-12 w-48 h-48 rounded-full bg-indigo-500/30 blur-2xl pointer-events-none" />
      </div>

      {/* Global Quick Search */}
      <div className="relative">
        <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
        <input
          type="text"
          value={searchQuery}
          onChange={e => setSearchQuery(e.target.value)}
          placeholder={t('searchPlaceholder')}
          className="w-full pl-10 pr-4 py-3 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-xs sm:text-sm font-medium text-slate-900 dark:text-slate-100 shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 transition"
        />
        {searchQuery && (
          <button
            onClick={() => setSearchQuery('')}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-semibold text-slate-400 hover:text-slate-600"
          >
            Clear
          </button>
        )}
      </div>

      {/* Search Results Display */}
      {isSearching ? (
        <div className="space-y-3">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>Search Results ({filteredTools.length})</span>
          </div>
          {filteredTools.length === 0 ? (
            <div className="p-8 text-center rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-400 text-xs">
              {t('noToolsFound')}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {filteredTools.map(tool => (
                <ToolCard key={tool.id} tool={tool} />
              ))}
            </div>
          )}
        </div>
      ) : (
        <>
          {/* Quick Categories Bar */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs select-none">
            {categories.map(cat => {
              const Icon = cat.icon;
              const isSelected = selectedCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`inline-flex items-center gap-1.5 px-3 py-2 rounded-xl font-bold transition whitespace-nowrap ${
                    isSelected
                      ? 'bg-blue-600 text-white shadow-sm'
                      : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-50'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{t(cat.nameKey)}</span>
                </button>
              );
            })}
          </div>

          {/* If specific category selected, show its tools directly */}
          {selectedCategory !== 'all' ? (
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs text-slate-500 font-semibold">
                <span>{t(categories.find(c => c.id === selectedCategory)!.nameKey)}</span>
                <button onClick={() => setSelectedCategory('all')} className="text-blue-600 hover:underline">
                  Show All
                </button>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {ALL_TOOLS.filter(t => t.category === selectedCategory).map(tool => (
                  <ToolCard key={tool.id} tool={tool} />
                ))}
              </div>
            </div>
          ) : (
            <>
              {/* Starred / Favorite Tools */}
              {favoriteTools.length > 0 && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-slate-500">
                      <Star className="w-3.5 h-3.5 fill-amber-500 text-amber-500" />
                      <span>{t('favorites')}</span>
                    </div>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {favoriteTools.map(tool => (
                      <ToolCard key={tool.id} tool={tool} />
                    ))}
                  </div>
                </div>
              )}

              {/* Native Ad Placement */}
              <AdMobNative />

              {/* Recently Used Tools */}
              {recentTools.length > 0 && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-slate-500">
                      <Clock className="w-3.5 h-3.5 text-blue-500" />
                      <span>{t('recentlyUsed')}</span>
                    </div>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    {recentTools.slice(0, 4).map(tool => (
                      <ToolCard key={tool.id} tool={tool} compact />
                    ))}
                  </div>
                </div>
              )}

              {/* Tool Suites Overview */}
              <div className="space-y-5 pt-2">
                {/* PDF Suite */}
                <div className="space-y-2.5">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold uppercase tracking-wider text-rose-600 dark:text-rose-400">
                      {t('catPdf')}
                    </span>
                    <button
                      onClick={() => setSelectedCategory('pdf')}
                      className="text-xs text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 flex items-center gap-0.5"
                    >
                      <span>View All</span>
                      <ChevronRight className="w-3 h-3" />
                    </button>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {ALL_TOOLS.filter(t => t.category === 'pdf').map(tool => (
                      <ToolCard key={tool.id} tool={tool} />
                    ))}
                  </div>
                </div>

                {/* Calculators Suite */}
                <div className="space-y-2.5">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">
                      {t('catCalc')}
                    </span>
                    <button
                      onClick={() => setSelectedCategory('calc')}
                      className="text-xs text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 flex items-center gap-0.5"
                    >
                      <span>View All</span>
                      <ChevronRight className="w-3 h-3" />
                    </button>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {ALL_TOOLS.filter(t => t.category === 'calc').slice(0, 4).map(tool => (
                      <ToolCard key={tool.id} tool={tool} />
                    ))}
                  </div>
                </div>

                {/* Image & QR Suites */}
                <div className="space-y-2.5">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
                      {t('catImage')} & {t('catQr')}
                    </span>
                    <button
                      onClick={() => {
                        setActiveTab('tools');
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                      }}
                      className="text-xs text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 flex items-center gap-0.5"
                    >
                      <span>All 20+ Tools</span>
                      <ChevronRight className="w-3 h-3" />
                    </button>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {ALL_TOOLS.filter(t => t.category === 'image' || t.category === 'qr').slice(0, 4).map(tool => (
                      <ToolCard key={tool.id} tool={tool} />
                    ))}
                  </div>
                </div>
              </div>
            </>
          )}
        </>
      )}
    </div>
  );
};
