import React from 'react';
import { ToolDefinition } from '../../types';
import { useApp } from '../../context/AppContext';
import { ToolIcon } from '../common/ToolIcon';
import { Star, ChevronRight } from 'lucide-react';

export const ToolCard: React.FC<{ tool: ToolDefinition; compact?: boolean }> = ({
  tool,
  compact = false,
}) => {
  const { openTool, toggleFavorite, isFavorite, t } = useApp();
  const favorited = isFavorite(tool.id);

  return (
    <div
      onClick={() => openTool(tool.id)}
      className="group relative cursor-pointer rounded-2xl border border-slate-200/90 dark:border-slate-800 bg-white dark:bg-slate-900/90 hover:bg-slate-50 dark:hover:bg-slate-800/80 p-3.5 sm:p-4 shadow-sm hover:shadow-md transition-all active:scale-[0.98] flex items-center justify-between gap-3 text-left"
    >
      <div className="flex items-center gap-3 min-w-0">
        <ToolIcon name={tool.iconName} category={tool.category} />
        <div className="min-w-0">
          <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100 truncate group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
            {t(tool.titleKey)}
          </h4>
          {!compact && (
            <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-1 mt-0.5">
              {t(tool.descKey)}
            </p>
          )}
        </div>
      </div>

      <div className="flex items-center gap-1 shrink-0">
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            toggleFavorite(tool.id);
          }}
          className={`p-2 rounded-lg transition-colors ${
            favorited
              ? 'text-amber-500 hover:text-amber-600'
              : 'text-slate-300 dark:text-slate-600 hover:text-amber-400'
          }`}
          aria-label={favorited ? 'Remove from favorites' : 'Add to favorites'}
        >
          <Star className={`w-4 h-4 ${favorited ? 'fill-amber-500' : ''}`} />
        </button>
        <ChevronRight className="w-4 h-4 text-slate-400 group-hover:translate-x-0.5 transition-transform" />
      </div>
    </div>
  );
};
