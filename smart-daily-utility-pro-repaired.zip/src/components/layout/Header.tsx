import React from 'react';
import { useApp } from '../../context/AppContext';
import { PWAInstallButton } from '../pwa/PWAInstallButton';
import {
  Sun,
  Moon,
  Globe,
  Sparkles,
  Smartphone,
  ChevronLeft,
  Search,
} from 'lucide-react';

export const Header: React.FC = () => {
  const {
    language,
    setLanguage,
    theme,
    toggleTheme,
    isPremium,
    setShowPremiumModal,
    setShowApkModal,
    activeToolId,
    closeTool,
    activeTab,
    setActiveTab,
    t,
  } = useApp();

  return (
    <header className="sticky top-0 z-30 w-full bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 transition-colors">
      <div className="max-w-6xl mx-auto px-4 h-14 flex items-center justify-between gap-4">
        {/* Zone 1: Left Brand or Back Action */}
        <div className="flex items-center gap-2.5 min-w-0 shrink-0">
          {activeToolId ? (
            <button
              onClick={closeTool}
              className="min-h-[40px] min-w-[40px] flex items-center justify-center -ml-2 rounded-xl text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 active:scale-95 transition"
              aria-label="Back to dashboard"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
          ) : null}

          <div
            onClick={() => {
              closeTool();
              setActiveTab('home');
            }}
            className="flex items-center gap-2.5 cursor-pointer select-none"
          >
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-600 text-white flex items-center justify-center font-bold text-sm shadow-sm shrink-0">
              U
            </div>
            <div className="flex flex-col">
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-base tracking-tight text-slate-900 dark:text-slate-100 whitespace-nowrap">
                  DailyUtility
                </span>
                <span className="text-[10px] font-extrabold uppercase tracking-wider px-1.5 py-0.5 rounded-md bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20">
                  PRO
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Zone 2: Desktop Quick Nav Links */}
        <nav className="hidden md:flex items-center gap-6 text-xs font-semibold text-slate-600 dark:text-slate-300">
          <button
            onClick={() => {
              closeTool();
              setActiveTab('home');
            }}
            className={`hover:text-blue-600 dark:hover:text-blue-400 transition-colors ${
              activeTab === 'home' && !activeToolId ? 'text-blue-600 dark:text-blue-400' : ''
            }`}
          >
            {t('navHome')}
          </button>
          <button
            onClick={() => {
              closeTool();
              setActiveTab('tools');
            }}
            className={`hover:text-blue-600 dark:hover:text-blue-400 transition-colors ${
              activeTab === 'tools' ? 'text-blue-600 dark:text-blue-400' : ''
            }`}
          >
            {t('navTools')}
          </button>
          <button
            onClick={() => {
              closeTool();
              setActiveTab('docs');
            }}
            className={`hover:text-blue-600 dark:hover:text-blue-400 transition-colors ${
              activeTab === 'docs' ? 'text-blue-600 dark:text-blue-400' : ''
            }`}
          >
            {t('navDocs')}
          </button>
          <button
            onClick={() => {
              closeTool();
              setActiveTab('settings');
            }}
            className={`hover:text-blue-600 dark:hover:text-blue-400 transition-colors ${
              activeTab === 'settings' ? 'text-blue-600 dark:text-blue-400' : ''
            }`}
          >
            {t('navSettings')}
          </button>
        </nav>

        {/* Zone 3: Actions & Controls */}
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          {/* PWA Install */}
          <PWAInstallButton compact />

          {/* Android APK Build Modal Trigger */}
          <button
            onClick={() => setShowApkModal(true)}
            className="hidden sm:inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 text-slate-700 dark:text-slate-200 text-xs font-semibold transition"
            title="Download Android APK / Packaging steps"
          >
            <Smartphone className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
            <span className="hidden lg:inline">Android APK</span>
          </button>

          {/* Language Toggle */}
          <button
            onClick={() => setLanguage(language === 'en' ? 'hi' : 'en')}
            className="min-h-[36px] px-2 flex items-center gap-1 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-semibold transition"
            title="Switch Language / भाषा बदलें"
          >
            <Globe className="w-3.5 h-3.5 text-blue-500" />
            <span>{language === 'en' ? 'हिन्दी' : 'EN'}</span>
          </button>

          {/* Theme Toggle */}
          <button
            onClick={toggleTheme}
            className="min-h-[36px] min-w-[36px] flex items-center justify-center rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 transition"
            aria-label="Toggle Theme"
          >
            {theme === 'dark' ? (
              <Sun className="w-4 h-4 text-amber-400" />
            ) : (
              <Moon className="w-4 h-4 text-slate-700" />
            )}
          </button>

          {/* Pro Button */}
          {!isPremium ? (
            <button
              onClick={() => setShowPremiumModal(true)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs shadow-sm transition active:scale-95 whitespace-nowrap"
            >
              <Sparkles className="w-3.5 h-3.5 fill-slate-950" />
              <span className="hidden sm:inline">Go Pro</span>
            </button>
          ) : (
            <div className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-600 dark:text-amber-400 text-xs font-bold">
              <span>PRO</span>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
