import React from 'react';
import { useApp } from '../../context/AppContext';
import { Home, Grid, FolderArchive, Settings } from 'lucide-react';

export const BottomNav: React.FC = () => {
  const { activeTab, setActiveTab, activeToolId, closeTool, t } = useApp();

  const handleTabClick = (tab: 'home' | 'tools' | 'docs' | 'settings') => {
    if (activeToolId) {
      closeTool();
    }
    setActiveTab(tab);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 z-30 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 pb-[env(safe-area-inset-bottom)] transition-colors">
      <div className="grid grid-cols-4 items-center h-16 max-w-md mx-auto px-2">
        {/* Home */}
        <button
          onClick={() => handleTabClick('home')}
          className={`flex flex-col items-center justify-center min-h-[48px] py-1 rounded-xl transition-all ${
            activeTab === 'home' && !activeToolId
              ? 'text-blue-600 dark:text-blue-400 font-bold'
              : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
          }`}
        >
          <Home className="w-5 h-5" />
          <span className="text-[10px] tracking-tight mt-1 whitespace-nowrap">
            {t('navHome')}
          </span>
        </button>

        {/* All Tools */}
        <button
          onClick={() => handleTabClick('tools')}
          className={`flex flex-col items-center justify-center min-h-[48px] py-1 rounded-xl transition-all ${
            activeTab === 'tools' || activeToolId
              ? 'text-blue-600 dark:text-blue-400 font-bold'
              : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
          }`}
        >
          <Grid className="w-5 h-5" />
          <span className="text-[10px] tracking-tight mt-1 whitespace-nowrap">
            {t('navTools')}
          </span>
        </button>

        {/* Documents */}
        <button
          onClick={() => handleTabClick('docs')}
          className={`flex flex-col items-center justify-center min-h-[48px] py-1 rounded-xl transition-all ${
            activeTab === 'docs' && !activeToolId
              ? 'text-blue-600 dark:text-blue-400 font-bold'
              : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
          }`}
        >
          <FolderArchive className="w-5 h-5" />
          <span className="text-[10px] tracking-tight mt-1 whitespace-nowrap">
            {t('navDocs')}
          </span>
        </button>

        {/* Settings */}
        <button
          onClick={() => handleTabClick('settings')}
          className={`flex flex-col items-center justify-center min-h-[48px] py-1 rounded-xl transition-all ${
            activeTab === 'settings' && !activeToolId
              ? 'text-blue-600 dark:text-blue-400 font-bold'
              : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
          }`}
        >
          <Settings className="w-5 h-5" />
          <span className="text-[10px] tracking-tight mt-1 whitespace-nowrap">
            {t('navSettings')}
          </span>
        </button>
      </div>
    </nav>
  );
};
