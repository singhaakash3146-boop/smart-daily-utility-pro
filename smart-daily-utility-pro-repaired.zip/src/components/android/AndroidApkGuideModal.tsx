import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { X, Smartphone, Terminal, Copy, Check, Download, Layers, ShieldCheck } from 'lucide-react';

export const AndroidApkGuideModal: React.FC = () => {
  const { showApkModal, setShowApkModal, language } = useApp();
  const [activeTab, setActiveTab] = useState<'phone' | 'capacitor' | 'bubblewrap' | 'manifest'>('phone');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  if (!showApkModal) return null;

  const appUrl = window.location.origin;

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const capacitorConfig = `{
  "appId": "com.smartdailyutility.pro",
  "appName": "Smart Daily Utility Pro",
  "webDir": "dist",
  "bundledWebRuntime": false,
  "plugins": {
    "AdMob": {
      "appId": "ca-app-pub-3940256099942544~3347511713"
    }
  }
}`;

  const androidManifestSnippet = `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.smartdailyutility.pro">

    <!-- Permissions required for camera scanner & document download -->
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.CAMERA" />
    <uses-permission android:name="android.permission.VIBRATE" />
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="Smart Daily Utility Pro"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:theme="@style/AppTheme">

        <!-- Google AdMob App ID -->
        <meta-data
            android:name="com.google.android.gms.ads.APPLICATION_ID"
            android:value="ca-app-pub-3940256099942544~3347511713"/>

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:configChanges="orientation|keyboardHidden|screenSize">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>`;

  const downloadFile = (filename: string, content: string, type: string) => {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in">
      <div className="relative w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl p-6 text-slate-900 dark:text-slate-100">
        <button
          onClick={() => setShowApkModal(false)}
          className="absolute top-4 right-4 p-2 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 text-white flex items-center justify-center shadow-md">
            <Smartphone className="w-7 h-7" />
          </div>
          <div>
            <h3 className="text-xl font-bold">
              {language === 'hi' ? 'एंड्रॉइड APK और Google Play पब्लिशिंग' : 'Build Android APK & Google Play Publishing'}
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {language === 'hi' ? 'स्मार्ट डेली यूटिलिटी प्रो को स्टैंडअलोन APK या AAB में बनाएं' : 'Turn this progressive utility into a production Android APK'}
            </p>
          </div>
        </div>

        {/* Tabs */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl mb-4 text-xs font-semibold">
          <button
            onClick={() => setActiveTab('phone')}
            className={`py-2 px-2.5 rounded-lg transition-all text-center ${
              activeTab === 'phone'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            📱 Phone (Free)
          </button>
          <button
            onClick={() => setActiveTab('capacitor')}
            className={`py-2 px-2.5 rounded-lg transition-all text-center ${
              activeTab === 'capacitor'
                ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Capacitor PC
          </button>
          <button
            onClick={() => setActiveTab('bubblewrap')}
            className={`py-2 px-2.5 rounded-lg transition-all text-center ${
              activeTab === 'bubblewrap'
                ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Google TWA
          </button>
          <button
            onClick={() => setActiveTab('manifest')}
            className={`py-2 px-2.5 rounded-lg transition-all text-center ${
              activeTab === 'manifest'
                ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Manifest.xml
          </button>
        </div>

        {/* Tab 0: Phone Free Generation */}
        {activeTab === 'phone' && (
          <div className="space-y-4 text-xs text-slate-600 dark:text-slate-300">
            {/* Live Hosted URL Bar */}
            <div className="p-3.5 rounded-2xl bg-gradient-to-r from-emerald-500/10 via-teal-500/10 to-blue-500/10 border border-emerald-500/30">
              <span className="text-[11px] font-semibold text-emerald-800 dark:text-emerald-300 block mb-1">
                {language === 'hi' ? 'आपकी लाइव ऐप यूआरएल (APK जनरेटर के लिए)' : 'Your Live App URL (For APK Generation)'}
              </span>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  readOnly
                  value={appUrl}
                  className="flex-1 px-3 py-1.5 rounded-xl bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-200 font-mono text-[11px] select-all"
                />
                <button
                  onClick={() => copyToClipboard(appUrl, 'app-url')}
                  className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs shrink-0 transition"
                >
                  {copiedKey === 'app-url' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedKey === 'app-url' ? (language === 'hi' ? 'कॉपी हुआ!' : 'Copied!') : (language === 'hi' ? 'URL कॉपी करें' : 'Copy URL')}</span>
                </button>
              </div>
            </div>

            {/* Method A: PWABuilder (Downloadable APK) */}
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-2">
                  <span className="w-5 h-5 rounded-full bg-emerald-600 text-white flex items-center justify-center text-[10px]">1</span>
                  {language === 'hi' ? 'विधि 1: PWABuilder से 100% फ्री APK डाउनलोड करें' : 'Method 1: Instant Free APK via PWABuilder (No PC Needed)'}
                </span>
                <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300">
                  Direct .apk File
                </span>
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                {language === 'hi'
                  ? 'माइक्रोसॉफ्ट का आधिकारिक फ्री ओपन-सोर्स क्लाउड बिल्डर आपके लिए फोन में सीधे APK कंपाइल करता है:'
                  : 'Microsoft PWABuilder is an official free cloud builder that compiles your PWA into a true Android APK package:'}
              </p>
              <ol className="list-decimal list-inside space-y-1.5 text-[11px] leading-relaxed text-slate-700 dark:text-slate-300 pl-1">
                <li>
                  {language === 'hi' ? 'ऊपर दिए गए ' : 'Tap '}
                  <strong className="text-emerald-600 dark:text-emerald-400">
                    {language === 'hi' ? '“URL कॉपी करें”' : '“Copy URL”'}
                  </strong>{' '}
                  {language === 'hi' ? 'बटन को दबाएं।' : 'button above.'}
                </li>
                <li>
                  {language === 'hi' ? 'अपने एंड्रॉइड फोन के ब्राउज़र में खोलें: ' : 'Open in your Android Chrome browser: '}
                  <a
                    href="https://www.pwabuilder.com"
                    target="_blank"
                    rel="noreferrer"
                    className="text-blue-600 dark:text-blue-400 font-semibold underline"
                  >
                    pwabuilder.com
                  </a>
                </li>
                <li>
                  {language === 'hi' ? 'URL पेस्ट करें और ' : 'Paste the URL and tap '}
                  <strong>Start / Build My PWA</strong>
                  {language === 'hi' ? ' पर टैप करें। (Manifest व Icons पहले से 100% तैयार हैं)' : ' (Manifest & Icons are 100% verified).'}
                </li>
                <li>
                  {language === 'hi' ? '“Package for Stores” में ' : 'Under “Package for Stores”, select '}
                  <strong>Android</strong>.
                </li>
                <li>
                  {language === 'hi' ? '“Generate Package” पर टैप करें। 60 सेकंड में आपकी ' : 'Tap “Generate Package”. Within 60s your '}
                  <strong className="text-emerald-600 dark:text-emerald-400">.apk</strong>{' '}
                  {language === 'hi' ? 'फ़ाइल आपके फ़ोन के Downloads फ़ोल्डर में आ जाएगी!' : 'package downloads directly to your phone!'}
                </li>
                <li>
                  {language === 'hi' ? 'फ़ाइल मैनेजर में जाकर APK पर टैप करें और Install दबाएं।' : 'Open Downloads, tap the APK, and tap Install.'}
                </li>
              </ol>
            </div>

            {/* Method B: WebAPK 1-Tap Native Install */}
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-2">
                  <span className="w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center text-[10px]">2</span>
                  {language === 'hi' ? 'विधि 2: Chrome 1-टैप सिस्टम WebAPK (शून्य टूल, तुरंत)' : 'Method 2: Google Chrome 1-Tap WebAPK (Zero Tools Needed)'}
                </span>
                <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300">
                  Google Play Minted
                </span>
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                {language === 'hi'
                  ? 'Google Chrome अपने आधिकारिक WebAPK सर्वर से आपके फोन में मूल Android पैकेज बनाता है:'
                  : 'Chrome uses Google’s official WebAPK minting service to install a real native Android package in your system app drawer:'}
              </p>
              <ul className="list-disc list-inside space-y-1.5 text-[11px] leading-relaxed text-slate-700 dark:text-slate-300 pl-1">
                <li>
                  {language === 'hi' ? 'इस ऐप को अपने फोन के ' : 'Open this app in '}
                  <strong>Chrome on Android</strong>.
                </li>
                <li>
                  {language === 'hi' ? 'ऊपर दाएं कोने में 3-डॉट मेनू ' : 'Tap Chrome’s 3 dots menu '}
                  <strong>(⋮)</strong>{' '}
                  {language === 'hi' ? 'पर टैप करें।' : 'at the top right.'}
                </li>
                <li>
                  {language === 'hi' ? '“' : 'Select “'}
                  <strong className="text-blue-600 dark:text-blue-400">
                    {language === 'hi' ? 'ऐप इंस्टॉल करें' : 'Install app'}
                  </strong>{' '}
                  {language === 'hi' ? '” या “होम स्क्रीन में जोड़ें” चुनें।' : '” or “Add to Home screen”.'}
                </li>
                <li>
                  {language === 'hi' ? 'Google Play सेवाएं बैकग्राउंड में असली पैकेज (APK) रजिस्टर करती हैं, जो आपके होम स्क्रीन और ऐप ड्रॉअर में बिना ब्राउज़र बार के फुल स्क्रीन चलता है।' : 'Google Play Services mints an official standalone native package directly into your Android app drawer with full offline & camera access.'}
                </li>
              </ul>
            </div>
          </div>
        )}

        {/* Tab 1: Capacitor */}
        {activeTab === 'capacitor' && (
          <div className="space-y-4 text-xs text-slate-600 dark:text-slate-300">
            <p>
              Capacitor wraps your React + Vite code into a native Android Studio project with full camera, filesystem, and AdMob plugin support:
            </p>

            <div className="p-3 bg-slate-950 text-slate-100 rounded-xl font-mono text-[11px] space-y-1.5 relative">
              <button
                onClick={() =>
                  copyToClipboard(
                    `npm run build\nnpm i -D @capacitor/cli\nnpm i @capacitor/core @capacitor/android\nnpx cap init "Smart Daily Utility Pro" com.smartdailyutility.pro --web-dir dist\nnpx cap add android\nnpx cap open android`,
                    'cap-cmds'
                  )
                }
                className="absolute top-2.5 right-2.5 p-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300"
                title="Copy Commands"
              >
                {copiedKey === 'cap-cmds' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
              <div className="text-slate-500"># 1. Build the production web bundle</div>
              <div className="text-emerald-400">npm run build</div>
              <div className="text-slate-500"># 2. Install Capacitor</div>
              <div className="text-emerald-400">npm i @capacitor/core @capacitor/android</div>
              <div className="text-emerald-400">npm i -D @capacitor/cli</div>
              <div className="text-slate-500"># 3. Initialize & Add Android platform</div>
              <div className="text-emerald-400">npx cap init "Smart Daily Utility Pro" com.smartdailyutility.pro --web-dir dist</div>
              <div className="text-emerald-400">npx cap add android</div>
              <div className="text-slate-500"># 4. Open in Android Studio & Generate Signed APK</div>
              <div className="text-emerald-400">npx cap open android</div>
            </div>

            <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
              <div>
                <span className="font-semibold text-slate-900 dark:text-slate-100 block">capacitor.config.json</span>
                <span className="text-[11px] text-slate-500">Pre-configured with AdMob and bundle settings</span>
              </div>
              <button
                onClick={() => downloadFile('capacitor.config.json', capacitorConfig, 'application/json')}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-medium text-xs shadow-sm"
              >
                <Download className="w-3.5 h-3.5" />
                Download Config
              </button>
            </div>
          </div>
        )}

        {/* Tab 2: Bubblewrap */}
        {activeTab === 'bubblewrap' && (
          <div className="space-y-4 text-xs text-slate-600 dark:text-slate-300">
            <p>
              Google Bubblewrap is the official CLI tool to wrap PWAs directly into Google Play AABs (Android App Bundles) using Trusted Web Activities (TWA):
            </p>
            <div className="p-3 bg-slate-950 text-slate-100 rounded-xl font-mono text-[11px] space-y-1.5 relative">
              <button
                onClick={() =>
                  copyToClipboard(
                    `npm install -g @bubblewrap/cli\nbubblewrap init --manifest https://your-domain.com/manifest.webmanifest\nbubblewrap build`,
                    'bubble-cmds'
                  )
                }
                className="absolute top-2.5 right-2.5 p-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300"
              >
                {copiedKey === 'bubble-cmds' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
              <div className="text-slate-500"># 1. Install Google Bubblewrap CLI</div>
              <div className="text-emerald-400">npm i -g @bubblewrap/cli</div>
              <div className="text-slate-500"># 2. Initialize from PWA Manifest</div>
              <div className="text-emerald-400">bubblewrap init --manifest https://your-domain.com/manifest.webmanifest</div>
              <div className="text-slate-500"># 3. Compile signed release AAB</div>
              <div className="text-emerald-400">bubblewrap build</div>
            </div>
            <p className="text-[11px] text-slate-500">
              Output: Generates `app-release-signed.apk` and `app-release-bundle.aab` ready for upload to the Google Play Developer Console.
            </p>
          </div>
        )}

        {/* Tab 3: Manifest */}
        {activeTab === 'manifest' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold">android/app/src/main/AndroidManifest.xml</span>
              <button
                onClick={() => downloadFile('AndroidManifest.xml', androidManifestSnippet, 'application/xml')}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-medium text-xs"
              >
                <Download className="w-3.5 h-3.5" />
                Download Manifest
              </button>
            </div>
            <pre className="p-3 bg-slate-950 text-slate-200 rounded-xl font-mono text-[10px] overflow-x-auto max-h-56">
              {androidManifestSnippet}
            </pre>
          </div>
        )}

        {/* Footer */}
        <div className="mt-6 pt-4 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <ShieldCheck className="w-4 h-4 text-emerald-500" />
            <span>Google Play Policy & Target SDK 34 Ready</span>
          </div>
          <button
            onClick={() => setShowApkModal(false)}
            className="px-4 py-2 rounded-xl bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 font-semibold text-xs"
          >
            {language === 'hi' ? 'बंद करें' : 'Close'}
          </button>
        </div>
      </div>
    </div>
  );
};
