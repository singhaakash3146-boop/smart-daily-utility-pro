import React from 'react';
import { useApp } from '../../context/AppContext';
import { ALL_TOOLS } from '../../data/tools';
import { ArrowLeft, Star, Share2 } from 'lucide-react';

// PDF Tools
import { ImageToPdf } from './pdf/ImageToPdf';
import { MergePdf } from './pdf/MergePdf';
import { SplitPdf } from './pdf/SplitPdf';
import { CompressPdf } from './pdf/CompressPdf';

// Image Tools
import { ImageCompressor } from './image/ImageCompressor';
import { ImageResizer } from './image/ImageResizer';
import { ImageConverter } from './image/ImageConverter';
import { ImageCropper } from './image/ImageCropper';

// Calculators
import { AgeCalculator } from './calculators/AgeCalculator';
import { EmiCalculator } from './calculators/EmiCalculator';
import { GstCalculator } from './calculators/GstCalculator';
import { DiscountCalculator } from './calculators/DiscountCalculator';
import { PercentageCalculator } from './calculators/PercentageCalculator';
import { ScientificCalculator } from './calculators/ScientificCalculator';

// QR Tools
import { QrScanner } from './qr/QrScanner';
import { QrGenerator } from './qr/QrGenerator';

// Daily Tools
import { NotesManager } from './daily/NotesManager';
import { DailyReminder } from './daily/DailyReminder';
import { UnitConverter } from './daily/UnitConverter';
import { CurrencyConverter } from './daily/CurrencyConverter';
import { PasswordGenerator } from './daily/PasswordGenerator';
import { DocumentManager } from '../documents/DocumentManager';

export const ToolHost: React.FC = () => {
  const { activeToolId, closeTool, isFavorite, toggleFavorite, t, showToast, language } = useApp();

  if (!activeToolId) return null;

  const toolDef = ALL_TOOLS.find(t => t.id === activeToolId);
  const favorited = isFavorite(activeToolId);

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: toolDef ? t(toolDef.titleKey) : 'Smart Daily Utility Pro',
        text: 'Check out this daily utility tool on Smart Daily Utility Pro',
        url: window.location.href,
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(window.location.href);
      showToast(language === 'hi' ? 'लिंक कॉपी हो गया!' : 'App link copied to clipboard!');
    }
  };

  const renderToolComponent = () => {
    switch (activeToolId) {
      // PDF
      case 'image_to_pdf':
        return <ImageToPdf />;
      case 'merge_pdf':
        return <MergePdf />;
      case 'split_pdf':
        return <SplitPdf />;
      case 'compress_pdf':
        return <CompressPdf />;

      // Image
      case 'img_compressor':
        return <ImageCompressor />;
      case 'img_resizer':
        return <ImageResizer />;
      case 'img_converter':
        return <ImageConverter />;
      case 'img_cropper':
        return <ImageCropper />;

      // Calculators
      case 'age_calc':
        return <AgeCalculator />;
      case 'emi_calc':
        return <EmiCalculator />;
      case 'gst_calc':
        return <GstCalculator />;
      case 'discount_calc':
        return <DiscountCalculator />;
      case 'percentage_calc':
        return <PercentageCalculator />;
      case 'scientific_calc':
        return <ScientificCalculator />;

      // QR
      case 'qr_scanner':
        return <QrScanner />;
      case 'qr_generator':
        return <QrGenerator />;

      // Daily
      case 'notes':
        return <NotesManager />;
      case 'reminders':
        return <DailyReminder />;
      case 'unit_converter':
        return <UnitConverter />;
      case 'currency_converter':
        return <CurrencyConverter />;
      case 'password_gen':
        return <PasswordGenerator />;
      case 'doc_manager':
        return <DocumentManager />;

      default:
        return <div>Tool not found</div>;
    }
  };

  return (
    <div className="space-y-4 pb-20">
      {/* Tool Top Action Header Bar */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
        <button
          onClick={closeTool}
          className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-50 transition"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>{t('back')}</span>
        </button>

        <div className="flex items-center gap-1">
          <button
            onClick={() => toggleFavorite(activeToolId)}
            className={`p-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 transition ${
              favorited ? 'text-amber-500' : 'text-slate-400 hover:text-amber-500'
            }`}
            title={favorited ? 'Starred' : 'Add to Starred'}
          >
            <Star className={`w-4 h-4 ${favorited ? 'fill-amber-500' : ''}`} />
          </button>
          <button
            onClick={handleShare}
            className="p-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-500 hover:text-blue-600 transition"
            title="Share Tool"
          >
            <Share2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Render Active Tool */}
      <div className="animate-in fade-in duration-200">
        {renderToolComponent()}
      </div>
    </div>
  );
};
