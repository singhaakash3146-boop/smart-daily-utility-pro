import React, { useCallback, useEffect, useState } from 'react';
import { useApp } from '../../../context/AppContext';
import { ArrowRightLeft, RefreshCw } from 'lucide-react';

interface CurrencyInfo {
  code: string;
  name: string;
  symbol: string;
  rateToUSD: number; // 1 USD = X Currency
}

const CURRENCIES: CurrencyInfo[] = [
  { code: 'INR', name: 'Indian Rupee', symbol: '₹', rateToUSD: 86.85 },
  { code: 'USD', name: 'US Dollar', symbol: '$', rateToUSD: 1.0 },
  { code: 'EUR', name: 'Euro', symbol: '€', rateToUSD: 0.95 },
  { code: 'GBP', name: 'British Pound', symbol: '£', rateToUSD: 0.79 },
  { code: 'AED', name: 'UAE Dirham', symbol: 'د.إ', rateToUSD: 3.67 },
  { code: 'SAR', name: 'Saudi Riyal', symbol: '﷼', rateToUSD: 3.75 },
  { code: 'JPY', name: 'Japanese Yen', symbol: '¥', rateToUSD: 154.2 },
  { code: 'CAD', name: 'Canadian Dollar', symbol: 'CA$', rateToUSD: 1.41 },
  { code: 'AUD', name: 'Australian Dollar', symbol: 'A$', rateToUSD: 1.55 },
  { code: 'SGD', name: 'Singapore Dollar', symbol: 'S$', rateToUSD: 1.34 },
  { code: 'KWD', name: 'Kuwaiti Dinar', symbol: 'KD', rateToUSD: 0.31 },
  { code: 'QAR', name: 'Qatari Riyal', symbol: 'QR', rateToUSD: 3.64 },
  { code: 'CNY', name: 'Chinese Yuan', symbol: '¥', rateToUSD: 7.24 },
  { code: 'CHF', name: 'Swiss Franc', symbol: 'CHF', rateToUSD: 0.89 },
  { code: 'THB', name: 'Thai Baht', symbol: '฿', rateToUSD: 34.5 },
  { code: 'MYR', name: 'Malaysian Ringgit', symbol: 'RM', rateToUSD: 4.45 },
  { code: 'RUB', name: 'Russian Ruble', symbol: '₽', rateToUSD: 98.5 },
  { code: 'BRL', name: 'Brazilian Real', symbol: 'R$', rateToUSD: 5.75 },
  { code: 'ZAR', name: 'South African Rand', symbol: 'R', rateToUSD: 18.2 },
  { code: 'NZD', name: 'New Zealand Dollar', symbol: 'NZ$', rateToUSD: 1.72 },
];

export const CurrencyConverter: React.FC = () => {
  const { t, language } = useApp();
  const [fromCode, setFromCode] = useState<string>('USD');
  const [toCode, setToCode] = useState<string>('INR');
  const [amount, setAmount] = useState<number>(100);
  const [liveRates, setLiveRates] = useState<Record<string, number>>(() => Object.fromEntries(CURRENCIES.map(c => [c.code, c.rateToUSD])));
  const [isLoadingRates, setIsLoadingRates] = useState(false);
  const [rateUpdatedAt, setRateUpdatedAt] = useState<string | null>(null);
  const [rateError, setRateError] = useState<string | null>(null);

  const refreshRates = useCallback(async () => {
    setIsLoadingRates(true);
    setRateError(null);
    try {
      const response = await fetch('https://open.er-api.com/v6/latest/USD', { cache: 'no-store' });
      if (!response.ok) throw new Error(`Exchange rate service returned ${response.status}`);
      const data = await response.json();
      if (data.result !== 'success' || !data.rates || typeof data.rates.INR !== 'number') {
        throw new Error('Exchange rate service returned invalid data');
      }
      setLiveRates(previous => {
        const next = { ...previous };
        for (const currency of CURRENCIES) {
          const value = data.rates[currency.code];
          if (typeof value === 'number' && Number.isFinite(value) && value > 0) next[currency.code] = value;
        }
        return next;
      });
      setRateUpdatedAt(data.time_last_update_utc || new Date().toISOString());
    } catch (error) {
      console.error('Currency rate refresh failed:', error);
      setRateError(language === 'hi' ? 'लाइव रेट नहीं मिल सके। पिछली उपलब्ध दरें दिखाई जा रही हैं।' : 'Live rates unavailable. Showing fallback rates.');
    } finally {
      setIsLoadingRates(false);
    }
  }, [language]);

  useEffect(() => { refreshRates(); }, [refreshRates]);

  const fromCurr = CURRENCIES.find(c => c.code === fromCode) || CURRENCIES[1];
  const toCurr = CURRENCIES.find(c => c.code === toCode) || CURRENCIES[0];

  // Convert amount from `fromCurr` to USD, then from USD to `toCurr`
  const fromRate = liveRates[fromCurr.code] || fromCurr.rateToUSD;
  const toRate = liveRates[toCurr.code] || toCurr.rateToUSD;
  const amountInUSD = amount / fromRate;
  const convertedAmount = amountInUSD * toRate;
  const singleExchangeRate = (1 / fromRate) * toRate;

  const handleSwap = () => {
    const temp = fromCode;
    setFromCode(toCode);
    setToCode(temp);
  };

  const popularTargets = ['INR', 'USD', 'EUR', 'GBP', 'AED', 'CAD'];

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">
          {t('tool_currency_converter')}
        </h3>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
          {t('tool_currency_converter_desc')}
        </p>
      </div>

      <div className="flex items-center justify-between gap-2 text-xs">
        <div className="text-slate-500 dark:text-slate-400">
          {rateUpdatedAt ? (language === 'hi' ? `रेट अपडेट: ${new Date(rateUpdatedAt).toLocaleString()}` : `Rates updated: ${new Date(rateUpdatedAt).toLocaleString()}`) : (language === 'hi' ? 'लाइव रेट लोड हो रहे हैं…' : 'Loading live rates…')}
          {rateError && <p className="text-amber-600 dark:text-amber-400 mt-1">{rateError}</p>}
        </div>
        <button type="button" onClick={refreshRates} disabled={isLoadingRates} className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 disabled:opacity-50">
          <RefreshCw className={`w-3.5 h-3.5 ${isLoadingRates ? 'animate-spin' : ''}`} />
          {language === 'hi' ? 'रेट अपडेट' : 'Refresh'}
        </button>
      </div>

      {/* Main Converter Card */}
      <div className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-4">
        {/* Amount Input */}
        <div>
          <label className="text-xs font-semibold text-slate-500 block mb-1">
            Amount
          </label>
          <div className="relative">
            <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 font-bold font-mono">
              {fromCurr.symbol}
            </span>
            <input
              type="number"
              value={amount || ''}
              onChange={e => setAmount(parseFloat(e.target.value) || 0)}
              className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-mono font-bold text-base focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {/* Quick chips */}
          <div className="flex items-center gap-1.5 mt-2">
            {[50, 100, 500, 1000, 5000].map(val => (
              <button
                key={val}
                type="button"
                onClick={() => setAmount(val)}
                className="px-2.5 py-0.5 rounded-md text-[11px] font-mono bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200"
              >
                {val}
              </button>
            ))}
          </div>
        </div>

        {/* Currency selection row */}
        <div className="grid grid-cols-[1fr,auto,1fr] items-center gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
          <div>
            <label className="text-[11px] text-slate-400 block mb-1">From</label>
            <select
              value={fromCode}
              onChange={e => setFromCode(e.target.value)}
              className="w-full px-2.5 py-2 text-xs font-bold rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100"
            >
              {CURRENCIES.map(c => (
                <option key={c.code} value={c.code}>
                  {c.code} - {c.name}
                </option>
              ))}
            </select>
          </div>

          <button
            onClick={handleSwap}
            className="p-2.5 rounded-full bg-slate-100 dark:bg-slate-800 hover:bg-blue-50 text-slate-600 dark:text-slate-300 hover:text-blue-600 transition mt-4"
            title="Swap Currencies"
          >
            <ArrowRightLeft className="w-4 h-4" />
          </button>

          <div>
            <label className="text-[11px] text-slate-400 block mb-1">To</label>
            <select
              value={toCode}
              onChange={e => setToCode(e.target.value)}
              className="w-full px-2.5 py-2 text-xs font-bold rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100"
            >
              {CURRENCIES.map(c => (
                <option key={c.code} value={c.code}>
                  {c.code} - {c.name}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Converted Result Display */}
      <div className="p-6 rounded-3xl bg-gradient-to-br from-blue-600 to-indigo-700 text-white shadow-xl text-center">
        <span className="text-xs text-blue-200 block mb-1">
          {amount.toLocaleString()} {fromCurr.code} =
        </span>
        <div className="text-3xl sm:text-4xl font-extrabold font-mono tracking-tight">
          {toCurr.symbol} {convertedAmount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
        </div>
        <span className="text-xs text-blue-100 mt-2 block font-mono">
          1 {fromCurr.code} = {singleExchangeRate.toFixed(4)} {toCurr.code}
        </span>
      </div>

      {/* Popular Comparison Matrix */}
      <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
        <span className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-3">
          Popular Exchange Comparison ({fromCurr.code})
        </span>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
          {popularTargets
            .filter(c => c !== fromCurr.code)
            .map(code => {
              const target = CURRENCIES.find(c => c.code === code)!;
              const converted = (amount / fromRate) * (liveRates[target.code] || target.rateToUSD);
              return (
                <div
                  key={code}
                  className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 flex items-center justify-between"
                >
                  <span className="text-xs font-semibold text-slate-500">{code}</span>
                  <span className="text-xs font-bold font-mono text-slate-900 dark:text-slate-100">
                    {target.symbol} {converted.toFixed(2)}
                  </span>
                </div>
              );
            })}
        </div>
      </div>
    </div>
  );
};
