import React, { useState } from 'react';
import { useApp } from '../../../context/AppContext';
import { NoteItem } from '../../../types';
import {
  FileText,
  Plus,
  Pin,
  Trash2,
  Edit2,
  Download,
  Search,
  Check,
  X,
} from 'lucide-react';

export const NotesManager: React.FC = () => {
  const { notes, saveNote, deleteNote, t, language, showToast } = useApp();
  const [search, setSearch] = useState('');
  const [editingNote, setEditingNote] = useState<Partial<NoteItem> | null>(null);

  const colors = [
    { id: 'blue', bg: 'bg-blue-50 dark:bg-blue-950/40 border-blue-200 dark:border-blue-900/60' },
    { id: 'emerald', bg: 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-900/60' },
    { id: 'amber', bg: 'bg-amber-50 dark:bg-amber-950/40 border-amber-200 dark:border-amber-900/60' },
    { id: 'purple', bg: 'bg-purple-50 dark:bg-purple-950/40 border-purple-200 dark:border-purple-900/60' },
    { id: 'rose', bg: 'bg-rose-50 dark:bg-rose-950/40 border-rose-200 dark:border-rose-900/60' },
  ];

  const filteredNotes = notes
    .filter(n =>
      n.title.toLowerCase().includes(search.toLowerCase()) ||
      n.content.toLowerCase().includes(search.toLowerCase())
    )
    .sort((a, b) => (b.pinned ? 1 : 0) - (a.pinned ? 1 : 0) || b.updatedAt - a.updatedAt);

  const handleSave = () => {
    if (!editingNote?.title?.trim() && !editingNote?.content?.trim()) return;
    saveNote({
      id: editingNote.id,
      title: editingNote.title?.trim() || 'Untitled Note',
      content: editingNote.content?.trim() || '',
      color: editingNote.color || 'blue',
      pinned: editingNote.pinned || false,
    });
    setEditingNote(null);
  };

  const exportNote = (n: NoteItem) => {
    const text = `${n.title}\n${'='.repeat(n.title.length)}\n\n${n.content}`;
    const blob = new Blob([text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${n.title.replace(/[^a-z0-9]/gi, '_')}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    showToast(language === 'hi' ? 'नोट डाउनलोड हो गया' : 'Note downloaded as .txt');
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">
            {t('tool_notes')}
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            {t('tool_notes_desc')}
          </p>
        </div>
        <button
          onClick={() =>
            setEditingNote({
              title: '',
              content: '',
              color: 'blue',
              pinned: false,
            })
          }
          className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-sm transition active:scale-95"
        >
          <Plus className="w-4 h-4" />
          <span>New Note</span>
        </button>
      </div>

      {/* Search Bar */}
      <div className="relative">
        <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
        <input
          type="text"
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="Search notes..."
          className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-xs focus:ring-2 focus:ring-blue-500"
        />
      </div>

      {/* Editor Modal */}
      {editingNote && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 shadow-2xl space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-700 dark:text-slate-300">
                {editingNote.id ? 'Edit Note' : 'Create Note'}
              </span>
              <button
                onClick={() => setEditingNote(null)}
                className="p-1 rounded-full text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <input
              type="text"
              value={editingNote.title || ''}
              onChange={e => setEditingNote(prev => ({ ...prev, title: e.target.value }))}
              placeholder="Note title..."
              className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-sm font-bold text-slate-900 dark:text-slate-100"
            />

            <textarea
              rows={6}
              value={editingNote.content || ''}
              onChange={e => setEditingNote(prev => ({ ...prev, content: e.target.value }))}
              placeholder="Write your note here..."
              className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-slate-100 resize-none"
            />

            <div className="flex items-center justify-between pt-2">
              <div className="flex items-center gap-1.5">
                {['blue', 'emerald', 'amber', 'purple', 'rose'].map(c => (
                  <button
                    key={c}
                    type="button"
                    onClick={() => setEditingNote(prev => ({ ...prev, color: c }))}
                    className={`w-6 h-6 rounded-full border-2 transition ${
                      editingNote.color === c ? 'border-slate-900 dark:border-white scale-110' : 'border-transparent'
                    }`}
                    style={{
                      backgroundColor:
                        c === 'blue' ? '#3b82f6' : c === 'emerald' ? '#10b981' : c === 'amber' ? '#f59e0b' : c === 'purple' ? '#a855f7' : '#f43f5e',
                    }}
                  />
                ))}
              </div>

              <button
                type="button"
                onClick={() => setEditingNote(prev => ({ ...prev, pinned: !prev?.pinned }))}
                className={`p-2 rounded-xl text-xs font-semibold flex items-center gap-1 transition ${
                  editingNote.pinned ? 'bg-amber-100 text-amber-700' : 'bg-slate-100 text-slate-600'
                }`}
              >
                <Pin className={`w-3.5 h-3.5 ${editingNote.pinned ? 'fill-amber-600' : ''}`} />
                <span>Pin</span>
              </button>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
              <button
                onClick={() => setEditingNote(null)}
                className="px-3 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100"
              >
                Cancel
              </button>
              <button
                onClick={handleSave}
                className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-sm"
              >
                Save Note
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Notes Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {filteredNotes.length === 0 ? (
          <div className="col-span-2 text-center py-12 text-slate-400 text-xs">
            No notes found. Tap "New Note" to create one.
          </div>
        ) : (
          filteredNotes.map(note => {
            const colorClass =
              colors.find(c => c.id === note.color)?.bg || colors[0].bg;

            return (
              <div
                key={note.id}
                className={`p-4 rounded-2xl border transition-all flex flex-col justify-between ${colorClass}`}
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-1.5">
                    <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100 truncate">
                      {note.title}
                    </h4>
                    {note.pinned && (
                      <Pin className="w-3.5 h-3.5 fill-amber-500 text-amber-500 shrink-0" />
                    )}
                  </div>
                  <p className="text-xs text-slate-600 dark:text-slate-300 whitespace-pre-wrap line-clamp-4">
                    {note.content}
                  </p>
                </div>

                <div className="flex items-center justify-between pt-3 mt-3 border-t border-slate-200/60 dark:border-slate-700/60 text-[11px] text-slate-500">
                  <span>{new Date(note.updatedAt).toLocaleDateString()}</span>
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => setEditingNote(note)}
                      className="p-1.5 rounded-lg hover:bg-white/80 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300"
                      title="Edit"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => exportNote(note)}
                      className="p-1.5 rounded-lg hover:bg-white/80 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300"
                      title="Export Text"
                    >
                      <Download className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => deleteNote(note.id)}
                      className="p-1.5 rounded-lg hover:bg-rose-100 text-rose-500"
                      title="Delete"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
