import React, { useState, useEffect } from 'react';
import { useApp } from '../../../context/AppContext';
import { ReminderItem } from '../../../types';
import {
  Bell,
  Plus,
  Clock,
  Calendar,
  CheckCircle2,
  Circle,
  Trash2,
  X,
  Volume2,
} from 'lucide-react';

export const DailyReminder: React.FC = () => {
  const { reminders, saveReminder, toggleReminder, deleteReminder, t, language, showToast } = useApp();

  const getLocalDateKey = (value: Date) => {
    const year = value.getFullYear();
    const month = String(value.getMonth() + 1).padStart(2, '0');
    const day = String(value.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };
  const [showAddModal, setShowAddModal] = useState<boolean>(false);
  const [title, setTitle] = useState<string>('');
  const [time, setTime] = useState<string>('09:00');
  const [date, setDate] = useState<string>(getLocalDateKey(new Date()));
  const [category, setCategory] = useState<'work' | 'personal' | 'health' | 'bills' | 'general'>('general');
  const [repeat, setRepeat] = useState<'none' | 'daily' | 'weekdays' | 'weekly'>('daily');


  const handleAdd = () => {
    if (!title.trim()) return;
    saveReminder({
      title: title.trim(),
      time,
      date,
      category,
      repeat,
      completed: false,
    });
    setTitle('');
    setShowAddModal(false);

    // Request notification permission if supported
    if ('Notification' in window && Notification.permission !== 'granted') {
      Notification.requestPermission();
    }
  };

  // Checks while this screen/app is active. Browser timers cannot guarantee
  // delivery after the app is closed; native scheduled notifications need a plugin.
  useEffect(() => {
    const checkReminders = () => {
      const now = new Date();
      const todayStr = getLocalDateKey(now);
      const currentTimeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
      const weekday = now.getDay();

      reminders.forEach(r => {
        if (r.completed || r.time !== currentTimeStr) return;
        const isDue = r.repeat === 'daily'
          ? r.date <= todayStr
          : r.repeat === 'weekdays'
            ? weekday >= 1 && weekday <= 5 && (r.date <= todayStr)
            : r.repeat === 'weekly'
              ? r.date <= todayStr && new Date(`${r.date}T12:00:00`).getDay() === weekday
              : r.date === todayStr;
        if (!isDue) return;

        const firedKey = `sdup-reminder-fired:${r.id}:${todayStr}:${currentTimeStr}`;
        try {
          if (window.localStorage.getItem(firedKey) === '1') return;
          window.localStorage.setItem(firedKey, '1');
        } catch { /* Continue for this session if storage is unavailable. */ }

        showToast(`🔔 Reminder: ${r.title}`);
        if ('Notification' in window && Notification.permission === 'granted') {
          new Notification('Smart Daily Utility Pro', { body: r.title, icon: '/icon.svg' });
        }
      });
    };

    checkReminders();
    const checkInterval = window.setInterval(checkReminders, 15000);
    return () => window.clearInterval(checkInterval);
  }, [reminders, showToast]);

  const playChime = () => {
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.type = 'sine';
      osc.frequency.setValueAtTime(587.33, audioCtx.currentTime); // D5
      osc.frequency.setValueAtTime(880, audioCtx.currentTime + 0.15); // A5
      gain.gain.setValueAtTime(0.3, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.6);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.6);
      showToast(language === 'hi' ? 'टेस्ट रिमाइंडर ध्वनि बजाई गई' : 'Played chime preview');
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">
            {t('tool_reminders')}
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            {t('tool_reminders_desc')}
          </p>
        </div>
        <div className="flex items-center gap-1.5">
          <button
            onClick={playChime}
            className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200"
            title="Preview Sound Chime"
          >
            <Volume2 className="w-4 h-4" />
          </button>
          <button
            onClick={() => setShowAddModal(true)}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-sm transition active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>Add Alert</span>
          </button>
        </div>
      </div>

      {/* Add Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 shadow-2xl space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-700 dark:text-slate-300">
                New Daily Reminder
              </span>
              <button
                onClick={() => setShowAddModal(false)}
                className="p-1 rounded-full text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <input
              type="text"
              value={title}
              onChange={e => setTitle(e.target.value)}
              placeholder="e.g. Drink water, Drink medicine, Pay electricity bill"
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-semibold text-slate-900 dark:text-slate-100"
            />

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[11px] text-slate-500 block mb-1">Time</label>
                <input
                  type="time"
                  value={time}
                  onChange={e => setTime(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-mono"
                />
              </div>
              <div>
                <label className="text-[11px] text-slate-500 block mb-1">Date</label>
                <input
                  type="date"
                  value={date}
                  onChange={e => setDate(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-mono"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[11px] text-slate-500 block mb-1">Category</label>
                <select
                  value={category}
                  onChange={e => setCategory(e.target.value as any)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                >
                  <option value="general">General</option>
                  <option value="health">Health & Meds</option>
                  <option value="work">Work & Tasks</option>
                  <option value="bills">Bills & Payments</option>
                  <option value="personal">Personal</option>
                </select>
              </div>
              <div>
                <label className="text-[11px] text-slate-500 block mb-1">Repeat</label>
                <select
                  value={repeat}
                  onChange={e => setRepeat(e.target.value as any)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                >
                  <option value="none">One-time</option>
                  <option value="daily">Daily</option>
                  <option value="weekdays">Mon - Fri</option>
                  <option value="weekly">Weekly</option>
                </select>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
              <button
                onClick={() => setShowAddModal(false)}
                className="px-3 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100"
              >
                Cancel
              </button>
              <button
                onClick={handleAdd}
                className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-sm"
              >
                Save Reminder
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Reminders List */}
      <div className="space-y-2">
        {reminders.length === 0 ? (
          <div className="text-center py-12 text-slate-400 text-xs">
            No reminders scheduled. Tap "+ Add Alert" above.
          </div>
        ) : (
          reminders.map(rem => (
            <div
              key={rem.id}
              className={`p-3.5 rounded-2xl border transition-all flex items-center justify-between gap-3 ${
                rem.completed
                  ? 'bg-slate-100 dark:bg-slate-900 border-slate-200 dark:border-slate-800 opacity-60'
                  : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 shadow-sm'
              }`}
            >
              <div className="flex items-center gap-3 min-w-0">
                <button
                  onClick={() => toggleReminder(rem.id)}
                  className="text-blue-600 dark:text-blue-400 shrink-0"
                >
                  {rem.completed ? (
                    <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                  ) : (
                    <Circle className="w-5 h-5 text-slate-300 hover:text-blue-500" />
                  )}
                </button>
                <div className="min-w-0">
                  <span
                    className={`text-xs font-bold block truncate ${
                      rem.completed ? 'line-through text-slate-400' : 'text-slate-900 dark:text-slate-100'
                    }`}
                  >
                    {rem.title}
                  </span>
                  <div className="flex items-center gap-2 text-[10px] text-slate-400 mt-0.5">
                    <span className="font-mono text-blue-600 dark:text-blue-400 font-bold">
                      {rem.time}
                    </span>
                    <span>·</span>
                    <span className="capitalize">{rem.repeat}</span>
                    <span>·</span>
                    <span className="capitalize">{rem.category}</span>
                  </div>
                </div>
              </div>

              <button
                onClick={() => deleteReminder(rem.id)}
                className="p-1.5 rounded-lg text-slate-300 hover:text-rose-500 transition"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
