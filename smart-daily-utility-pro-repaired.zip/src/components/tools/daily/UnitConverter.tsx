import React, { useState } from 'react';
import { useApp } from '../../../context/AppContext';
import { Ruler, ArrowRightLeft } from 'lucide-react';

type UnitCategory = 'length' | 'weight' | 'temp' | 'area' | 'speed' | 'data';

interface UnitDef {
  id: string;
  label: string;
  toBase: (val: number) => number;
  fromBase: (val: number) => number;
}

const UNITS: Record<UnitCategory, { name: string; units: UnitDef[] }> = {
  length: {
    name: 'Length',
    units: [
      { id: 'm', label: 'Meters (m)', toBase: v => v, fromBase: v => v },
      { id: 'km', label: 'Kilometers (km)', toBase: v => v * 1000, fromBase: v => v / 1000 },
      { id: 'cm', label: 'Centimeters (cm)', toBase: v => v / 100, fromBase: v => v * 100 },
      { id: 'mm', label: 'Millimeters (mm)', toBase: v => v / 1000, fromBase: v => v * 1000 },
      { id: 'mi', label: 'Miles (mi)', toBase: v => v * 1609.34, fromBase: v => v / 1609.34 },
      { id: 'yd', label: 'Yards (yd)', toBase: v => v * 0.9144, fromBase: v => v / 0.9144 },
      { id: 'ft', label: 'Feet (ft)', toBase: v => v * 0.3048, fromBase: v => v / 0.3048 },
      { id: 'in', label: 'Inches (in)', toBase: v => v * 0.0254, fromBase: v => v / 0.0254 },
    ],
  },
  weight: {
    name: 'Weight / Mass',
    units: [
      { id: 'kg', label: 'Kilograms (kg)', toBase: v => v, fromBase: v => v },
      { id: 'g', label: 'Grams (g)', toBase: v => v / 1000, fromBase: v => v * 1000 },
      { id: 'mg', label: 'Milligrams (mg)', toBase: v => v / 1e6, fromBase: v => v * 1e6 },
      { id: 'lb', label: 'Pounds (lbs)', toBase: v => v * 0.453592, fromBase: v => v / 0.453592 },
      { id: 'oz', label: 'Ounces (oz)', toBase: v => v * 0.0283495, fromBase: v => v / 0.0283495 },
      { id: 'ton', label: 'Metric Ton (t)', toBase: v => v * 1000, fromBase: v => v / 1000 },
    ],
  },
  temp: {
    name: 'Temperature',
    units: [
      { id: 'c', label: 'Celsius (°C)', toBase: v => v, fromBase: v => v },
      { id: 'f', label: 'Fahrenheit (°F)', toBase: v => (v - 32) * (5 / 9), fromBase: v => (v * 9) / 5 + 32 },
      { id: 'k', label: 'Kelvin (K)', toBase: v => v - 273.15, fromBase: v => v + 273.15 },
    ],
  },
  area: {
    name: 'Area',
    units: [
      { id: 'sqm', label: 'Square Meters (m²)', toBase: v => v, fromBase: v => v },
      { id: 'sqkm', label: 'Square Kilometers (km²)', toBase: v => v * 1e6, fromBase: v => v / 1e6 },
      { id: 'sqft', label: 'Square Feet (ft²)', toBase: v => v * 0.092903, fromBase: v => v / 0.092903 },
      { id: 'acre', label: 'Acres', toBase: v => v * 4046.86, fromBase: v => v / 4046.86 },
      { id: 'hectare', label: 'Hectares', toBase: v => v * 10000, fromBase: v => v / 10000 },
      { id: 'gaj', label: 'Gaj (Square Yard)', toBase: v => v * 0.836127, fromBase: v => v / 0.836127 },
    ],
  },
  speed: {
    name: 'Speed',
    units: [
      { id: 'kmh', label: 'km/h', toBase: v => v, fromBase: v => v },
      { id: 'mph', label: 'Miles per hour (mph)', toBase: v => v * 1.60934, fromBase: v => v / 1.60934 },
      { id: 'ms', label: 'Meters per sec (m/s)', toBase: v => v * 3.6, fromBase: v => v / 3.6 },
      { id: 'knot', label: 'Knots (kt)', toBase: v => v * 1.852, fromBase: v => v / 1.852 },
    ],
  },
  data: {
    name: 'Data Storage',
    units: [
      { id: 'mb', label: 'Megabytes (MB)', toBase: v => v, fromBase: v => v },
      { id: 'kb', label: 'Kilobytes (KB)', toBase: v => v / 1024, fromBase: v => v * 1024 },
      { id: 'gb', label: 'Gigabytes (GB)', toBase: v => v * 1024, fromBase: v => v / 1024 },
      { id: 'tb', label: 'Terabytes (TB)', toBase: v => v * 1048576, fromBase: v => v / 1048576 },
      { id: 'byte', label: 'Bytes (B)', toBase: v => v / 1048576, fromBase: v => v * 1048576 },
    ],
  },
};

export const UnitConverter: React.FC = () => {
  const { t, language } = useApp();
  const [category, setCategory] = useState<UnitCategory>('length');
  const [fromUnitId, setFromUnitId] = useState<string>('km');
  const [toUnitId, setToUnitId] = useState<string>('m');
  const [inputValue, setInputValue] = useState<number>(1);

  const currentCategory = UNITS[category];
  const fromUnit = currentCategory.units.find(u => u.id === fromUnitId) || currentCategory.units[0];
  const toUnit = currentCategory.units.find(u => u.id === toUnitId) || currentCategory.units[1];

  const handleCategoryChange = (cat: UnitCategory) => {
    setCategory(cat);
    setFromUnitId(UNITS[cat].units[0].id);
    setToUnitId(UNITS[cat].units[1]?.id || UNITS[cat].units[0].id);
  };

  const swapUnits = () => {
    const temp = fromUnitId;
    setFromUnitId(toUnitId);
    setToUnitId(temp);
  };

  // Conversion: input -> base -> output
  const baseValue = fromUnit.toBase(inputValue);
  const outputValue = toUnit.fromBase(baseValue);
  const formattedOutput = Number.isFinite(outputValue)
    ? Math.abs(outputValue) < 0.0001
      ? outputValue.toExponential(4)
      : Math.round(outputValue * 1000000) / 1000000
    : 0;

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">
          {t('tool_unit_converter')}
        </h3>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
          {t('tool_unit_converter_desc')}
        </p>
      </div>

      {/* Category Pills */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
        {(Object.keys(UNITS) as UnitCategory[]).map(catKey => (
          <button
            key={catKey}
            onClick={() => handleCategoryChange(catKey)}
            className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition ${
              category === catKey
                ? 'bg-blue-600 text-white shadow-sm'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200'
            }`}
          >
            {UNITS[catKey].name}
          </button>
        ))}
      </div>

      {/* Conversion Card */}
      <div className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-4">
        {/* From */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-slate-500">From</label>
          <div className="grid grid-cols-[1fr,1.2fr] gap-2">
            <input
              type="number"
              value={inputValue || ''}
              onChange={e => setInputValue(parseFloat(e.target.value) || 0)}
              className="px-3 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-mono font-bold text-base text-slate-900 dark:text-slate-100"
            />
            <select
              value={fromUnitId}
              onChange={e => setFromUnitId(e.target.value)}
              className="px-3 py-2 text-xs font-semibold rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-200"
            >
              {currentCategory.units.map(u => (
                <option key={u.id} value={u.id}>
                  {u.label}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Swap Button */}
        <div className="flex justify-center -my-1">
          <button
            onClick={swapUnits}
            className="p-2.5 rounded-full bg-slate-100 dark:bg-slate-800 hover:bg-blue-50 text-slate-600 dark:text-slate-300 hover:text-blue-600 transition shadow-sm border border-slate-200 dark:border-slate-700"
            title="Swap Units"
          >
            <ArrowRightLeft className="w-4 h-4" />
          </button>
        </div>

        {/* To */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-slate-500">To</label>
          <div className="grid grid-cols-[1fr,1.2fr] gap-2">
            <div className="px-3 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-mono font-bold text-base text-blue-600 dark:text-blue-400 overflow-x-auto truncate">
              {formattedOutput}
            </div>
            <select
              value={toUnitId}
              onChange={e => setToUnitId(e.target.value)}
              className="px-3 py-2 text-xs font-semibold rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-200"
            >
              {currentCategory.units.map(u => (
                <option key={u.id} value={u.id}>
                  {u.label}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Summary Banner */}
      <div className="p-4 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 text-white text-center shadow-md">
        <span className="text-xs text-blue-200 block mb-0.5">Live Equivalent</span>
        <div className="text-xl font-mono font-bold tracking-tight">
          {inputValue} {fromUnit.label} = {formattedOutput} {toUnit.label}
        </div>
      </div>
    </div>
  );
};
