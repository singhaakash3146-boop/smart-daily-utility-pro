import React, { useState, useEffect } from 'react';
import { useApp } from '../../../context/AppContext';
import { KeyRound, Copy, RefreshCw, Check, ShieldCheck, ShieldAlert } from 'lucide-react';

export const PasswordGenerator: React.FC = () => {
  const { t, language, showToast } = useApp();
  const [length, setLength] = useState<number>(16);
  const [includeUpper, setIncludeUpper] = useState<boolean>(true);
  const [includeLower, setIncludeLower] = useState<boolean>(true);
  const [includeNumbers, setIncludeNumbers] = useState<boolean>(true);
  const [includeSymbols, setIncludeSymbols] = useState<boolean>(true);
  const [mode, setMode] = useState<'random' | 'passphrase'>('random');
  const [password, setPassword] = useState<string>('');
  const [copied, setCopied] = useState<boolean>(false);

  const sampleWords = [
    'Solar', 'Falcon', 'Orbit', 'Summit', 'Quartz', 'Echo', 'Tiger', 'Vortex',
    'Breeze', 'Timber', 'Shadow', 'Apex', 'Silver', 'Pulse', 'Haven', 'Glacier',
    'Anchor', 'Beacon', 'Cosmos', 'Marvel', 'Zenith', 'Cedar', 'Cobalt', 'Rhythm'
  ];

  const generatePassword = () => {
    if (mode === 'passphrase') {
      const w1 = sampleWords[Math.floor(Math.random() * sampleWords.length)];
      const w2 = sampleWords[Math.floor(Math.random() * sampleWords.length)];
      const w3 = sampleWords[Math.floor(Math.random() * sampleWords.length)];
      const num = Math.floor(Math.random() * 90 + 10);
      setPassword(`${w1}-${w2}-${w3}-${num}`);
      return;
    }

    let chars = '';
    if (includeUpper) chars += 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    if (includeLower) chars += 'abcdefghijklmnopqrstuvwxyz';
    if (includeNumbers) chars += '0123456789';
    if (includeSymbols) chars += '!@#$%^&*()_+~|}{[]:;?><,.-=';

    if (!chars) chars = 'abcdefghijklmnopqrstuvwxyz';

    let res = '';
    const array = new Uint32Array(length);
    window.crypto.getRandomValues(array);
    for (let i = 0; i < length; i++) {
      res += chars[array[i] % chars.length];
    }
    setPassword(res);
  };

  useEffect(() => {
    generatePassword();
  }, [length, includeUpper, includeLower, includeNumbers, includeSymbols, mode]);

  const copyPassword = () => {
    navigator.clipboard.writeText(password);
    setCopied(true);
    showToast(t('copied'));
    setTimeout(() => setCopied(false), 2000);
  };

  const getStrength = () => {
    if (mode === 'passphrase') return { label: 'Very Strong', color: 'bg-emerald-500', width: '90%' };
    let score = 0;
    if (length >= 12) score += 1;
    if (length >= 16) score += 1;
    if (includeUpper && includeLower) score += 1;
    if (includeNumbers) score += 1;
    if (includeSymbols) score += 1;

    if (score <= 2) return { label: 'Weak', color: 'bg-rose-500', width: '25%' };
    if (score === 3) return { label: 'Fair', color: 'bg-amber-500', width: '50%' };
    if (score === 4) return { label: 'Strong', color: 'bg-blue-500', width: '75%' };
    return { label: 'Very Strong', color: 'bg-emerald-500', width: '100%' };
  };

  const strength = getStrength();

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">
          {t('tool_password_gen')}
        </h3>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
          {t('tool_password_gen_desc')}
        </p>
      </div>

      {/* Generated Password Box */}
      <div className="p-5 rounded-3xl bg-slate-900 text-white border border-slate-800 shadow-xl space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">
            Generated Secure Key
          </span>
          <button
            onClick={generatePassword}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
            title="Generate New"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>

        <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 font-mono text-sm sm:text-base font-bold break-all select-all text-emerald-400 min-h-[52px] flex items-center justify-between gap-2">
          <span>{password}</span>
          <button
            onClick={copyPassword}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white transition shrink-0"
            title="Copy Password"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
          </button>
        </div>

        {/* Strength Meter */}
        <div className="space-y-1.5 pt-1">
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400">Security Rating</span>
            <span className="font-bold text-slate-200">{strength.label}</span>
          </div>
          <div className="w-full h-1.5 rounded-full bg-slate-800 overflow-hidden">
            <div
              className={`h-full ${strength.color} transition-all duration-300`}
              style={{ width: strength.width }}
            />
          </div>
        </div>
      </div>

      {/* Configuration */}
      <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-4">
        {/* Mode switcher */}
        <div className="flex rounded-xl bg-slate-100 dark:bg-slate-800 p-1 text-xs font-semibold">
          <button
            type="button"
            onClick={() => setMode('random')}
            className={`flex-1 py-1.5 rounded-lg transition ${
              mode === 'random' ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-sm' : 'text-slate-600'
            }`}
          >
            Custom Characters
          </button>
          <button
            type="button"
            onClick={() => setMode('passphrase')}
            className={`flex-1 py-1.5 rounded-lg transition ${
              mode === 'passphrase' ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-sm' : 'text-slate-600'
            }`}
          >
            Memorable Passphrase
          </button>
        </div>

        {mode === 'random' && (
          <>
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Password Length
                </label>
                <span className="text-xs font-bold font-mono text-blue-600 dark:text-blue-400">
                  {length} characters
                </span>
              </div>
              <input
                type="range"
                min="6"
                max="32"
                value={length}
                onChange={e => setLength(parseInt(e.target.value, 10))}
                className="w-full accent-blue-600"
              />
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs font-medium">
              <label className="flex items-center gap-2 p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 cursor-pointer">
                <input
                  type="checkbox"
                  checked={includeUpper}
                  onChange={e => setIncludeUpper(e.target.checked)}
                  className="rounded text-blue-600"
                />
                <span>Uppercase (A-Z)</span>
              </label>

              <label className="flex items-center gap-2 p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 cursor-pointer">
                <input
                  type="checkbox"
                  checked={includeLower}
                  onChange={e => setIncludeLower(e.target.checked)}
                  className="rounded text-blue-600"
                />
                <span>Lowercase (a-z)</span>
              </label>

              <label className="flex items-center gap-2 p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 cursor-pointer">
                <input
                  type="checkbox"
                  checked={includeNumbers}
                  onChange={e => setIncludeNumbers(e.target.checked)}
                  className="rounded text-blue-600"
                />
                <span>Numbers (0-9)</span>
              </label>

              <label className="flex items-center gap-2 p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 cursor-pointer">
                <input
                  type="checkbox"
                  checked={includeSymbols}
                  onChange={e => setIncludeSymbols(e.target.checked)}
                  className="rounded text-blue-600"
                />
                <span>Symbols (!@#$)</span>
              </label>
            </div>
          </>
        )}

        {mode === 'passphrase' && (
          <p className="text-xs text-slate-500 leading-relaxed">
            Passphrases use easy-to-remember dictionary words combined with separators and numbers. Recommended for master passwords and encryption keys.
          </p>
        )}
      </div>
    </div>
  );
};
