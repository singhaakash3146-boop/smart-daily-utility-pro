import React, { useState } from 'react';
import { useApp } from '../../../context/AppContext';
import { Landmark, PieChart, Table } from 'lucide-react';

export const EmiCalculator: React.FC = () => {
  const { t, language } = useApp();
  const [loanAmount, setLoanAmount] = useState<number>(500000);
  const [interestRate, setInterestRate] = useState<number>(8.5);
  const [tenureYears, setTenureYears] = useState<number>(5);
  const [tenureType, setTenureType] = useState<'years' | 'months'>('years');
  const [showSchedule, setShowSchedule] = useState<boolean>(false);

  // EMI formula: P * r * (1 + r)^n / ((1 + r)^n - 1)
  const calculateEMI = () => {
    const P = loanAmount;
    const annualRate = interestRate;
    const monthlyRate = annualRate / (12 * 100);
    const totalMonths = tenureType === 'years' ? tenureYears * 12 : tenureYears;

    if (P <= 0 || monthlyRate <= 0 || totalMonths <= 0) return null;

    const emi =
      (P * monthlyRate * Math.pow(1 + monthlyRate, totalMonths)) /
      (Math.pow(1 + monthlyRate, totalMonths) - 1);

    const totalPayment = emi * totalMonths;
    const totalInterest = totalPayment - P;

    // Build yearly breakdown
    const schedule = [];
    let balance = P;
    const totalYears = Math.ceil(totalMonths / 12);

    for (let yr = 1; yr <= totalYears; yr++) {
      let yearlyInterest = 0;
      let yearlyPrincipal = 0;

      for (let m = 1; m <= 12; m++) {
        const monthNum = (yr - 1) * 12 + m;
        if (monthNum > totalMonths) break;
        const interestForMonth = balance * monthlyRate;
        const principalForMonth = emi - interestForMonth;
        yearlyInterest += interestForMonth;
        yearlyPrincipal += principalForMonth;
        balance = Math.max(0, balance - principalForMonth);
      }

      schedule.push({
        year: yr,
        principal: yearlyPrincipal,
        interest: yearlyInterest,
        total: yearlyPrincipal + yearlyInterest,
        balance,
      });
    }

    return {
      monthlyEmi: Math.round(emi),
      totalInterest: Math.round(totalInterest),
      totalPayment: Math.round(totalPayment),
      principalRatio: Math.round((P / totalPayment) * 100),
      interestRatio: Math.round((totalInterest / totalPayment) * 100),
      schedule,
    };
  };

  const results = calculateEMI();

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">
          {t('tool_emi_calc')}
        </h3>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
          {t('tool_emi_calc_desc')}
        </p>
      </div>

      {/* Input Sliders & Fields */}
      <div className="space-y-4 p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
        {/* Loan Amount */}
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
              {language === 'hi' ? 'लोन राशि (Loan Amount)' : 'Loan Amount'}
            </label>
            <div className="relative w-36">
              <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400">₹</span>
              <input
                type="number"
                min="1000"
                max="50000000"
                value={loanAmount}
                onChange={e => setLoanAmount(Math.max(0, parseInt(e.target.value, 10) || 0))}
                className="w-full pl-6 pr-2 py-1 text-xs font-bold font-mono text-right rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-blue-600 dark:text-blue-400 focus:ring-1 focus:ring-blue-500"
              />
            </div>
          </div>
          <input
            type="range"
            min="10000"
            max="10000000"
            step="10000"
            value={loanAmount}
            onChange={e => setLoanAmount(parseInt(e.target.value, 10))}
            className="w-full accent-blue-600 mb-1"
          />
        </div>

        {/* Interest Rate */}
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
              {language === 'hi' ? 'ब्याज दर (% प्रति वर्ष)' : 'Interest Rate (% p.a.)'}
            </label>
            <div className="relative w-24">
              <input
                type="number"
                min="0.1"
                max="35"
                step="0.1"
                value={interestRate}
                onChange={e => setInterestRate(Math.max(0, parseFloat(e.target.value) || 0))}
                className="w-full pl-2 pr-6 py-1 text-xs font-bold font-mono text-right rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-blue-600 dark:text-blue-400 focus:ring-1 focus:ring-blue-500"
              />
              <span className="absolute right-2.5 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400">%</span>
            </div>
          </div>
          <input
            type="range"
            min="1"
            max="25"
            step="0.1"
            value={interestRate}
            onChange={e => setInterestRate(parseFloat(e.target.value))}
            className="w-full accent-blue-600 mb-1"
          />
        </div>

        {/* Tenure */}
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
              {language === 'hi' ? 'लोन अवधि (Tenure)' : 'Loan Tenure'}
            </label>
            <div className="flex gap-1 text-xs">
              <button
                type="button"
                onClick={() => setTenureType('years')}
                className={`px-2 py-0.5 rounded-md font-medium transition ${
                  tenureType === 'years'
                    ? 'bg-blue-600 text-white'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600'
                }`}
              >
                Years
              </button>
              <button
                type="button"
                onClick={() => setTenureType('months')}
                className={`px-2 py-0.5 rounded-md font-medium transition ${
                  tenureType === 'months'
                    ? 'bg-blue-600 text-white'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600'
                }`}
              >
                Months
              </button>
            </div>
          </div>
          <input
            type="range"
            min="1"
            max={tenureType === 'years' ? 30 : 360}
            step="1"
            value={tenureYears}
            onChange={e => setTenureYears(parseInt(e.target.value, 10))}
            className="w-full accent-blue-600 mb-1"
          />
          <div className="text-right text-xs font-bold font-mono text-blue-600 dark:text-blue-400">
            {tenureYears} {tenureType === 'years' ? 'Years' : 'Months'}
          </div>
        </div>
      </div>

      {/* Results */}
      {results && (
        <div className="space-y-4">
          {/* Main EMI Highlight */}
          <div className="p-6 rounded-3xl bg-gradient-to-br from-blue-600 to-indigo-700 text-white text-center shadow-lg">
            <span className="text-xs font-medium text-blue-200 uppercase tracking-wider block mb-1">
              {language === 'hi' ? 'मासिक ईएमआई (Monthly EMI)' : 'Monthly EMI Amount'}
            </span>
            <div className="text-3xl sm:text-4xl font-extrabold font-mono tracking-tight">
              ₹ {results.monthlyEmi.toLocaleString()}
            </div>
          </div>

          {/* Breakdown cards */}
          <div className="grid grid-cols-2 gap-3">
            <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
              <span className="text-[11px] text-slate-500 block">
                {language === 'hi' ? 'कुल ब्याज देय' : 'Total Interest'}
              </span>
              <span className="text-base font-bold font-mono text-rose-600 dark:text-rose-400 block mt-1">
                ₹ {results.totalInterest.toLocaleString()}
              </span>
            </div>

            <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
              <span className="text-[11px] text-slate-500 block">
                {language === 'hi' ? 'कुल भुगतान (मूल + ब्याज)' : 'Total Amount Payable'}
              </span>
              <span className="text-base font-bold font-mono text-slate-900 dark:text-slate-100 block mt-1">
                ₹ {results.totalPayment.toLocaleString()}
              </span>
            </div>
          </div>

          {/* Visual Bar representation */}
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-2">
            <div className="flex items-center justify-between text-xs font-semibold">
              <span className="text-blue-600 dark:text-blue-400">
                Principal ({results.principalRatio}%)
              </span>
              <span className="text-rose-600 dark:text-rose-400">
                Interest ({results.interestRatio}%)
              </span>
            </div>
            <div className="w-full h-3 rounded-full bg-rose-500 overflow-hidden flex">
              <div
                className="h-full bg-blue-600"
                style={{ width: `${results.principalRatio}%` }}
              />
            </div>
          </div>

          {/* Amortization schedule toggle */}
          <div>
            <button
              onClick={() => setShowSchedule(!showSchedule)}
              className="w-full py-2.5 px-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:bg-slate-50 font-semibold text-xs text-slate-700 dark:text-slate-300 flex items-center justify-center gap-2 transition"
            >
              <Table className="w-4 h-4 text-blue-600" />
              <span>
                {showSchedule
                  ? language === 'hi' ? 'वार्षिक तालिका छुपाएं' : 'Hide Payment Schedule'
                  : language === 'hi' ? 'वार्षिक भुगतान तालिका देखें' : 'View Yearly Amortization Schedule'}
              </span>
            </button>

            {showSchedule && (
              <div className="mt-3 overflow-x-auto rounded-xl border border-slate-200 dark:border-slate-800">
                <table className="w-full text-left text-xs font-mono">
                  <thead className="bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                    <tr>
                      <th className="p-2.5">Year</th>
                      <th className="p-2.5">Principal</th>
                      <th className="p-2.5">Interest</th>
                      <th className="p-2.5">Balance</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {results.schedule.map(row => (
                      <tr key={row.year} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/40">
                        <td className="p-2.5 font-bold">Yr {row.year}</td>
                        <td className="p-2.5 text-blue-600 dark:text-blue-400">₹{Math.round(row.principal).toLocaleString()}</td>
                        <td className="p-2.5 text-rose-500">₹{Math.round(row.interest).toLocaleString()}</td>
                        <td className="p-2.5 text-slate-500">₹{Math.round(row.balance).toLocaleString()}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
