import React, { useState } from 'react';
import { useApp } from '../../../context/AppContext';
import { Receipt, Percent, ArrowUpDown } from 'lucide-react';

export const GstCalculator: React.FC = () => {
  const { t, language } = useApp();
  const [amount, setAmount] = useState<number>(1000);
  const [gstRate, setGstRate] = useState<number>(18);
  const [gstType, setGstType] = useState<'exclusive' | 'inclusive'>('exclusive');

  const calculateGST = () => {
    if (amount <= 0 || gstRate <= 0) return null;

    let netAmount = 0;
    let gstAmount = 0;
    let totalGross = 0;

    if (gstType === 'exclusive') {
      // Add GST on top
      netAmount = amount;
      gstAmount = (amount * gstRate) / 100;
      totalGross = netAmount + gstAmount;
    } else {
      // Extract GST from total
      totalGross = amount;
      netAmount = (amount * 100) / (100 + gstRate);
      gstAmount = totalGross - netAmount;
    }

    const cgst = gstAmount / 2;
    const sgst = gstAmount / 2;

    return {
      netAmount: Math.round(netAmount * 100) / 100,
      gstAmount: Math.round(gstAmount * 100) / 100,
      cgst: Math.round(cgst * 100) / 100,
      sgst: Math.round(sgst * 100) / 100,
      totalGross: Math.round(totalGross * 100) / 100,
    };
  };

  const results = calculateGST();
  const slabs = [5, 12, 18, 28];

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">
          {t('tool_gst_calc')}
        </h3>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
          {t('tool_gst_calc_desc')}
        </p>
      </div>

      {/* Input Form */}
      <div className="space-y-4 p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
        {/* Type toggle */}
        <div className="flex rounded-xl bg-slate-100 dark:bg-slate-800 p-1 text-xs font-semibold">
          <button
            type="button"
            onClick={() => setGstType('exclusive')}
            className={`flex-1 py-2 rounded-lg transition ${
              gstType === 'exclusive'
                ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-sm'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            {language === 'hi' ? 'जीएसटी जोड़ें (Exclusive)' : 'GST Exclusive (Add GST)'}
          </button>
          <button
            type="button"
            onClick={() => setGstType('inclusive')}
            className={`flex-1 py-2 rounded-lg transition ${
              gstType === 'inclusive'
                ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-sm'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            {language === 'hi' ? 'जीएसटी हटाएं (Inclusive)' : 'GST Inclusive (Remove GST)'}
          </button>
        </div>

        {/* Amount Input */}
        <div>
          <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
            {gstType === 'exclusive'
              ? language === 'hi' ? 'मूल राशि (Net Amount)' : 'Initial Amount'
              : language === 'hi' ? 'कुल राशि (Gross Amount)' : 'Total Price (with GST)'}
          </label>
          <div className="relative">
            <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 font-bold">
              ₹
            </span>
            <input
              type="number"
              value={amount || ''}
              onChange={e => setAmount(parseFloat(e.target.value) || 0)}
              className="w-full pl-8 pr-3 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-mono font-bold text-base focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>

        {/* GST Slab buttons */}
        <div>
          <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1.5">
            GST Slab Rate (%)
          </label>
          <div className="grid grid-cols-4 gap-2">
            {slabs.map(rate => (
              <button
                key={rate}
                type="button"
                onClick={() => setGstRate(rate)}
                className={`py-2 px-3 rounded-xl border text-xs font-bold font-mono transition ${
                  gstRate === rate
                    ? 'border-blue-600 dark:border-blue-500 bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400'
                    : 'border-slate-200 dark:border-slate-700 hover:border-slate-300 text-slate-700 dark:text-slate-300'
                }`}
              >
                {rate}%
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Breakdown Output */}
      {results && (
        <div className="space-y-3">
          <div className="p-6 rounded-3xl bg-gradient-to-br from-blue-600 to-indigo-700 text-white text-center shadow-lg">
            <span className="text-xs font-medium text-blue-200 uppercase tracking-wider block mb-1">
              {gstType === 'exclusive' ? 'Final Total Amount (With GST)' : 'Net Amount (Without GST)'}
            </span>
            <div className="text-3xl font-extrabold font-mono">
              ₹ {gstType === 'exclusive' ? results.totalGross.toLocaleString() : results.netAmount.toLocaleString()}
            </div>
            <span className="text-xs text-blue-100 mt-1 block">
              {gstType === 'exclusive'
                ? `Total GST Added: ₹ ${results.gstAmount.toLocaleString()} (${gstRate}%)`
                : `Total GST Included: ₹ ${results.gstAmount.toLocaleString()} (${gstRate}%)`}
            </span>
          </div>

          <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 divide-y divide-slate-100 dark:divide-slate-800 text-xs">
            <div className="flex items-center justify-between py-2">
              <span className="text-slate-500">Net / Base Price</span>
              <span className="font-mono font-bold text-slate-900 dark:text-slate-100">
                ₹ {results.netAmount.toLocaleString()}
              </span>
            </div>
            <div className="flex items-center justify-between py-2">
              <span className="text-slate-500">CGST ({gstRate / 2}%)</span>
              <span className="font-mono font-bold text-blue-600 dark:text-blue-400">
                ₹ {results.cgst.toLocaleString()}
              </span>
            </div>
            <div className="flex items-center justify-between py-2">
              <span className="text-slate-500">SGST / UTGST ({gstRate / 2}%)</span>
              <span className="font-mono font-bold text-blue-600 dark:text-blue-400">
                ₹ {results.sgst.toLocaleString()}
              </span>
            </div>
            <div className="flex items-center justify-between py-2 font-bold text-sm">
              <span className="text-slate-800 dark:text-slate-200">Total Gross Amount</span>
              <span className="font-mono text-emerald-600 dark:text-emerald-400">
                ₹ {results.totalGross.toLocaleString()}
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
