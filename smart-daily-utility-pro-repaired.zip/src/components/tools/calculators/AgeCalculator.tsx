import React, { useState } from 'react';
import { useApp } from '../../../context/AppContext';
import { Calendar, Cake, Clock, Sparkles } from 'lucide-react';

export const AgeCalculator: React.FC = () => {
  const { t, language } = useApp();
  const [birthDate, setBirthDate] = useState<string>('2000-01-01');
  const [targetDate, setTargetDate] = useState<string>(
    new Date().toISOString().split('T')[0]
  );

  const calculateAge = () => {
    const birth = new Date(birthDate);
    const target = new Date(targetDate);

    if (isNaN(birth.getTime()) || isNaN(target.getTime()) || target < birth) {
      return null;
    }

    let years = target.getFullYear() - birth.getFullYear();
    let months = target.getMonth() - birth.getMonth();
    let days = target.getDate() - birth.getDate();

    if (days < 0) {
      months -= 1;
      const prevMonth = new Date(target.getFullYear(), target.getMonth(), 0);
      days += prevMonth.getDate();
    }

    if (months < 0) {
      years -= 1;
      months += 12;
    }

    // Total metrics
    const diffMs = target.getTime() - birth.getTime();
    const totalDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
    const totalWeeks = Math.floor(totalDays / 7);
    const totalHours = totalDays * 24;
    const totalMinutes = totalHours * 60;

    // Next birthday
    let nextBday = new Date(target.getFullYear(), birth.getMonth(), birth.getDate());
    if (nextBday < target) {
      nextBday = new Date(target.getFullYear() + 1, birth.getMonth(), birth.getDate());
    }
    const daysToNextBday = Math.ceil((nextBday.getTime() - target.getTime()) / (1000 * 60 * 60 * 24));
    const nextBdayDayName = nextBday.toLocaleDateString(language === 'hi' ? 'hi-IN' : 'en-US', {
      weekday: 'long',
    });

    // Zodiac sign
    const bMonth = birth.getMonth() + 1;
    const bDay = birth.getDate();
    const getZodiac = (m: number, d: number) => {
      if ((m === 3 && d >= 21) || (m === 4 && d <= 19)) return 'Aries (मेष)';
      if ((m === 4 && d >= 20) || (m === 5 && d <= 20)) return 'Taurus (वृषभ)';
      if ((m === 5 && d >= 21) || (m === 6 && d <= 20)) return 'Gemini (मिथुन)';
      if ((m === 6 && d >= 21) || (m === 7 && d <= 22)) return 'Cancer (कर्क)';
      if ((m === 7 && d >= 23) || (m === 8 && d <= 22)) return 'Leo (सिंह)';
      if ((m === 8 && d >= 23) || (m === 9 && d <= 22)) return 'Virgo (कन्या)';
      if ((m === 9 && d >= 23) || (m === 10 && d <= 22)) return 'Libra (तुला)';
      if ((m === 10 && d >= 23) || (m === 11 && d <= 21)) return 'Scorpio (वृश्चिक)';
      if ((m === 11 && d >= 22) || (m === 12 && d <= 21)) return 'Sagittarius (धनु)';
      if ((m === 12 && d >= 22) || (m === 1 && d <= 19)) return 'Capricorn (मकर)';
      if ((m === 1 && d >= 20) || (m === 2 && d <= 18)) return 'Aquarius (कुंभ)';
      return 'Pisces (मीन)';
    };

    return {
      years,
      months,
      days,
      totalDays,
      totalWeeks,
      totalHours,
      totalMinutes,
      daysToNextBday,
      nextBdayDayName,
      zodiac: getZodiac(bMonth, bDay),
    };
  };

  const result = calculateAge();

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">
          {t('tool_age_calc')}
        </h3>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
          {t('tool_age_calc_desc')}
        </p>
      </div>

      {/* Date Pickers */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
        <div>
          <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1.5">
            {language === 'hi' ? 'जन्म तिथि (Date of Birth)' : 'Date of Birth'}
          </label>
          <input
            type="date"
            value={birthDate}
            onChange={e => setBirthDate(e.target.value)}
            className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-mono font-medium focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div>
          <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1.5">
            {language === 'hi' ? 'आयु की तारीख (Age as of Date)' : 'Age As Of'}
          </label>
          <input
            type="date"
            value={targetDate}
            onChange={e => setTargetDate(e.target.value)}
            className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-mono font-medium focus:ring-2 focus:ring-blue-500"
          />
        </div>
      </div>

      {/* Primary Result Display */}
      {result && (
        <div className="space-y-4">
          <div className="p-6 rounded-3xl bg-gradient-to-br from-blue-600 to-indigo-700 text-white shadow-xl text-center">
            <span className="text-xs font-medium uppercase tracking-wider text-blue-200 block mb-2">
              {language === 'hi' ? 'आपकी वर्तमान आयु' : 'Your Exact Age'}
            </span>
            <div className="flex items-center justify-center gap-4 my-2">
              <div>
                <span className="text-3xl sm:text-4xl font-extrabold font-mono block">
                  {result.years}
                </span>
                <span className="text-[11px] text-blue-100 font-medium">
                  {language === 'hi' ? 'वर्ष' : 'Years'}
                </span>
              </div>
              <span className="text-2xl text-blue-300 font-light">:</span>
              <div>
                <span className="text-3xl sm:text-4xl font-extrabold font-mono block">
                  {result.months}
                </span>
                <span className="text-[11px] text-blue-100 font-medium">
                  {language === 'hi' ? 'महीने' : 'Months'}
                </span>
              </div>
              <span className="text-2xl text-blue-300 font-light">:</span>
              <div>
                <span className="text-3xl sm:text-4xl font-extrabold font-mono block">
                  {result.days}
                </span>
                <span className="text-[11px] text-blue-100 font-medium">
                  {language === 'hi' ? 'दिन' : 'Days'}
                </span>
              </div>
            </div>
          </div>

          {/* Next Birthday & Zodiac */}
          <div className="grid grid-cols-2 gap-3">
            <div className="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/60 flex items-start gap-3">
              <div className="w-10 h-10 rounded-xl bg-amber-100 dark:bg-amber-900 text-amber-600 dark:text-amber-300 flex items-center justify-center shrink-0">
                <Cake className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[11px] text-slate-500 dark:text-slate-400 block font-medium">
                  {language === 'hi' ? 'अगला जन्मदिन' : 'Next Birthday'}
                </span>
                <span className="text-sm font-bold text-slate-900 dark:text-slate-100 block">
                  {result.daysToNextBday} {language === 'hi' ? 'दिन बाकी' : 'days left'}
                </span>
                <span className="text-[10px] text-amber-700 dark:text-amber-400 font-medium">
                  {result.nextBdayDayName}
                </span>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-purple-50 dark:bg-purple-950/40 border border-purple-200 dark:border-purple-900/60 flex items-start gap-3">
              <div className="w-10 h-10 rounded-xl bg-purple-100 dark:bg-purple-900 text-purple-600 dark:text-purple-300 flex items-center justify-center shrink-0">
                <Sparkles className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[11px] text-slate-500 dark:text-slate-400 block font-medium">
                  {language === 'hi' ? 'राशि चक्र' : 'Zodiac Sign'}
                </span>
                <span className="text-xs font-bold text-slate-900 dark:text-slate-100 block mt-0.5">
                  {result.zodiac}
                </span>
              </div>
            </div>
          </div>

          {/* Life stats grid */}
          <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
            <span className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-3">
              {language === 'hi' ? 'जीवन के महत्वपूर्ण आंकड़े' : 'Total Life Statistics'}
            </span>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center">
              <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800">
                <span className="text-sm font-bold font-mono text-slate-900 dark:text-slate-100 block">
                  {result.totalDays.toLocaleString()}
                </span>
                <span className="text-[10px] text-slate-500">Total Days</span>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800">
                <span className="text-sm font-bold font-mono text-slate-900 dark:text-slate-100 block">
                  {result.totalWeeks.toLocaleString()}
                </span>
                <span className="text-[10px] text-slate-500">Total Weeks</span>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800">
                <span className="text-sm font-bold font-mono text-slate-900 dark:text-slate-100 block">
                  {result.totalHours.toLocaleString()}
                </span>
                <span className="text-[10px] text-slate-500">Total Hours</span>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800">
                <span className="text-sm font-bold font-mono text-slate-900 dark:text-slate-100 block">
                  {result.totalMinutes.toLocaleString()}
                </span>
                <span className="text-[10px] text-slate-500">Total Minutes</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
