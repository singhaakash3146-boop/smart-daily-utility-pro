import React, { useState } from 'react';
import { useApp } from '../../../context/AppContext';
import { Tag, Sparkles, ShoppingBag } from 'lucide-react';

export const DiscountCalculator: React.FC = () => {
  const { t, language } = useApp();
  const [originalPrice, setOriginalPrice] = useState<number>(2000);
  const [discountPercent, setDiscountPercent] = useState<number>(25);
  const [couponPercent, setCouponPercent] = useState<number>(0);

  const calculateDiscount = () => {
    if (originalPrice <= 0) return null;

    const firstDiscountAmount = (originalPrice * discountPercent) / 100;
    const priceAfterFirst = originalPrice - firstDiscountAmount;

    const couponAmount = (priceAfterFirst * couponPercent) / 100;
    const finalPrice = Math.max(0, priceAfterFirst - couponAmount);
    const totalSavings = originalPrice - finalPrice;
    const effectivePercent = Math.round((totalSavings / originalPrice) * 100);

    return {
      finalPrice: Math.round(finalPrice * 100) / 100,
      totalSavings: Math.round(totalSavings * 100) / 100,
      effectivePercent,
    };
  };

  const results = calculateDiscount();
  const presets = [10, 15, 20, 25, 30, 40, 50, 70];

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">
          {t('tool_discount_calc')}
        </h3>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
          {t('tool_discount_calc_desc')}
        </p>
      </div>

      <div className="space-y-4 p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
        <div>
          <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
            {language === 'hi' ? 'मूल कीमत (Original Price)' : 'Original Price (MRP)'}
          </label>
          <div className="relative">
            <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 font-bold">
              ₹
            </span>
            <input
              type="number"
              value={originalPrice || ''}
              onChange={e => setOriginalPrice(parseFloat(e.target.value) || 0)}
              className="w-full pl-8 pr-3 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-mono font-bold text-base focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>

        <div>
          <div className="flex items-center justify-between mb-1.5">
            <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
              {language === 'hi' ? 'छूट (Discount %)' : 'Discount Rate (%)'}
            </label>
            <span className="text-xs font-bold font-mono text-blue-600 dark:text-blue-400">
              {discountPercent}%
            </span>
          </div>
          <input
            type="range"
            min="1"
            max="95"
            step="1"
            value={discountPercent}
            onChange={e => setDiscountPercent(parseInt(e.target.value, 10))}
            className="w-full accent-blue-600 mb-2"
          />

          <div className="flex flex-wrap gap-1.5">
            {presets.map(p => (
              <button
                key={p}
                type="button"
                onClick={() => setDiscountPercent(p)}
                className={`px-2.5 py-1 rounded-lg text-xs font-semibold font-mono transition ${
                  discountPercent === p
                    ? 'bg-blue-600 text-white'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
                }`}
              >
                {p}%
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
            {language === 'hi' ? 'अतिरिक्त कूपन छूट (% ऐच्छिक)' : 'Extra Coupon / Voucher Discount (% optional)'}
          </label>
          <input
            type="number"
            min="0"
            max="90"
            value={couponPercent || ''}
            onChange={e => setCouponPercent(parseFloat(e.target.value) || 0)}
            placeholder="0%"
            className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-mono text-xs focus:ring-2 focus:ring-blue-500"
          />
        </div>
      </div>

      {results && (
        <div className="space-y-4">
          {/* Visual Price Tag */}
          <div className="p-6 rounded-3xl bg-gradient-to-br from-emerald-600 to-teal-700 text-white text-center shadow-lg relative overflow-hidden">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/30 text-emerald-100 text-xs font-bold mb-2">
              <Sparkles className="w-3.5 h-3.5" />
              <span>You Save {results.effectivePercent}%</span>
            </div>
            <div className="text-xs text-emerald-200 uppercase tracking-wider">Final Payable Price</div>
            <div className="text-3xl sm:text-4xl font-extrabold font-mono mt-1">
              ₹ {results.finalPrice.toLocaleString()}
            </div>
            <div className="mt-2 text-xs text-emerald-100">
              Original: <span className="line-through">₹ {originalPrice.toLocaleString()}</span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 text-center">
            <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
              <span className="text-[11px] text-slate-500 block">Total Money Saved</span>
              <span className="text-base font-bold font-mono text-emerald-600 dark:text-emerald-400 block mt-1">
                ₹ {results.totalSavings.toLocaleString()}
              </span>
            </div>
            <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
              <span className="text-[11px] text-slate-500 block">Net Effective Discount</span>
              <span className="text-base font-bold font-mono text-blue-600 dark:text-blue-400 block mt-1">
                {results.effectivePercent}% OFF
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
