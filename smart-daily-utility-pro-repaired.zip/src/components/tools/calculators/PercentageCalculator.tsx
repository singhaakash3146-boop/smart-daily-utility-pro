import React, { useState } from 'react';
import { useApp } from '../../../context/AppContext';
import { Percent, ArrowRight } from 'lucide-react';

export const PercentageCalculator: React.FC = () => {
  const { t, language } = useApp();
  const [activeMode, setActiveMode] = useState<'of' | 'isWhat' | 'change' | 'margin'>('of');

  // Mode 1: What is X% of Y?
  const [m1X, setM1X] = useState<number>(15);
  const [m1Y, setM1Y] = useState<number>(2500);

  // Mode 2: X is what % of Y?
  const [m2X, setM2X] = useState<number>(450);
  const [m2Y, setM2Y] = useState<number>(1500);

  // Mode 3: Percentage increase / decrease from X to Y
  const [m3Initial, setM3Initial] = useState<number>(120);
  const [m3Final, setM3Final] = useState<number>(180);

  // Mode 4: Margin / Markup (Cost vs Selling)
  const [m4Cost, setM4Cost] = useState<number>(1000);
  const [m4Selling, setM4Selling] = useState<number>(1400);

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">
          {t('tool_percentage_calc')}
        </h3>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
          {t('tool_percentage_calc_desc')}
        </p>
      </div>

      {/* Mode Tabs */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 p-1 rounded-2xl bg-slate-100 dark:bg-slate-800 text-xs font-semibold">
        <button
          onClick={() => setActiveMode('of')}
          className={`py-2 px-2 rounded-xl transition ${
            activeMode === 'of'
              ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-sm'
              : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          X% of Y
        </button>
        <button
          onClick={() => setActiveMode('isWhat')}
          className={`py-2 px-2 rounded-xl transition ${
            activeMode === 'isWhat'
              ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-sm'
              : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          X is what %
        </button>
        <button
          onClick={() => setActiveMode('change')}
          className={`py-2 px-2 rounded-xl transition ${
            activeMode === 'change'
              ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-sm'
              : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          Increase / Decrease
        </button>
        <button
          onClick={() => setActiveMode('margin')}
          className={`py-2 px-2 rounded-xl transition ${
            activeMode === 'margin'
              ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-sm'
              : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          Margin & Profit
        </button>
      </div>

      {/* Mode 1: What is X% of Y */}
      {activeMode === 'of' && (
        <div className="space-y-4">
          <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3">
            <span className="text-xs font-bold text-slate-700 dark:text-slate-300 block">
              {language === 'hi' ? 'Y का X% कितना होगा?' : 'What is X% of Y?'}
            </span>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-[11px] text-slate-500 block mb-1">Percentage (X %)</label>
                <input
                  type="number"
                  value={m1X || ''}
                  onChange={e => setM1X(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 text-sm rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-mono font-bold"
                />
              </div>
              <div>
                <label className="text-[11px] text-slate-500 block mb-1">Total Value (Y)</label>
                <input
                  type="number"
                  value={m1Y || ''}
                  onChange={e => setM1Y(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 text-sm rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-mono font-bold"
                />
              </div>
            </div>
          </div>

          <div className="p-6 rounded-3xl bg-blue-600 text-white text-center shadow-lg">
            <span className="text-xs text-blue-200 block mb-1">Result</span>
            <div className="text-3xl font-extrabold font-mono">
              {((m1X * m1Y) / 100).toLocaleString(undefined, { maximumFractionDigits: 2 })}
            </div>
            <span className="text-xs text-blue-100 mt-1 block">
              {m1X}% of {m1Y} is {((m1X * m1Y) / 100).toLocaleString()}
            </span>
          </div>
        </div>
      )}

      {/* Mode 2: X is what % of Y */}
      {activeMode === 'isWhat' && (
        <div className="space-y-4">
          <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3">
            <span className="text-xs font-bold text-slate-700 dark:text-slate-300 block">
              {language === 'hi' ? 'X, Y का कितना प्रतिशत है?' : 'X is what percentage of Y?'}
            </span>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-[11px] text-slate-500 block mb-1">Part Value (X)</label>
                <input
                  type="number"
                  value={m2X || ''}
                  onChange={e => setM2X(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 text-sm rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-mono font-bold"
                />
              </div>
              <div>
                <label className="text-[11px] text-slate-500 block mb-1">Total Base (Y)</label>
                <input
                  type="number"
                  value={m2Y || ''}
                  onChange={e => setM2Y(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 text-sm rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-mono font-bold"
                />
              </div>
            </div>
          </div>

          <div className="p-6 rounded-3xl bg-indigo-600 text-white text-center shadow-lg">
            <span className="text-xs text-indigo-200 block mb-1">Percentage</span>
            <div className="text-3xl font-extrabold font-mono">
              {m2Y > 0 ? ((m2X / m2Y) * 100).toFixed(2) : 0}%
            </div>
            <span className="text-xs text-indigo-100 mt-1 block">
              {m2X} out of {m2Y}
            </span>
          </div>
        </div>
      )}

      {/* Mode 3: Percentage increase / decrease */}
      {activeMode === 'change' && (
        <div className="space-y-4">
          <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3">
            <span className="text-xs font-bold text-slate-700 dark:text-slate-300 block">
              {language === 'hi' ? 'प्रारंभिक से अंतिम मान में परिवर्तन' : 'Percentage Change (Increase / Decrease)'}
            </span>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-[11px] text-slate-500 block mb-1">Initial Value</label>
                <input
                  type="number"
                  value={m3Initial || ''}
                  onChange={e => setM3Initial(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 text-sm rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-mono font-bold"
                />
              </div>
              <div>
                <label className="text-[11px] text-slate-500 block mb-1">Final Value</label>
                <input
                  type="number"
                  value={m3Final || ''}
                  onChange={e => setM3Final(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 text-sm rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-mono font-bold"
                />
              </div>
            </div>
          </div>

          {(() => {
            const diff = m3Final - m3Initial;
            const pct = m3Initial > 0 ? ((diff / m3Initial) * 100).toFixed(2) : '0';
            const isIncrease = diff >= 0;
            return (
              <div
                className={`p-6 rounded-3xl text-white text-center shadow-lg ${
                  isIncrease ? 'bg-emerald-600' : 'bg-rose-600'
                }`}
              >
                <span className="text-xs uppercase tracking-wider block mb-1 opacity-80">
                  {isIncrease ? 'Percentage Increase' : 'Percentage Decrease'}
                </span>
                <div className="text-3xl font-extrabold font-mono">
                  {isIncrease ? `+${pct}%` : `${pct}%`}
                </div>
                <span className="text-xs mt-1 block opacity-90">
                  Difference of {Math.abs(diff).toLocaleString()} from original
                </span>
              </div>
            );
          })()}
        </div>
      )}

      {/* Mode 4: Margin & Markup */}
      {activeMode === 'margin' && (
        <div className="space-y-4">
          <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3">
            <span className="text-xs font-bold text-slate-700 dark:text-slate-300 block">
              Profit Margin & Markup Calculator
            </span>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-[11px] text-slate-500 block mb-1">Cost Price (CP)</label>
                <input
                  type="number"
                  value={m4Cost || ''}
                  onChange={e => setM4Cost(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 text-sm rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-mono font-bold"
                />
              </div>
              <div>
                <label className="text-[11px] text-slate-500 block mb-1">Selling Price (SP)</label>
                <input
                  type="number"
                  value={m4Selling || ''}
                  onChange={e => setM4Selling(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 text-sm rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-mono font-bold"
                />
              </div>
            </div>
          </div>

          {(() => {
            const profit = m4Selling - m4Cost;
            const margin = m4Selling > 0 ? ((profit / m4Selling) * 100).toFixed(2) : '0';
            const markup = m4Cost > 0 ? ((profit / m4Cost) * 100).toFixed(2) : '0';

            return (
              <div className="grid grid-cols-3 gap-2 text-center">
                <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                  <span className="text-[11px] text-slate-500 block">Net Profit</span>
                  <span className="text-base font-bold font-mono text-emerald-600 block mt-1">
                    ₹ {profit.toLocaleString()}
                  </span>
                </div>
                <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                  <span className="text-[11px] text-slate-500 block">Profit Margin</span>
                  <span className="text-base font-bold font-mono text-blue-600 block mt-1">
                    {margin}%
                  </span>
                </div>
                <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                  <span className="text-[11px] text-slate-500 block">Markup Rate</span>
                  <span className="text-base font-bold font-mono text-purple-600 block mt-1">
                    {markup}%
                  </span>
                </div>
              </div>
            );
          })()}
        </div>
      )}
    </div>
  );
};
