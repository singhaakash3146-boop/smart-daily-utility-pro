import React, { useState } from 'react';
import { useApp } from '../../../context/AppContext';
import { Delete, History, RotateCcw } from 'lucide-react';

export const ScientificCalculator: React.FC = () => {
  const { t, language } = useApp();
  const [expression, setExpression] = useState<string>('');
  const [result, setResult] = useState<string>('0');
  const [isRad, setIsRad] = useState<boolean>(true);
  const [history, setHistory] = useState<{ expr: string; res: string }[]>([]);
  const [showHistory, setShowHistory] = useState<boolean>(false);

  const appendToken = (token: string) => {
    setExpression(prev => prev + token);
  };

  const clearAll = () => {
    setExpression('');
    setResult('0');
  };

  const deleteLast = () => {
    setExpression(prev => prev.slice(0, -1));
  };

  const evaluateExpression = () => {
    if (!expression) return;
    try {
      // Safe math parser
      let sanitized = expression
        .replace(/×/g, '*')
        .replace(/÷/g, '/')
        .replace(/π/g, 'Math.PI')
        .replace(/e/g, 'Math.E')
        .replace(/\^/g, '**');

      // Functions with rad/deg conversion
      if (isRad) {
        sanitized = sanitized
          .replace(/sin\(/g, 'Math.sin(')
          .replace(/cos\(/g, 'Math.cos(')
          .replace(/tan\(/g, 'Math.tan(');
      } else {
        sanitized = sanitized
          .replace(/sin\(([^)]+)\)/g, 'Math.sin(($1) * Math.PI / 180)')
          .replace(/cos\(([^)]+)\)/g, 'Math.cos(($1) * Math.PI / 180)')
          .replace(/tan\(([^)]+)\)/g, 'Math.tan(($1) * Math.PI / 180)');
      }

      sanitized = sanitized
        .replace(/ln\(/g, 'Math.log(')
        .replace(/log\(/g, 'Math.log10(')
        .replace(/√\(/g, 'Math.sqrt(');

      // Percentage calculation
      sanitized = sanitized.replace(/(\d+(\.\d+)?)%/g, '($1/100)');

      // Auto close any unclosed parentheses
      const openParens = (sanitized.match(/\(/g) || []).length;
      const closeParens = (sanitized.match(/\)/g) || []).length;
      if (openParens > closeParens) {
        sanitized += ')'.repeat(openParens - closeParens);
      }

      // Security check: ensure only Math functions, numbers, and basic operators are present
      const invalidChars = sanitized
        .replace(/Math\.(sin|cos|tan|log|log10|sqrt|PI|E)/g, '')
        .replace(/[0-9+\-*/%(),.\s]/g, '');

      if (invalidChars.length > 0) {
        setResult('Error');
        return;
      }

      // eslint-disable-next-line no-eval
      const evalResult = Function(`"use strict"; return (${sanitized})`)();
      const formatted = Number.isFinite(evalResult)
        ? Math.round(evalResult * 100000000) / 100000000
        : 'Error';

      setResult(formatted.toString());
      setHistory(prev => [{ expr: expression, res: formatted.toString() }, ...prev.slice(0, 9)]);
    } catch {
      setResult('Error');
    }
  };

  return (
    <div className="space-y-4 max-w-sm mx-auto">
      <div>
        <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">
          {t('tool_scientific_calc')}
        </h3>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
          {t('tool_scientific_calc_desc')}
        </p>
      </div>

      {/* Screen Display */}
      <div className="p-4 rounded-3xl bg-slate-900 text-white font-mono shadow-inner border border-slate-800 text-right space-y-1">
        <div className="flex items-center justify-between text-xs text-slate-400">
          <div className="flex gap-2">
            <button
              onClick={() => setIsRad(!isRad)}
              className="px-2 py-0.5 rounded bg-slate-800 text-blue-400 font-bold hover:bg-slate-700 transition"
            >
              {isRad ? 'RAD' : 'DEG'}
            </button>
            <button
              onClick={() => setShowHistory(!showHistory)}
              className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center gap-1"
            >
              <History className="w-3 h-3" />
              <span>{history.length}</span>
            </button>
          </div>
          <span className="text-[11px] truncate max-w-[180px]">
            {expression || '0'}
          </span>
        </div>
        <div className="text-3xl sm:text-4xl font-bold tracking-tight text-white overflow-x-auto py-1">
          {result}
        </div>
      </div>

      {/* History view */}
      {showHistory && (
        <div className="p-3 rounded-2xl bg-slate-100 dark:bg-slate-800 text-xs font-mono max-h-40 overflow-y-auto space-y-1.5 border border-slate-200 dark:border-slate-700">
          <div className="flex items-center justify-between text-slate-500 font-sans font-semibold pb-1 border-b border-slate-200 dark:border-slate-700">
            <span>Recent Calculations</span>
            <button onClick={() => setHistory([])} className="text-rose-500 hover:underline">
              Clear
            </button>
          </div>
          {history.length === 0 ? (
            <p className="text-slate-400 text-center py-2">No history yet</p>
          ) : (
            history.map((h, i) => (
              <div
                key={i}
                onClick={() => {
                  setExpression(h.expr);
                  setResult(h.res);
                }}
                className="flex items-center justify-between p-1.5 rounded hover:bg-white dark:hover:bg-slate-700 cursor-pointer"
              >
                <span className="text-slate-500 truncate max-w-[180px]">{h.expr} =</span>
                <span className="font-bold text-slate-900 dark:text-slate-100">{h.res}</span>
              </div>
            ))
          )}
        </div>
      )}

      {/* Keypad Grid */}
      <div className="grid grid-cols-5 gap-1.5 text-xs font-semibold">
        {/* Row 1 Scientific Functions */}
        <button
          onClick={() => appendToken('sin(')}
          className="p-3 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300"
        >
          sin
        </button>
        <button
          onClick={() => appendToken('cos(')}
          className="p-3 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300"
        >
          cos
        </button>
        <button
          onClick={() => appendToken('tan(')}
          className="p-3 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300"
        >
          tan
        </button>
        <button
          onClick={() => appendToken('ln(')}
          className="p-3 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300"
        >
          ln
        </button>
        <button
          onClick={() => appendToken('log(')}
          className="p-3 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300"
        >
          log
        </button>

        {/* Row 2 Powers & Const */}
        <button
          onClick={() => appendToken('^')}
          className="p-3 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 font-mono"
        >
          xʸ
        </button>
        <button
          onClick={() => appendToken('√(')}
          className="p-3 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300"
        >
          √
        </button>
        <button
          onClick={() => appendToken('π')}
          className="p-3 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300"
        >
          π
        </button>
        <button
          onClick={() => appendToken('e')}
          className="p-3 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300"
        >
          e
        </button>
        <button
          onClick={() => appendToken('!')}
          className="p-3 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300"
        >
          n!
        </button>

        {/* Row 3 Parens & Clear */}
        <button
          onClick={clearAll}
          className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 font-bold hover:bg-rose-100"
        >
          AC
        </button>
        <button
          onClick={() => appendToken('(')}
          className="p-3 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300"
        >
          (
        </button>
        <button
          onClick={() => appendToken(')')}
          className="p-3 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300"
        >
          )
        </button>
        <button
          onClick={() => appendToken('%')}
          className="p-3 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300"
        >
          %
        </button>
        <button
          onClick={() => appendToken('÷')}
          className="p-3 rounded-xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 text-base font-bold hover:bg-blue-100"
        >
          ÷
        </button>

        {/* Numbers & Operators */}
        <button
          onClick={() => appendToken('7')}
          className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-slate-100 text-sm font-bold shadow-sm"
        >
          7
        </button>
        <button
          onClick={() => appendToken('8')}
          className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-slate-100 text-sm font-bold shadow-sm"
        >
          8
        </button>
        <button
          onClick={() => appendToken('9')}
          className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-slate-100 text-sm font-bold shadow-sm"
        >
          9
        </button>
        <button
          onClick={() => appendToken('×')}
          className="p-3 rounded-xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 text-base font-bold hover:bg-blue-100"
        >
          ×
        </button>
        <button
          onClick={deleteLast}
          className="p-3 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 flex items-center justify-center hover:bg-slate-200"
        >
          <Delete className="w-4 h-4" />
        </button>

        <button
          onClick={() => appendToken('4')}
          className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-slate-100 text-sm font-bold shadow-sm"
        >
          4
        </button>
        <button
          onClick={() => appendToken('5')}
          className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-slate-100 text-sm font-bold shadow-sm"
        >
          5
        </button>
        <button
          onClick={() => appendToken('6')}
          className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-slate-100 text-sm font-bold shadow-sm"
        >
          6
        </button>
        <button
          onClick={() => appendToken('-')}
          className="p-3 rounded-xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 text-base font-bold hover:bg-blue-100"
        >
          -
        </button>
        <button
          onClick={() => appendToken('^2')}
          className="p-3 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-mono hover:bg-slate-200"
        >
          x²
        </button>

        <button
          onClick={() => appendToken('1')}
          className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-slate-100 text-sm font-bold shadow-sm"
        >
          1
        </button>
        <button
          onClick={() => appendToken('2')}
          className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-slate-100 text-sm font-bold shadow-sm"
        >
          2
        </button>
        <button
          onClick={() => appendToken('3')}
          className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-slate-100 text-sm font-bold shadow-sm"
        >
          3
        </button>
        <button
          onClick={() => appendToken('+')}
          className="p-3 rounded-xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 text-base font-bold hover:bg-blue-100"
        >
          +
        </button>
        <button
          onClick={evaluateExpression}
          className="row-span-2 p-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-extrabold text-lg shadow-md flex items-center justify-center transition active:scale-95"
        >
          =
        </button>

        <button
          onClick={() => appendToken('0')}
          className="col-span-2 p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-slate-100 text-sm font-bold shadow-sm"
        >
          0
        </button>
        <button
          onClick={() => appendToken('.')}
          className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-slate-100 text-sm font-bold shadow-sm"
        >
          .
        </button>
        <button
          onClick={() => appendToken('00')}
          className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-slate-100 text-sm font-bold shadow-sm"
        >
          00
        </button>
      </div>
    </div>
  );
};
