import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../../../context/AppContext';
import QRCode from 'qrcode';
import {
  QrCode,
  FileDown,
  FolderPlus,
  Copy,
  Check,
  Wifi,
  Globe,
  IndianRupee,
  Phone,
  Mail,
  Type,
} from 'lucide-react';

export const QrGenerator: React.FC = () => {
  const { t, addDocument, showToast, language } = useApp();
  const [type, setType] = useState<'url' | 'text' | 'wifi' | 'upi' | 'phone' | 'email'>('url');

  // Input states
  const [url, setUrl] = useState<string>('https://google.com');
  const [text, setText] = useState<string>('Hello from Smart Daily Utility Pro!');
  const [wifiSsid, setWifiSsid] = useState<string>('MyHomeWiFi');
  const [wifiPass, setWifiPass] = useState<string>('password123');
  const [wifiSec, setWifiSec] = useState<'WPA' | 'WEP' | 'nopass'>('WPA');
  const [upiId, setUpiId] = useState<string>('merchant@upi');
  const [upiName, setUpiName] = useState<string>('Store Name');
  const [upiAmount, setUpiAmount] = useState<string>('500');
  const [phone, setPhone] = useState<string>('+919876543210');
  const [email, setEmail] = useState<string>('support@example.com');

  // Styling options
  const [fgColor, setFgColor] = useState<string>('#000000');
  const [bgColor, setBgColor] = useState<string>('#ffffff');
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [copied, setCopied] = useState<boolean>(false);

  const getPayload = (): string => {
    switch (type) {
      case 'url':
        return url;
      case 'text':
        return text;
      case 'wifi':
        return `WIFI:T:${wifiSec};S:${wifiSsid};P:${wifiPass};;`;
      case 'upi':
        return `upi://pay?pa=${encodeURIComponent(upiId)}&pn=${encodeURIComponent(upiName)}&am=${encodeURIComponent(upiAmount)}&cu=INR`;
      case 'phone':
        return `tel:${phone}`;
      case 'email':
        return `mailto:${email}`;
      default:
        return url;
    }
  };

  useEffect(() => {
    const payload = getPayload();
    if (!payload) return;

    QRCode.toDataURL(payload, {
      width: 480,
      margin: 2,
      color: {
        dark: fgColor,
        light: bgColor,
      },
      errorCorrectionLevel: 'H',
    })
      .then(url => setQrDataUrl(url))
      .catch(err => console.error(err));
  }, [type, url, text, wifiSsid, wifiPass, wifiSec, upiId, upiName, upiAmount, phone, email, fgColor, bgColor]);

  const handleDownload = () => {
    if (!qrDataUrl) return;
    const a = document.createElement('a');
    a.href = qrDataUrl;
    a.download = `QRCode_${type}_${Date.now()}.png`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleSaveToDocs = () => {
    if (!qrDataUrl) return;
    addDocument({
      name: `QRCode_${type.toUpperCase()}`,
      type: 'qr',
      size: Math.round((qrDataUrl.length * 3) / 4),
      dataUrl: qrDataUrl,
      category: 'QR Tools',
      tags: ['Generated', type.toUpperCase()],
    });
  };

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">
          {t('tool_qr_generator')}
        </h3>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
          {t('tool_qr_generator_desc')}
        </p>
      </div>

      {/* Mode Selector Strip */}
      <div className="grid grid-cols-3 sm:grid-cols-6 gap-1.5 p-1 rounded-2xl bg-slate-100 dark:bg-slate-800 text-xs font-semibold">
        <button
          onClick={() => setType('url')}
          className={`py-2 px-2 rounded-xl flex items-center justify-center gap-1.5 transition ${
            type === 'url' ? 'bg-white dark:bg-slate-700 text-emerald-600 dark:text-emerald-400 shadow-sm' : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          <Globe className="w-3.5 h-3.5" />
          <span>URL</span>
        </button>
        <button
          onClick={() => setType('text')}
          className={`py-2 px-2 rounded-xl flex items-center justify-center gap-1.5 transition ${
            type === 'text' ? 'bg-white dark:bg-slate-700 text-emerald-600 dark:text-emerald-400 shadow-sm' : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          <Type className="w-3.5 h-3.5" />
          <span>Text</span>
        </button>
        <button
          onClick={() => setType('wifi')}
          className={`py-2 px-2 rounded-xl flex items-center justify-center gap-1.5 transition ${
            type === 'wifi' ? 'bg-white dark:bg-slate-700 text-emerald-600 dark:text-emerald-400 shadow-sm' : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          <Wifi className="w-3.5 h-3.5" />
          <span>Wi-Fi</span>
        </button>
        <button
          onClick={() => setType('upi')}
          className={`py-2 px-2 rounded-xl flex items-center justify-center gap-1.5 transition ${
            type === 'upi' ? 'bg-white dark:bg-slate-700 text-emerald-600 dark:text-emerald-400 shadow-sm' : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          <IndianRupee className="w-3.5 h-3.5" />
          <span>UPI</span>
        </button>
        <button
          onClick={() => setType('phone')}
          className={`py-2 px-2 rounded-xl flex items-center justify-center gap-1.5 transition ${
            type === 'phone' ? 'bg-white dark:bg-slate-700 text-emerald-600 dark:text-emerald-400 shadow-sm' : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          <Phone className="w-3.5 h-3.5" />
          <span>Call</span>
        </button>
        <button
          onClick={() => setType('email')}
          className={`py-2 px-2 rounded-xl flex items-center justify-center gap-1.5 transition ${
            type === 'email' ? 'bg-white dark:bg-slate-700 text-emerald-600 dark:text-emerald-400 shadow-sm' : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          <Mail className="w-3.5 h-3.5" />
          <span>Email</span>
        </button>
      </div>

      {/* Form Fields depending on mode */}
      <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3">
        {type === 'url' && (
          <div>
            <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
              Website URL
            </label>
            <input
              type="url"
              value={url}
              onChange={e => setUrl(e.target.value)}
              placeholder="https://example.com"
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-mono focus:ring-2 focus:ring-emerald-500"
            />
          </div>
        )}

        {type === 'text' && (
          <div>
            <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
              Plain Text or Message
            </label>
            <textarea
              rows={3}
              value={text}
              onChange={e => setText(e.target.value)}
              placeholder="Enter text..."
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-emerald-500"
            />
          </div>
        )}

        {type === 'wifi' && (
          <div className="space-y-3">
            <div>
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                Network Name (SSID)
              </label>
              <input
                type="text"
                value={wifiSsid}
                onChange={e => setWifiSsid(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100"
              />
            </div>
            <div>
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                Wi-Fi Password
              </label>
              <input
                type="text"
                value={wifiPass}
                onChange={e => setWifiPass(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-mono"
              />
            </div>
          </div>
        )}

        {type === 'upi' && (
          <div className="space-y-3">
            <div>
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                Virtual Payment Address (UPI ID)
              </label>
              <input
                type="text"
                value={upiId}
                onChange={e => setUpiId(e.target.value)}
                placeholder="name@okaxis"
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-mono"
              />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[11px] text-slate-500 block mb-1">Payee Name</label>
                <input
                  type="text"
                  value={upiName}
                  onChange={e => setUpiName(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                />
              </div>
              <div>
                <label className="text-[11px] text-slate-500 block mb-1">Amount (₹)</label>
                <input
                  type="number"
                  value={upiAmount}
                  onChange={e => setUpiAmount(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-mono"
                />
              </div>
            </div>
          </div>
        )}

        {type === 'phone' && (
          <div>
            <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
              Phone Number with Country Code
            </label>
            <input
              type="tel"
              value={phone}
              onChange={e => setPhone(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-mono"
            />
          </div>
        )}

        {type === 'email' && (
          <div>
            <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
              Email Address
            </label>
            <input
              type="email"
              value={email}
              onChange={e => setEmail(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-mono"
            />
          </div>
        )}

        {/* Colors */}
        <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800 text-xs">
          <div className="flex items-center gap-2">
            <span className="text-slate-500">QR Color:</span>
            <input
              type="color"
              value={fgColor}
              onChange={e => setFgColor(e.target.value)}
              className="w-7 h-7 rounded border-0 cursor-pointer"
            />
          </div>
          <div className="flex items-center gap-2">
            <span className="text-slate-500">Background:</span>
            <input
              type="color"
              value={bgColor}
              onChange={e => setBgColor(e.target.value)}
              className="w-7 h-7 rounded border-0 cursor-pointer"
            />
          </div>
        </div>
      </div>

      {/* Generated QR Display */}
      {qrDataUrl && (
        <div className="p-6 rounded-3xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 flex flex-col items-center justify-center space-y-4">
          <div className="p-3 bg-white rounded-2xl shadow-md border border-slate-200">
            <img src={qrDataUrl} alt="Generated QR" className="w-56 h-56 rounded-lg" />
          </div>

          <div className="grid grid-cols-2 gap-2 w-full max-w-xs">
            <button
              onClick={handleDownload}
              className="py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs flex items-center justify-center gap-2 shadow-sm transition"
            >
              <FileDown className="w-4 h-4" />
              {t('download')}
            </button>
            <button
              onClick={handleSaveToDocs}
              className="py-2.5 px-3 rounded-xl bg-white dark:bg-slate-800 hover:bg-slate-50 text-slate-800 dark:text-slate-200 font-semibold text-xs border border-slate-300 dark:border-slate-700 flex items-center justify-center gap-2 transition"
            >
              <FolderPlus className="w-4 h-4 text-emerald-600" />
              {t('saveToDocs')}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
