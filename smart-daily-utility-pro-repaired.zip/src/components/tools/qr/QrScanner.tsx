import React, { useState, useRef, useEffect, useCallback } from 'react';
import jsQR from 'jsqr';
import { useApp } from '../../../context/AppContext';
import {
  Camera,
  Upload,
  Copy,
  ExternalLink,
  FolderPlus,
  RefreshCw,
  Check,
  ScanLine,
  Loader2,
  AlertCircle,
  Share2,
  Globe,
  Wifi,
  User,
  Mail,
  Phone,
  ShieldCheck,
  ShieldAlert,
  Smartphone,
} from 'lucide-react';

export const QrScanner: React.FC = () => {
  const { t, addDocument, showToast, language } = useApp();
  const [isScanning, setIsScanning] = useState<boolean>(false);
  const [isStartingCamera, setIsStartingCamera] = useState<boolean>(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [scanResult, setScanResult] = useState<string>('');
  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');
  const [copied, setCopied] = useState<boolean>(false);

  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const animationFrameRef = useRef<number | null>(null);

  const stopCamera = useCallback(() => {
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
      animationFrameRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => {
        try {
          track.stop();
        } catch {
          // ignore
        }
      });
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    setIsScanning(false);
    setIsStartingCamera(false);
  }, []);

  const startBarcodeDetection = useCallback(() => {
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
      animationFrameRef.current = null;
    }

    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d', { willReadFrequently: true });

    const detect = () => {
      const video = videoRef.current;
      if (
        video &&
        video.readyState >= 2 &&
        video.videoWidth > 0 &&
        video.videoHeight > 0 &&
        ctx
      ) {
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const code = jsQR(imageData.data, imageData.width, imageData.height, {
          inversionAttempts: 'dontInvert',
        });

        if (code && code.data) {
          setScanResult(code.data);
          stopCamera();
          showToast(language === 'hi' ? 'क्यूआर कोड स्कैन हो गया!' : 'QR Code Scanned!');
          return;
        }
      }
      animationFrameRef.current = requestAnimationFrame(detect);
    };

    animationFrameRef.current = requestAnimationFrame(detect);
  }, [language, showToast, stopCamera]);

  // Start video stream with immediate display
  const startCamera = async (targetFacingMode?: 'environment' | 'user') => {
    const mode = targetFacingMode || facingMode || 'environment';
    setIsStartingCamera(true);
    setCameraError(null);

    // Stop existing stream if any
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => {
        try {
          t.stop();
        } catch {
          // ignore
        }
      });
      streamRef.current = null;
    }
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
      animationFrameRef.current = null;
    }

    if (!navigator?.mediaDevices?.getUserMedia) {
      const msg =
        language === 'hi'
          ? 'आपके ब्राउज़र में कैमरा समर्थित नहीं है या HTTPS आवश्यक है'
          : 'Camera API not supported or secure context (HTTPS) required';
      setCameraError(msg);
      showToast(msg);
      setIsStartingCamera(false);
      return;
    }

    try {
      let stream: MediaStream;
      try {
        // Preferred: rear camera with ideal facingMode
        stream = await navigator.mediaDevices.getUserMedia({
          video: {
            facingMode: { ideal: mode },
            width: { ideal: 1280 },
            height: { ideal: 720 },
          },
          audio: false,
        });
      } catch (constraintErr) {
        console.warn('Ideal constraint failed, retrying generic video constraint...', constraintErr);
        // Fallback constraint if device does not support ideal facingMode
        stream = await navigator.mediaDevices.getUserMedia({
          video: true,
          audio: false,
        });
      }

      streamRef.current = stream;

      const video = videoRef.current;
      if (video) {
        video.srcObject = stream;
        video.setAttribute('playsinline', 'true');
        video.setAttribute('webkit-playsinline', 'true');
        video.muted = true;

        // Wait for video metadata to be ready before calling play()
        if (video.readyState < 1) {
          await new Promise<void>((resolve) => {
            const onLoaded = () => {
              video.removeEventListener('loadedmetadata', onLoaded);
              resolve();
            };
            video.addEventListener('loadedmetadata', onLoaded);
            // Safety timeout after 1.5s
            setTimeout(resolve, 1500);
          });
        }

        try {
          await video.play();
        } catch (playErr) {
          console.warn('video.play() warning:', playErr);
        }
      }

      setIsScanning(true);
      setIsStartingCamera(false);
      startBarcodeDetection();
    } catch (err: unknown) {
      console.error('Camera access error:', err);
      const isDenied =
        err instanceof Error &&
        (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError');
      const errorMsg = isDenied
        ? language === 'hi'
          ? 'कैमरा अनुमति अस्वीकार कर दी गई। कृपया सेटिंग्स में अनुमति दें।'
          : 'Camera permission denied. Please allow camera access in browser settings.'
        : language === 'hi'
        ? 'कैमरा शुरू करने में समस्या आई।'
        : 'Could not access camera. Please check camera permissions or try uploading an image.';

      setCameraError(errorMsg);
      showToast(errorMsg);
      setIsScanning(false);
      setIsStartingCamera(false);
    }
  };

  const switchCamera = async () => {
    const nextMode = facingMode === 'environment' ? 'user' : 'environment';
    setFacingMode(nextMode);
    await startCamera(nextMode);
  };

  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, [stopCamera]);

  // QR Content Classification
  const parseQrContent = (text: string) => {
    const trimmed = text.trim();

    // 1. URL
    if (/^https?:\/\//i.test(trimmed)) {
      try {
        const u = new URL(trimmed);
        return {
          type: 'url' as const,
          label: 'Website URL',
          url: trimmed,
          domain: u.hostname,
          isHttps: u.protocol === 'https:',
        };
      } catch {
        // fallback to text
      }
    }

    // 2. Wi-Fi
    if (trimmed.startsWith('WIFI:')) {
      const ssidMatch = trimmed.match(/S:([^;]+)/i);
      const passMatch = trimmed.match(/P:([^;]*)/i);
      const typeMatch = trimmed.match(/T:([^;]*)/i);
      return {
        type: 'wifi' as const,
        label: 'Wi-Fi Network',
        ssid: ssidMatch ? ssidMatch[1] : 'Unknown Network',
        password: passMatch ? passMatch[1] : '',
        security: typeMatch ? typeMatch[1] : 'WPA',
      };
    }

    // 3. Contact / vCard
    if (/^BEGIN:VCARD/i.test(trimmed) || /^MECARD:/i.test(trimmed)) {
      const nameMatch = trimmed.match(/(?:FN:|N:)([^;\n\r]+)/i);
      const telMatch = trimmed.match(/TEL(?:;[^:]+)?:([^\n\r;]+)/i);
      const emailMatch = trimmed.match(/EMAIL(?:;[^:]+)?:([^\n\r;]+)/i);
      return {
        type: 'contact' as const,
        label: 'Contact Card',
        name: nameMatch ? nameMatch[1].replace(/;/g, ' ').trim() : 'Contact',
        phone: telMatch ? telMatch[1].trim() : '',
        email: emailMatch ? emailMatch[1].trim() : '',
      };
    }

    // 4. UPI Payment
    if (/^upi:\/\/pay/i.test(trimmed)) {
      const paMatch = trimmed.match(/[?&]pa=([^&]+)/i);
      const pnMatch = trimmed.match(/[?&]pn=([^&]+)/i);
      const amMatch = trimmed.match(/[?&]am=([^&]+)/i);
      return {
        type: 'upi' as const,
        label: 'UPI Payment',
        vpa: paMatch ? decodeURIComponent(paMatch[1]) : '',
        name: pnMatch ? decodeURIComponent(pnMatch[1]) : '',
        amount: amMatch ? decodeURIComponent(amMatch[1]) : '',
      };
    }

    // 5. Email
    if (/^mailto:/i.test(trimmed)) {
      const email = trimmed.replace(/^mailto:/i, '').split('?')[0];
      return {
        type: 'email' as const,
        label: 'Email Address',
        email,
      };
    }

    // 6. Phone
    if (/^tel:/i.test(trimmed)) {
      const phone = trimmed.replace(/^tel:/i, '');
      return {
        type: 'phone' as const,
        label: 'Phone Number',
        phone,
      };
    }

    return {
      type: 'text' as const,
      label: 'Plain Text',
    };
  };

  const parsedInfo = scanResult ? parseQrContent(scanResult) : null;

  // Handle Image File Upload for QR Scan
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || !e.target.files[0]) return;
    const file = e.target.files[0];
    const reader = new FileReader();

    reader.onload = () => {
      const img = new Image();
      img.src = reader.result as string;
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = img.naturalWidth;
        canvas.height = img.naturalHeight;
        const ctx = canvas.getContext('2d', { willReadFrequently: true });
        if (ctx) {
          ctx.drawImage(img, 0, 0);
          const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
          const code = jsQR(imageData.data, imageData.width, imageData.height);
          if (code && code.data) {
            setScanResult(code.data);
            showToast(language === 'hi' ? 'क्यूआर कोड स्कैन हो गया!' : 'QR Code Decoded!');
            return;
          }
        }
        showToast(language === 'hi' ? 'तस्वीर में कोई क्यूआर नहीं मिला' : 'No QR code found in this image');
      };
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(scanResult);
    setCopied(true);
    showToast(t('copied'));
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: 'Scanned QR Code',
        text: scanResult,
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(scanResult);
      showToast(language === 'hi' ? 'सामग्री कॉपी हो गई!' : 'Content copied to clipboard!');
    }
  };

  const handleSaveToDocs = () => {
    const textDataUrl = `data:text/plain;charset=utf-8,${encodeURIComponent(scanResult)}`;
    addDocument({
      name: `QR_${parsedInfo?.label.replace(/\s+/g, '_') || 'Code'}_${Date.now()}`,
      type: 'qr',
      size: scanResult.length,
      dataUrl: textDataUrl,
      category: 'QR Tools',
      tags: [parsedInfo?.label || 'QR', scanResult.substring(0, 20)],
    });
  };

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">
          {t('tool_qr_scanner')}
        </h3>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
          {t('tool_qr_scanner_desc')}
        </p>
      </div>

      {/* Camera Viewfinder */}
      <div className="relative w-full aspect-square max-w-sm mx-auto rounded-3xl overflow-hidden bg-slate-950 border border-slate-800 shadow-xl flex items-center justify-center">
        {/* Video element is permanently mounted so ref is immediately ready on first click */}
        <video
          ref={videoRef}
          playsInline
          muted
          autoPlay
          className={`w-full h-full object-cover transition-opacity duration-200 ${
            isScanning ? 'opacity-100' : 'hidden opacity-0'
          }`}
        />

        {isScanning ? (
          <>
            {/* Viewfinder Target & Laser Line */}
            <div className="absolute inset-8 border-2 border-emerald-400/80 rounded-2xl pointer-events-none flex items-center justify-center">
              <div className="w-full h-0.5 bg-emerald-400 shadow-[0_0_12px_#34d399] animate-pulse" />
            </div>

            <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between z-10">
              <button
                onClick={switchCamera}
                className="p-2.5 rounded-full bg-slate-900/80 text-white backdrop-blur-md hover:bg-slate-800 transition active:scale-95 flex items-center gap-1.5 text-xs px-3.5 shadow-lg"
                title="Switch Camera"
              >
                <RefreshCw className="w-4 h-4" />
                <span className="hidden sm:inline">
                  {facingMode === 'environment' ? 'Rear' : 'Front'}
                </span>
              </button>
              <button
                onClick={stopCamera}
                className="px-4 py-2 rounded-full bg-rose-600/90 hover:bg-rose-600 text-white font-semibold text-xs backdrop-blur-md transition active:scale-95 shadow-lg"
              >
                {language === 'hi' ? 'रोकें' : 'Stop'}
              </button>
            </div>
          </>
        ) : (
          <div className="flex flex-col items-center justify-center p-6 text-center text-slate-400 space-y-3 z-10">
            <div className="w-16 h-16 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-center text-emerald-400 shadow-inner">
              {isStartingCamera ? (
                <Loader2 className="w-8 h-8 animate-spin text-emerald-400" />
              ) : (
                <Camera className="w-8 h-8" />
              )}
            </div>
            <div>
              <span className="text-sm font-semibold text-slate-200 block">
                {language === 'hi' ? 'लाइव कैमरा स्कैनर' : 'Live Camera Scanner'}
              </span>
              <span className="text-xs text-slate-500 mt-0.5 block">
                {isStartingCamera
                  ? language === 'hi'
                    ? 'कैमरा शुरू हो रहा है...'
                    : 'Starting camera...'
                  : language === 'hi'
                  ? 'कागज़, स्क्रीन या बिल पर क्यूआर कोड दिखाएं'
                  : 'Point at any QR code on paper, screen, or invoice'}
              </span>
            </div>

            {cameraError && (
              <div className="px-3 py-1.5 rounded-xl bg-rose-950/60 border border-rose-800/80 text-rose-300 text-[11px] max-w-xs flex items-center gap-1.5 text-left">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{cameraError}</span>
              </div>
            )}

            <button
              onClick={() => startCamera()}
              disabled={isStartingCamera}
              className="py-2.5 px-5 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-bold text-xs shadow-md transition active:scale-95 flex items-center gap-2"
            >
              {isStartingCamera ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>{language === 'hi' ? 'प्रतीक्षा करें...' : 'Starting...'}</span>
                </>
              ) : (
                <>
                  <ScanLine className="w-4 h-4" />
                  <span>{language === 'hi' ? 'कैमरा शुरू करें' : 'Start Camera'}</span>
                </>
              )}
            </button>
          </div>
        )}
      </div>

      {/* Alternative: Image Upload Dropzone */}
      <div className="relative border border-dashed border-slate-300 dark:border-slate-700 hover:border-emerald-500 rounded-2xl p-4 text-center bg-white dark:bg-slate-900 transition">
        <input
          type="file"
          accept="image/*"
          onChange={handleFileUpload}
          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
        />
        <div className="flex items-center justify-center gap-2 text-xs font-semibold text-slate-700 dark:text-slate-300">
          <Upload className="w-4 h-4 text-emerald-500" />
          <span>{language === 'hi' ? 'या फोटो से क्यूआर स्कैन करें' : 'Or upload QR image / screenshot'}</span>
        </div>
      </div>

      {/* Scanned Result Card */}
      {scanResult && parsedInfo && (
        <div className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xl space-y-3.5 animate-in fade-in">
          {/* Header with Type Badge */}
          <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-2.5">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
                {parsedInfo.type === 'url' && <Globe className="w-4 h-4" />}
                {parsedInfo.type === 'wifi' && <Wifi className="w-4 h-4" />}
                {parsedInfo.type === 'contact' && <User className="w-4 h-4" />}
                {parsedInfo.type === 'upi' && <Smartphone className="w-4 h-4" />}
                {parsedInfo.type === 'email' && <Mail className="w-4 h-4" />}
                {parsedInfo.type === 'phone' && <Phone className="w-4 h-4" />}
                {parsedInfo.type === 'text' && <ScanLine className="w-4 h-4" />}
              </div>
              <div>
                <span className="text-xs font-bold text-slate-900 dark:text-slate-100 block">
                  {parsedInfo.label}
                </span>
                <span className="text-[10px] text-slate-400">
                  {scanResult.length} characters
                </span>
              </div>
            </div>

            <button
              onClick={() => {
                setScanResult('');
                startCamera();
              }}
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-slate-500 hover:text-emerald-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs transition"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>{language === 'hi' ? 'फिर स्कैन करें' : 'Scan Again'}</span>
            </button>
          </div>

          {/* Wi-Fi Preview */}
          {parsedInfo.type === 'wifi' && (
            <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 space-y-1.5 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-slate-500 text-[11px]">Network Name (SSID):</span>
                <strong className="font-mono text-slate-900 dark:text-slate-100">{parsedInfo.ssid}</strong>
              </div>
              {parsedInfo.password && (
                <div className="flex items-center justify-between">
                  <span className="text-slate-500 text-[11px]">Password:</span>
                  <strong className="font-mono text-emerald-600 dark:text-emerald-400">{parsedInfo.password}</strong>
                </div>
              )}
              <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1">
                <span>Security: {parsedInfo.security}</span>
                {parsedInfo.password && (
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(parsedInfo.password || '');
                      showToast(language === 'hi' ? 'पासवर्ड कॉपी हो गया!' : 'Wi-Fi Password Copied!');
                    }}
                    className="text-blue-600 dark:text-blue-400 font-semibold hover:underline"
                  >
                    Copy Password
                  </button>
                )}
              </div>
            </div>
          )}

          {/* Contact Preview */}
          {parsedInfo.type === 'contact' && (
            <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 space-y-1 text-xs">
              <div className="font-bold text-slate-900 dark:text-slate-100">{parsedInfo.name}</div>
              {parsedInfo.phone && <div className="text-slate-500 font-mono text-[11px]">📞 {parsedInfo.phone}</div>}
              {parsedInfo.email && <div className="text-slate-500 text-[11px]">✉️ {parsedInfo.email}</div>}
            </div>
          )}

          {/* UPI Payment Preview */}
          {parsedInfo.type === 'upi' && (
            <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 space-y-1 text-xs">
              <div className="font-bold text-slate-900 dark:text-slate-100">{parsedInfo.name || 'UPI Payee'}</div>
              <div className="font-mono text-slate-500 text-[11px]">{parsedInfo.vpa}</div>
              {parsedInfo.amount && (
                <div className="text-emerald-600 font-bold text-sm">₹ {parsedInfo.amount}</div>
              )}
            </div>
          )}

          {/* Raw Decoded Content Box */}
          <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 font-mono text-xs break-all text-slate-800 dark:text-slate-200 max-h-28 overflow-y-auto select-all">
            {scanResult}
          </div>

          {/* Safety check for URLs */}
          {parsedInfo.type === 'url' && (
            <div className="p-2.5 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/60 text-[11px] text-amber-800 dark:text-amber-300 flex items-start gap-2">
              <ShieldAlert className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              <div>
                <strong>{language === 'hi' ? 'सुरक्षा सूचना:' : 'Security Notice:'}</strong>{' '}
                {language === 'hi'
                  ? 'अज्ञात वेबसाइट लिंक खोलने से पहले डोमेन की पुष्टि करें। लिंक अपने आप नहीं खोला जाता।'
                  : `Destination domain: ${parsedInfo.domain}. Links are never opened automatically.`}
              </div>
            </div>
          )}

          {/* Action Buttons: Open, Copy, Share, Save */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1">
            {/* 1. Open Button (Context-Sensitive) */}
            {parsedInfo.type === 'url' && (
              <a
                href={parsedInfo.url}
                target="_blank"
                rel="noreferrer noopener"
                className="py-2.5 px-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs flex items-center justify-center gap-1.5 shadow-sm transition active:scale-95"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                <span>Open Link</span>
              </a>
            )}

            {parsedInfo.type === 'phone' && (
              <a
                href={`tel:${parsedInfo.phone}`}
                className="py-2.5 px-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs flex items-center justify-center gap-1.5 shadow-sm transition active:scale-95"
              >
                <Phone className="w-3.5 h-3.5" />
                <span>Call Phone</span>
              </a>
            )}

            {parsedInfo.type === 'email' && (
              <a
                href={`mailto:${parsedInfo.email}`}
                className="py-2.5 px-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs flex items-center justify-center gap-1.5 shadow-sm transition active:scale-95"
              >
                <Mail className="w-3.5 h-3.5" />
                <span>Send Email</span>
              </a>
            )}

            {parsedInfo.type === 'upi' && (
              <a
                href={scanResult}
                className="py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs flex items-center justify-center gap-1.5 shadow-sm transition active:scale-95"
              >
                <Smartphone className="w-3.5 h-3.5" />
                <span>Pay via UPI</span>
              </a>
            )}

            {parsedInfo.type === 'wifi' && (
              <button
                onClick={() => {
                  navigator.clipboard.writeText(parsedInfo.password || parsedInfo.ssid);
                  showToast(language === 'hi' ? 'वाई-फाई विवरण कॉपी हो गया' : 'Wi-Fi credentials copied');
                }}
                className="py-2.5 px-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs flex items-center justify-center gap-1.5 shadow-sm transition active:scale-95"
              >
                <Wifi className="w-3.5 h-3.5" />
                <span>Copy Pass</span>
              </button>
            )}

            {parsedInfo.type === 'text' && (
              <button
                onClick={handleCopy}
                className="py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs flex items-center justify-center gap-1.5 shadow-sm transition active:scale-95"
              >
                {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Copy Text'}</span>
              </button>
            )}

            {/* 2. Copy Button */}
            {parsedInfo.type !== 'text' && (
              <button
                onClick={handleCopy}
                className="py-2.5 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 font-semibold text-xs flex items-center justify-center gap-1.5 transition active:scale-95"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Copy'}</span>
              </button>
            )}

            {/* 3. Share Button */}
            <button
              onClick={handleShare}
              className="py-2.5 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 font-semibold text-xs flex items-center justify-center gap-1.5 transition active:scale-95"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span>Share</span>
            </button>

            {/* 4. Save to My Documents Button */}
            <button
              onClick={handleSaveToDocs}
              className="py-2.5 px-3 rounded-xl border border-slate-300 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-200 font-semibold text-xs flex items-center justify-center gap-1.5 transition active:scale-95"
            >
              <FolderPlus className="w-3.5 h-3.5 text-emerald-600" />
              <span>Save</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
