import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../../../context/AppContext';
import {
  Upload,
  Crop as CropIcon,
  RotateCw,
  FlipHorizontal,
  FileDown,
  FolderPlus,
  Check,
} from 'lucide-react';

export const ImageCropper: React.FC = () => {
  const { t, addDocument, showToast, language } = useApp();
  const [file, setFile] = useState<File | null>(null);
  const [dataUrl, setDataUrl] = useState<string>('');
  const [rotation, setRotation] = useState<number>(0);
  const [flipH, setFlipH] = useState<boolean>(false);
  const [aspectRatio, setAspectRatio] = useState<'free' | '1:1' | '4:3' | '16:9' | '3:4'>('free');
  
  // Crop Box normalized 0-1
  const [cropBox, setCropBox] = useState<{ x: number; y: number; w: number; h: number }>({
    x: 0.1,
    y: 0.1,
    w: 0.8,
    h: 0.8,
  });

  const [croppedDataUrl, setCroppedDataUrl] = useState<string>('');
  const containerRef = useRef<HTMLDivElement>(null);

  const handleImageSelected = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || !e.target.files[0]) return;
    const selectedFile = e.target.files[0];
    setFile(selectedFile);

    const reader = new FileReader();
    reader.onload = () => {
      setDataUrl(reader.result as string);
      setCroppedDataUrl('');
      setRotation(0);
      setFlipH(false);
      setCropBox({ x: 0.05, y: 0.05, w: 0.9, h: 0.9 });
    };
    reader.readAsDataURL(selectedFile);
    e.target.value = '';
  };

  const applyAspectRatio = (ratio: 'free' | '1:1' | '4:3' | '16:9' | '3:4') => {
    setAspectRatio(ratio);
    if (ratio === '1:1') {
      setCropBox({ x: 0.15, y: 0.15, w: 0.7, h: 0.7 });
    } else if (ratio === '4:3') {
      setCropBox({ x: 0.1, y: 0.2, w: 0.8, h: 0.6 });
    } else if (ratio === '16:9') {
      setCropBox({ x: 0.05, y: 0.25, w: 0.9, h: 0.5 });
    } else if (ratio === '3:4') {
      setCropBox({ x: 0.2, y: 0.1, w: 0.6, h: 0.8 });
    } else {
      setCropBox({ x: 0.05, y: 0.05, w: 0.9, h: 0.9 });
    }
  };

  const executeCrop = () => {
    if (!dataUrl) return;
    const img = new Image();
    img.src = dataUrl;
    img.onload = () => {
      const srcCanvas = document.createElement('canvas');
      // If rotated 90 or 270, swap dimensions
      const isSwapped = rotation % 180 !== 0;
      srcCanvas.width = isSwapped ? img.naturalHeight : img.naturalWidth;
      srcCanvas.height = isSwapped ? img.naturalWidth : img.naturalHeight;

      const sCtx = srcCanvas.getContext('2d')!;
      sCtx.translate(srcCanvas.width / 2, srcCanvas.height / 2);
      sCtx.rotate((rotation * Math.PI) / 180);
      sCtx.scale(flipH ? -1 : 1, 1);
      sCtx.drawImage(img, -img.naturalWidth / 2, -img.naturalHeight / 2);

      // Now crop from srcCanvas
      const cropX = Math.round(cropBox.x * srcCanvas.width);
      const cropY = Math.round(cropBox.y * srcCanvas.height);
      const cropW = Math.max(10, Math.round(cropBox.w * srcCanvas.width));
      const cropH = Math.max(10, Math.round(cropBox.h * srcCanvas.height));

      const outCanvas = document.createElement('canvas');
      outCanvas.width = cropW;
      outCanvas.height = cropH;
      const outCtx = outCanvas.getContext('2d')!;
      outCtx.drawImage(srcCanvas, cropX, cropY, cropW, cropH, 0, 0, cropW, cropH);

      const res = outCanvas.toDataURL('image/png', 0.95);
      setCroppedDataUrl(res);
      showToast(language === 'hi' ? 'फोटो सफलतापूर्वक क्रॉप हो गई!' : 'Image Cropped Successfully!');
    };
  };

  const handleDownload = () => {
    if (!croppedDataUrl || !file) return;
    const a = document.createElement('a');
    a.href = croppedDataUrl;
    a.download = `cropped_${file.name.replace(/\.[^/.]+$/, '')}.png`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleSaveToDocs = () => {
    if (!croppedDataUrl || !file) return;
    addDocument({
      name: `cropped_${file.name}`,
      type: 'image',
      size: Math.round((croppedDataUrl.length * 3) / 4),
      dataUrl: croppedDataUrl,
      category: 'Image Tools',
      tags: ['Cropped', aspectRatio],
    });
  };

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">
          {t('tool_img_cropper')}
        </h3>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
          {t('tool_img_cropper_desc')}
        </p>
      </div>

      {!file ? (
        <div className="relative border-2 border-dashed border-slate-300 dark:border-slate-700 hover:border-indigo-500 rounded-3xl p-6 sm:p-8 text-center bg-white dark:bg-slate-900 transition-colors">
          <input
            type="file"
            accept="image/*"
            onChange={handleImageSelected}
            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
          />
          <div className="flex flex-col items-center justify-center">
            <div className="w-12 h-12 rounded-2xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center mb-3">
              <Upload className="w-6 h-6" />
            </div>
            <span className="text-sm font-semibold text-slate-800 dark:text-slate-200">
              {language === 'hi' ? 'फोटो चुनें जिसे क्रॉप करना है' : 'Select image to crop'}
            </span>
            <span className="text-xs text-slate-400 mt-1">
              Supports aspect presets, rotation and flipping
            </span>
          </div>
        </div>
      ) : (
        <div className="space-y-4">
          {/* Controls Bar */}
          <div className="flex flex-wrap items-center justify-between gap-2 p-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
            {/* Presets */}
            <div className="flex items-center gap-1 overflow-x-auto text-xs">
              {(['free', '1:1', '4:3', '16:9', '3:4'] as const).map(ratio => (
                <button
                  key={ratio}
                  type="button"
                  onClick={() => applyAspectRatio(ratio)}
                  className={`px-2.5 py-1 rounded-lg font-semibold transition ${
                    aspectRatio === ratio
                      ? 'bg-indigo-600 text-white'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                  }`}
                >
                  {ratio === 'free' ? 'Free' : ratio}
                </button>
              ))}
            </div>

            {/* Transform buttons */}
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => setRotation(r => (r + 90) % 360)}
                className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-200 transition"
                title="Rotate 90°"
              >
                <RotateCw className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => setFlipH(f => !f)}
                className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-200 transition"
                title="Flip Horizontal"
              >
                <FlipHorizontal className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Interactive Crop Viewport */}
          <div
            ref={containerRef}
            className="relative w-full max-h-80 min-h-60 rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-slate-950 flex items-center justify-center p-2 select-none"
          >
            <img
              src={dataUrl}
              alt="Crop target"
              className="max-h-72 max-w-full object-contain transition-transform pointer-events-none"
              style={{
                transform: `rotate(${rotation}deg) scaleX(${flipH ? -1 : 1})`,
              }}
            />

            {/* Crop Overlay Mask Box */}
            <div
              className="absolute border-2 border-indigo-400 bg-indigo-500/15 shadow-2xl pointer-events-none"
              style={{
                left: `${cropBox.x * 100}%`,
                top: `${cropBox.y * 100}%`,
                width: `${cropBox.w * 100}%`,
                height: `${cropBox.h * 100}%`,
              }}
            >
              {/* Rule of Thirds Lines */}
              <div className="absolute inset-0 grid grid-cols-3 grid-rows-3 pointer-events-none opacity-40">
                <div className="border-r border-b border-white" />
                <div className="border-r border-b border-white" />
                <div className="border-b border-white" />
                <div className="border-r border-b border-white" />
                <div className="border-r border-b border-white" />
                <div className="border-b border-white" />
                <div className="border-r border-white" />
                <div className="border-r border-white" />
                <div />
              </div>
            </div>
          </div>

          {/* Precision Crop Adjustment Sliders */}
          <div className="p-3.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3">
            <div className="flex items-center justify-between text-xs font-semibold text-slate-700 dark:text-slate-300">
              <span>Crop Area Size</span>
              <span className="font-mono text-indigo-600 dark:text-indigo-400 font-bold">
                {Math.round(cropBox.w * 100)}% × {Math.round(cropBox.h * 100)}%
              </span>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div>
                <label className="text-[11px] text-slate-500 block mb-1">Horizontal Position</label>
                <input
                  type="range"
                  min="0"
                  max={Math.max(0, 100 - Math.round(cropBox.w * 100))}
                  value={Math.round(cropBox.x * 100)}
                  onChange={e => {
                    const newX = parseInt(e.target.value, 10) / 100;
                    setCropBox(prev => ({ ...prev, x: newX }));
                  }}
                  className="w-full accent-indigo-600"
                />
              </div>

              <div>
                <label className="text-[11px] text-slate-500 block mb-1">Vertical Position</label>
                <input
                  type="range"
                  min="0"
                  max={Math.max(0, 100 - Math.round(cropBox.h * 100))}
                  value={Math.round(cropBox.y * 100)}
                  onChange={e => {
                    const newY = parseInt(e.target.value, 10) / 100;
                    setCropBox(prev => ({ ...prev, y: newY }));
                  }}
                  className="w-full accent-indigo-600"
                />
              </div>
            </div>
          </div>

          <button
            onClick={executeCrop}
            className="w-full py-3.5 px-4 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-sm shadow-md flex items-center justify-center gap-2 active:scale-98 transition-transform"
          >
            <CropIcon className="w-4 h-4" />
            <span>{language === 'hi' ? 'क्रॉप करें' : 'Apply Crop'}</span>
          </button>

          {/* Cropped Output */}
          {croppedDataUrl && (
            <div className="space-y-3 pt-2">
              <div className="relative rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-slate-100 dark:bg-slate-950 max-h-64 flex items-center justify-center p-2">
                <img
                  src={croppedDataUrl}
                  alt="Cropped output"
                  className="max-h-60 object-contain rounded-xl"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={handleDownload}
                  className="py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs flex items-center justify-center gap-2 shadow-sm transition"
                >
                  <FileDown className="w-4 h-4" />
                  {t('download')}
                </button>
                <button
                  onClick={handleSaveToDocs}
                  className="py-2.5 px-3 rounded-xl bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 font-semibold text-xs border border-slate-200 dark:border-slate-700 flex items-center justify-center gap-2 transition"
                >
                  <FolderPlus className="w-4 h-4 text-indigo-600" />
                  {t('saveToDocs')}
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
