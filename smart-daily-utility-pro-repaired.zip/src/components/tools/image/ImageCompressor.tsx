import React, { useState, useEffect } from 'react';
import { useApp } from '../../../context/AppContext';
import {
  Upload,
  Shrink,
  FileDown,
  FolderPlus,
  Loader2,
  TrendingDown,
  Sliders,
} from 'lucide-react';

export const ImageCompressor: React.FC = () => {
  const { t, addDocument, showToast, language } = useApp();
  const [file, setFile] = useState<File | null>(null);
  const [originalDataUrl, setOriginalDataUrl] = useState<string>('');
  const [quality, setQuality] = useState<number>(70);
  const [format, setFormat] = useState<'image/jpeg' | 'image/webp'>('image/jpeg');
  const [compressedDataUrl, setCompressedDataUrl] = useState<string>('');
  const [compressedSize, setCompressedSize] = useState<number>(0);
  const [isProcessing, setIsProcessing] = useState(false);

  const handleImageSelected = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || !e.target.files[0]) return;
    const selectedFile = e.target.files[0];
    setFile(selectedFile);

    const reader = new FileReader();
    reader.onload = () => {
      setOriginalDataUrl(reader.result as string);
    };
    reader.readAsDataURL(selectedFile);
    e.target.value = '';
  };

  const compressImage = (dataUrl: string, q: number, fmt: string) => {
    setIsProcessing(true);
    const img = new Image();
    img.src = dataUrl;
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = img.naturalWidth;
      canvas.height = img.naturalHeight;
      const ctx = canvas.getContext('2d')!;

      if (fmt === 'image/jpeg') {
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
      }
      ctx.drawImage(img, 0, 0);

      const result = canvas.toDataURL(fmt, q / 100);
      setCompressedDataUrl(result);

      // Estimate byte length from base64
      const head = `data:${fmt};base64,`;
      const sizeBytes = Math.round(((result.length - head.length) * 3) / 4);
      setCompressedSize(sizeBytes);
      setIsProcessing(false);
    };
  };

  useEffect(() => {
    if (originalDataUrl) {
      compressImage(originalDataUrl, quality, format);
    }
  }, [originalDataUrl, quality, format]);

  const handleDownload = () => {
    if (!compressedDataUrl || !file) return;
    const a = document.createElement('a');
    a.href = compressedDataUrl;
    const ext = format === 'image/webp' ? 'webp' : 'jpg';
    a.download = `compressed_${file.name.replace(/\.[^/.]+$/, '')}.${ext}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleSaveToDocs = () => {
    if (!compressedDataUrl || !file) return;
    addDocument({
      name: `compressed_${file.name}`,
      type: 'image',
      size: compressedSize,
      dataUrl: compressedDataUrl,
      category: 'Image Tools',
      tags: ['Compressor', `${quality}% quality`],
    });
  };

  const originalKb = file ? file.size / 1024 : 0;
  const compressedKb = compressedSize / 1024;
  const savedPercent = originalKb > 0
    ? Math.max(0, Math.round(((originalKb - compressedKb) / originalKb) * 100))
    : 0;

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">
          {t('tool_img_compressor')}
        </h3>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
          {t('tool_img_compressor_desc')}
        </p>
      </div>

      {!file ? (
        <div className="relative border-2 border-dashed border-slate-300 dark:border-slate-700 hover:border-indigo-500 rounded-3xl p-6 sm:p-8 text-center bg-white dark:bg-slate-900 transition-colors">
          <input
            type="file"
            accept="image/*"
            onChange={handleImageSelected}
            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
          />
          <div className="flex flex-col items-center justify-center">
            <div className="w-12 h-12 rounded-2xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center mb-3">
              <Upload className="w-6 h-6" />
            </div>
            <span className="text-sm font-semibold text-slate-800 dark:text-slate-200">
              {language === 'hi' ? 'फोटो चुनें जिसे कंप्रेस करना है' : 'Select image to compress'}
            </span>
            <span className="text-xs text-slate-400 mt-1">
              JPG, PNG, WEBP, HEIC supported
            </span>
          </div>
        </div>
      ) : (
        <div className="space-y-4">
          {/* Controls */}
          <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                Quality: <strong className="font-mono text-indigo-600 dark:text-indigo-400">{quality}%</strong>
              </span>
              <div className="flex gap-1 text-xs">
                {(['image/jpeg', 'image/webp'] as const).map(fmt => (
                  <button
                    key={fmt}
                    onClick={() => setFormat(fmt)}
                    className={`px-2.5 py-1 rounded-lg font-medium transition ${
                      format === fmt
                        ? 'bg-indigo-600 text-white'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    {fmt === 'image/jpeg' ? 'JPG' : 'WEBP'}
                  </button>
                ))}
              </div>
            </div>

            <input
              type="range"
              min="10"
              max="95"
              step="5"
              value={quality}
              onChange={e => setQuality(parseInt(e.target.value, 10))}
              className="w-full accent-indigo-600"
            />

            <div className="flex items-center justify-between text-[11px] text-slate-400">
              <span>Smallest Size (10%)</span>
              <span>Balanced (70%)</span>
              <span>Maximum Clarity (95%)</span>
            </div>
          </div>

          {/* Size Comparison Card */}
          <div className="grid grid-cols-2 gap-3 p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-center">
            <div>
              <span className="text-[11px] text-slate-500 block mb-0.5">Original Size</span>
              <span className="text-base font-bold font-mono text-slate-800 dark:text-slate-200">
                {originalKb.toFixed(1)} KB
              </span>
            </div>
            <div>
              <span className="text-[11px] text-emerald-600 dark:text-emerald-400 font-semibold block mb-0.5">
                Compressed ({savedPercent}% Saved)
              </span>
              <span className="text-base font-bold font-mono text-emerald-600 dark:text-emerald-400">
                {compressedKb.toFixed(1)} KB
              </span>
            </div>
          </div>

          {/* Image Preview */}
          <div className="relative rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-slate-100 dark:bg-slate-950 max-h-72 flex items-center justify-center p-2">
            {isProcessing ? (
              <Loader2 className="w-6 h-6 animate-spin text-indigo-600 my-12" />
            ) : (
              <img
                src={compressedDataUrl || originalDataUrl}
                alt="Compressed preview"
                className="max-h-64 object-contain rounded-xl"
              />
            )}
          </div>

          {/* Actions */}
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={handleDownload}
              className="py-3 px-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs flex items-center justify-center gap-2 shadow-sm transition active:scale-98"
            >
              <FileDown className="w-4 h-4" />
              {t('download')}
            </button>
            <button
              onClick={handleSaveToDocs}
              className="py-3 px-3 rounded-xl bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 font-semibold text-xs border border-slate-200 dark:border-slate-700 flex items-center justify-center gap-2 transition"
            >
              <FolderPlus className="w-4 h-4 text-indigo-600" />
              {t('saveToDocs')}
            </button>
          </div>

          <div className="text-center">
            <button
              onClick={() => {
                setFile(null);
                setOriginalDataUrl('');
                setCompressedDataUrl('');
              }}
              className="text-xs text-slate-500 hover:underline"
            >
              Choose another image
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
