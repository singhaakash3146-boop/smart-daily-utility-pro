import React, { useState, useEffect } from 'react';
import { useApp } from '../../../context/AppContext';
import {
  Upload,
  Maximize2,
  FileDown,
  FolderPlus,
  Lock,
  Unlock,
  Check,
} from 'lucide-react';

export const ImageResizer: React.FC = () => {
  const { t, addDocument, showToast, language } = useApp();
  const [file, setFile] = useState<File | null>(null);
  const [dataUrl, setDataUrl] = useState<string>('');
  const [originalWidth, setOriginalWidth] = useState<number>(0);
  const [originalHeight, setOriginalHeight] = useState<number>(0);
  const [targetWidth, setTargetWidth] = useState<number>(0);
  const [targetHeight, setTargetHeight] = useState<number>(0);
  const [lockAspectRatio, setLockAspectRatio] = useState<boolean>(true);
  const [resizedDataUrl, setResizedDataUrl] = useState<string>('');

  const handleImageSelected = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || !e.target.files[0]) return;
    const selectedFile = e.target.files[0];
    setFile(selectedFile);

    const reader = new FileReader();
    reader.onload = () => {
      const url = reader.result as string;
      setDataUrl(url);

      const img = new Image();
      img.src = url;
      img.onload = () => {
        setOriginalWidth(img.naturalWidth);
        setOriginalHeight(img.naturalHeight);
        setTargetWidth(img.naturalWidth);
        setTargetHeight(img.naturalHeight);
      };
    };
    reader.readAsDataURL(selectedFile);
    e.target.value = '';
  };

  const handleWidthChange = (val: number) => {
    setTargetWidth(val);
    if (lockAspectRatio && originalWidth > 0) {
      const ratio = originalHeight / originalWidth;
      setTargetHeight(Math.round(val * ratio));
    }
  };

  const handleHeightChange = (val: number) => {
    setTargetHeight(val);
    if (lockAspectRatio && originalHeight > 0) {
      const ratio = originalWidth / originalHeight;
      setTargetWidth(Math.round(val * ratio));
    }
  };

  const applyScale = (percent: number) => {
    if (originalWidth > 0 && originalHeight > 0) {
      const w = Math.round((originalWidth * percent) / 100);
      const h = Math.round((originalHeight * percent) / 100);
      setTargetWidth(w);
      setTargetHeight(h);
    }
  };

  const generateResized = () => {
    if (!dataUrl || targetWidth <= 0 || targetHeight <= 0) return;
    const img = new Image();
    img.src = dataUrl;
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = targetWidth;
      canvas.height = targetHeight;
      const ctx = canvas.getContext('2d')!;
      ctx.drawImage(img, 0, 0, targetWidth, targetHeight);

      const result = canvas.toDataURL(file?.type || 'image/png', 0.92);
      setResizedDataUrl(result);
      showToast(language === 'hi' ? 'इमेज साइज बदल गया!' : 'Image Resized Successfully!');
    };
  };

  const handleDownload = () => {
    if (!resizedDataUrl || !file) return;
    const a = document.createElement('a');
    a.href = resizedDataUrl;
    a.download = `resized_${targetWidth}x${targetHeight}_${file.name}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleSaveToDocs = () => {
    if (!resizedDataUrl || !file) return;
    addDocument({
      name: `resized_${targetWidth}x${targetHeight}_${file.name}`,
      type: 'image',
      size: Math.round((resizedDataUrl.length * 3) / 4),
      dataUrl: resizedDataUrl,
      category: 'Image Tools',
      tags: ['Resized', `${targetWidth}x${targetHeight}px`],
    });
  };

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">
          {t('tool_img_resizer')}
        </h3>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
          {t('tool_img_resizer_desc')}
        </p>
      </div>

      {!file ? (
        <div className="relative border-2 border-dashed border-slate-300 dark:border-slate-700 hover:border-indigo-500 rounded-3xl p-6 sm:p-8 text-center bg-white dark:bg-slate-900 transition-colors">
          <input
            type="file"
            accept="image/*"
            onChange={handleImageSelected}
            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
          />
          <div className="flex flex-col items-center justify-center">
            <div className="w-12 h-12 rounded-2xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center mb-3">
              <Upload className="w-6 h-6" />
            </div>
            <span className="text-sm font-semibold text-slate-800 dark:text-slate-200">
              {language === 'hi' ? 'फोटो चुनें जिसका आकार बदलना है' : 'Select image to resize'}
            </span>
            <span className="text-xs text-slate-400 mt-1">
              Supports exact pixel dimension scaling
            </span>
          </div>
        </div>
      ) : (
        <div className="space-y-4">
          {/* Quick presets */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
            <span className="text-slate-400 text-xs shrink-0">Scale:</span>
            {[25, 50, 75, 100].map(pct => (
              <button
                key={pct}
                onClick={() => applyScale(pct)}
                className="px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 font-semibold text-slate-700 dark:text-slate-300 transition shrink-0"
              >
                {pct}%
              </button>
            ))}
          </div>

          {/* Width / Height inputs */}
          <div className="grid grid-cols-[1fr,auto,1fr] items-center gap-3 p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
            <div>
              <label className="text-[11px] font-semibold text-slate-500 block mb-1">
                Width (px)
              </label>
              <input
                type="number"
                value={targetWidth || ''}
                onChange={e => handleWidthChange(parseInt(e.target.value, 10) || 0)}
                className="w-full px-3 py-2 text-sm rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-mono font-bold focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <button
              type="button"
              onClick={() => setLockAspectRatio(!lockAspectRatio)}
              className={`p-2.5 rounded-xl border mt-5 transition ${
                lockAspectRatio
                  ? 'bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 border-indigo-200 dark:border-indigo-800'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-400 border-slate-300 dark:border-slate-700'
              }`}
              title={lockAspectRatio ? 'Aspect ratio locked' : 'Aspect ratio unlocked'}
            >
              {lockAspectRatio ? <Lock className="w-4 h-4" /> : <Unlock className="w-4 h-4" />}
            </button>

            <div>
              <label className="text-[11px] font-semibold text-slate-500 block mb-1">
                Height (px)
              </label>
              <input
                type="number"
                value={targetHeight || ''}
                onChange={e => handleHeightChange(parseInt(e.target.value, 10) || 0)}
                className="w-full px-3 py-2 text-sm rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-mono font-bold focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>

          <button
            onClick={generateResized}
            className="w-full py-3.5 px-4 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-sm shadow-md flex items-center justify-center gap-2 active:scale-98 transition-transform"
          >
            <Maximize2 className="w-4 h-4" />
            <span>{language === 'hi' ? 'रीसाइज लागू करें' : `Apply Resize (${targetWidth} × ${targetHeight})`}</span>
          </button>

          {/* Result preview */}
          {resizedDataUrl && (
            <div className="space-y-3 pt-2">
              <div className="relative rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-slate-100 dark:bg-slate-950 max-h-64 flex items-center justify-center p-2">
                <img
                  src={resizedDataUrl}
                  alt="Resized output"
                  className="max-h-60 object-contain rounded-xl"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={handleDownload}
                  className="py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs flex items-center justify-center gap-2 shadow-sm transition"
                >
                  <FileDown className="w-4 h-4" />
                  {t('download')}
                </button>
                <button
                  onClick={handleSaveToDocs}
                  className="py-2.5 px-3 rounded-xl bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 font-semibold text-xs border border-slate-200 dark:border-slate-700 flex items-center justify-center gap-2 transition"
                >
                  <FolderPlus className="w-4 h-4 text-indigo-600" />
                  {t('saveToDocs')}
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
