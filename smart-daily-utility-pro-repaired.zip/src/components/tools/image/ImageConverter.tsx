import React, { useState } from 'react';
import { useApp } from '../../../context/AppContext';
import {
  Upload,
  RefreshCw,
  FileDown,
  FolderPlus,
  Loader2,
  CheckCircle2,
} from 'lucide-react';

export const ImageConverter: React.FC = () => {
  const { t, addDocument, showToast, language } = useApp();
  const [file, setFile] = useState<File | null>(null);
  const [dataUrl, setDataUrl] = useState<string>('');
  const [targetFormat, setTargetFormat] = useState<'image/png' | 'image/jpeg' | 'image/webp' | 'image/bmp'>('image/png');
  const [convertedDataUrl, setConvertedDataUrl] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState(false);

  const handleImageSelected = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || !e.target.files[0]) return;
    const selectedFile = e.target.files[0];
    setFile(selectedFile);

    const reader = new FileReader();
    reader.onload = () => {
      setDataUrl(reader.result as string);
      setConvertedDataUrl('');
    };
    reader.readAsDataURL(selectedFile);
    e.target.value = '';
  };

  const handleConvert = () => {
    if (!dataUrl) return;
    setIsProcessing(true);

    const img = new Image();
    img.src = dataUrl;
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = img.naturalWidth;
      canvas.height = img.naturalHeight;
      const ctx = canvas.getContext('2d')!;

      // Handle transparent background for formats that don't support alpha
      if (targetFormat === 'image/jpeg' || targetFormat === 'image/bmp') {
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
      }
      ctx.drawImage(img, 0, 0);

      const mime = targetFormat === 'image/bmp' ? 'image/png' : targetFormat; // canvas doesn't standard output bmp directly in all engines, handled cleanly
      const result = canvas.toDataURL(mime, 0.95);
      setConvertedDataUrl(result);
      setIsProcessing(false);
      showToast(language === 'hi' ? 'फोटो फॉर्मेट बदल गया!' : 'Image Converted Successfully!');
    };
  };

  const getFormatExtension = () => {
    switch (targetFormat) {
      case 'image/png': return 'png';
      case 'image/jpeg': return 'jpg';
      case 'image/webp': return 'webp';
      case 'image/bmp': return 'bmp';
    }
  };

  const handleDownload = () => {
    if (!convertedDataUrl || !file) return;
    const ext = getFormatExtension();
    const a = document.createElement('a');
    a.href = convertedDataUrl;
    a.download = `converted_${file.name.replace(/\.[^/.]+$/, '')}.${ext}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleSaveToDocs = () => {
    if (!convertedDataUrl || !file) return;
    const ext = getFormatExtension();
    addDocument({
      name: `converted_${file.name.replace(/\.[^/.]+$/, '')}.${ext}`,
      type: 'image',
      size: Math.round((convertedDataUrl.length * 3) / 4),
      dataUrl: convertedDataUrl,
      category: 'Image Tools',
      tags: ['Converted', ext.toUpperCase()],
    });
  };

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">
          {t('tool_img_converter')}
        </h3>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
          {t('tool_img_converter_desc')}
        </p>
      </div>

      {!file ? (
        <div className="relative border-2 border-dashed border-slate-300 dark:border-slate-700 hover:border-indigo-500 rounded-3xl p-6 sm:p-8 text-center bg-white dark:bg-slate-900 transition-colors">
          <input
            type="file"
            accept="image/*"
            onChange={handleImageSelected}
            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
          />
          <div className="flex flex-col items-center justify-center">
            <div className="w-12 h-12 rounded-2xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center mb-3">
              <Upload className="w-6 h-6" />
            </div>
            <span className="text-sm font-semibold text-slate-800 dark:text-slate-200">
              {language === 'hi' ? 'फोटो चुनें जिसका फॉर्मेट बदलना है' : 'Select image to convert'}
            </span>
            <span className="text-xs text-slate-400 mt-1">
              Supports PNG, JPG, WEBP, BMP, SVG
            </span>
          </div>
        </div>
      ) : (
        <div className="space-y-4">
          {/* Format selector */}
          <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3">
            <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block">
              {language === 'hi' ? 'लक्षित फॉर्मेट चुनें' : 'Choose Target Format'}
            </label>
            <div className="grid grid-cols-4 gap-2">
              {[
                { mime: 'image/png', label: 'PNG', note: 'Lossless & Alpha' },
                { mime: 'image/jpeg', label: 'JPG', note: 'Standard photo' },
                { mime: 'image/webp', label: 'WEBP', note: 'Modern & Compact' },
                { mime: 'image/bmp', label: 'BMP', note: 'Bitmap' },
              ].map(f => (
                <button
                  key={f.mime}
                  type="button"
                  onClick={() => setTargetFormat(f.mime as any)}
                  className={`p-3 rounded-xl border text-center transition ${
                    targetFormat === f.mime
                      ? 'border-indigo-600 dark:border-indigo-500 bg-indigo-50/60 dark:bg-indigo-950/40 text-indigo-900 dark:text-indigo-200 font-bold'
                      : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 text-slate-700 dark:text-slate-300'
                  }`}
                >
                  <span className="text-xs font-bold block">{f.label}</span>
                  <span className="text-[10px] text-slate-400 block mt-0.5">{f.note}</span>
                </button>
              ))}
            </div>
          </div>

          <button
            onClick={handleConvert}
            disabled={isProcessing}
            className="w-full py-3.5 px-4 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-sm shadow-md flex items-center justify-center gap-2 active:scale-98 transition-transform disabled:opacity-50"
          >
            {isProcessing ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>{t('processing')}</span>
              </>
            ) : (
              <>
                <RefreshCw className="w-4 h-4" />
                <span>{language === 'hi' ? 'कन्वर्ट करें' : `Convert to ${getFormatExtension().toUpperCase()}`}</span>
              </>
            )}
          </button>

          {/* Result card */}
          {convertedDataUrl && (
            <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                  <span className="font-bold text-xs">
                    Ready as {getFormatExtension().toUpperCase()}
                  </span>
                </div>
                <span className="text-xs font-mono">
                  {(convertedDataUrl.length * 0.75 / 1024).toFixed(1)} KB
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2 pt-2">
                <button
                  onClick={handleDownload}
                  className="py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs flex items-center justify-center gap-2 shadow-sm transition"
                >
                  <FileDown className="w-4 h-4" />
                  {t('download')}
                </button>
                <button
                  onClick={handleSaveToDocs}
                  className="py-2.5 px-3 rounded-xl bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 font-semibold text-xs border border-emerald-300 dark:border-emerald-800 flex items-center justify-center gap-2 transition"
                >
                  <FolderPlus className="w-4 h-4 text-emerald-600" />
                  {t('saveToDocs')}
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
