import React, { useState } from 'react';
import { useApp } from '../../../context/AppContext';
import { PDFDocument } from 'pdf-lib';
import {
  Upload,
  ArrowUp,
  ArrowDown,
  Trash2,
  FileDown,
  FolderPlus,
  Loader2,
  Files,
} from 'lucide-react';

interface PdfFileItem {
  id: string;
  name: string;
  size: number;
  arrayBuffer: ArrayBuffer;
  pageCount: number;
}

export const MergePdf: React.FC = () => {
  const { t, addDocument, showToast, language } = useApp();
  const [pdfFiles, setPdfFiles] = useState<PdfFileItem[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [mergedPdfBytes, setMergedPdfBytes] = useState<Uint8Array | null>(null);
  const [mergedName, setMergedName] = useState<string>('');

  const handlePdfsSelected = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files) return;
    const files = Array.from(e.target.files);
    setIsProcessing(true);

    try {
      const newItems: PdfFileItem[] = [];
      for (const file of files) {
        if (!file.name.toLowerCase().endsWith('.pdf') && file.type !== 'application/pdf') continue;
        const arrayBuffer = await file.arrayBuffer();
        try {
          const doc = await PDFDocument.load(arrayBuffer);
          newItems.push({
            id: Math.random().toString(36).substring(2, 9),
            name: file.name,
            size: file.size,
            arrayBuffer,
            pageCount: doc.getPageCount(),
          });
        } catch (err) {
          console.error('Error loading PDF file:', file.name, err);
        }
      }

      setPdfFiles(prev => [...prev, ...newItems]);
      setMergedPdfBytes(null);
    } finally {
      setIsProcessing(false);
      e.target.value = '';
    }
  };

  const moveFile = (index: number, direction: 'up' | 'down') => {
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= pdfFiles.length) return;
    const updated = [...pdfFiles];
    const temp = updated[index];
    updated[index] = updated[targetIndex];
    updated[targetIndex] = temp;
    setPdfFiles(updated);
    setMergedPdfBytes(null);
  };

  const removeFile = (index: number) => {
    setPdfFiles(prev => prev.filter((_, i) => i !== index));
    setMergedPdfBytes(null);
  };

  const handleMerge = async () => {
    if (pdfFiles.length < 2) {
      showToast(language === 'hi' ? 'कम से कम 2 पीडीएफ फाइलें चुनें' : 'Please select at least 2 PDF files to merge');
      return;
    }

    setIsProcessing(true);
    try {
      const mergedPdf = await PDFDocument.create();

      for (const file of pdfFiles) {
        const doc = await PDFDocument.load(file.arrayBuffer);
        const copiedPages = await mergedPdf.copyPages(doc, doc.getPageIndices());
        copiedPages.forEach(page => mergedPdf.addPage(page));
      }

      const mergedBytes = await mergedPdf.save();
      const filename = `Merged_${Date.now()}.pdf`;
      setMergedPdfBytes(mergedBytes);
      setMergedName(filename);
      showToast(language === 'hi' ? 'पीडीएफ सफलतापूर्वक मर्ज हो गए!' : 'PDFs Merged Successfully!');
    } catch (err) {
      console.error(err);
      showToast(language === 'hi' ? 'पीडीएफ मर्ज करने में त्रुटि' : 'Error merging PDFs');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDownload = () => {
    if (!mergedPdfBytes) return;
    const blob = new Blob([mergedPdfBytes as unknown as BlobPart], { type: 'application/pdf' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = mergedName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleSaveToDocs = () => {
    if (!mergedPdfBytes) return;
    const blob = new Blob([mergedPdfBytes as unknown as BlobPart], { type: 'application/pdf' });
    const reader = new FileReader();
    reader.onload = () => {
      addDocument({
        name: mergedName,
        type: 'pdf',
        size: mergedPdfBytes.byteLength,
        dataUrl: reader.result as string,
        category: 'PDF Tools',
        tags: ['Merged', `${pdfFiles.length} files`],
      });
    };
    reader.readAsDataURL(blob);
  };

  const totalPages = pdfFiles.reduce((acc, f) => acc + f.pageCount, 0);

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">
          {t('tool_merge_pdf')}
        </h3>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
          {t('tool_merge_pdf_desc')}
        </p>
      </div>

      {/* Upload Dropzone */}
      <div className="relative border-2 border-dashed border-slate-300 dark:border-slate-700 hover:border-blue-500 rounded-3xl p-6 sm:p-8 text-center bg-white dark:bg-slate-900 transition-colors">
        <input
          type="file"
          accept="application/pdf,.pdf"
          multiple
          onChange={handlePdfsSelected}
          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
        />
        <div className="flex flex-col items-center justify-center">
          <div className="w-12 h-12 rounded-2xl bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 flex items-center justify-center mb-3">
            <Upload className="w-6 h-6" />
          </div>
          <span className="text-sm font-semibold text-slate-800 dark:text-slate-200">
            {language === 'hi' ? 'पीडीएफ फाइलें चुनें या यहां छोड़ें' : 'Select PDF files or drop them here'}
          </span>
          <span className="text-xs text-slate-400 mt-1">
            {pdfFiles.length} {pdfFiles.length === 1 ? 'file' : 'files'} selected ({totalPages} total pages)
          </span>
        </div>
      </div>

      {/* Reorder List */}
      {pdfFiles.length > 0 && (
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>Merge Order ({pdfFiles.length} documents)</span>
            <button
              onClick={() => {
                setPdfFiles([]);
                setMergedPdfBytes(null);
              }}
              className="text-rose-600 hover:text-rose-700 font-medium"
            >
              Clear All
            </button>
          </div>

          <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
            {pdfFiles.map((item, idx) => (
              <div
                key={item.id}
                className="flex items-center justify-between p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 gap-3"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <span className="w-6 h-6 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-bold text-xs flex items-center justify-center shrink-0">
                    {idx + 1}
                  </span>
                  <div className="min-w-0">
                    <span className="text-xs font-semibold text-slate-800 dark:text-slate-200 truncate block">
                      {item.name}
                    </span>
                    <span className="text-[11px] text-slate-400">
                      {item.pageCount} {item.pageCount === 1 ? 'page' : 'pages'} · {(item.size / 1024).toFixed(1)} KB
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-1 shrink-0">
                  <button
                    onClick={() => moveFile(idx, 'up')}
                    disabled={idx === 0}
                    className="p-1.5 rounded hover:bg-slate-100 dark:hover:bg-slate-800 disabled:opacity-30 text-slate-600 dark:text-slate-300"
                    title="Move Up"
                  >
                    <ArrowUp className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => moveFile(idx, 'down')}
                    disabled={idx === pdfFiles.length - 1}
                    className="p-1.5 rounded hover:bg-slate-100 dark:hover:bg-slate-800 disabled:opacity-30 text-slate-600 dark:text-slate-300"
                    title="Move Down"
                  >
                    <ArrowDown className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => removeFile(idx)}
                    className="p-1.5 rounded hover:bg-rose-50 dark:hover:bg-rose-950 text-rose-500"
                    title="Remove"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Merge Action */}
      {pdfFiles.length >= 2 && !mergedPdfBytes && (
        <button
          onClick={handleMerge}
          disabled={isProcessing}
          className="w-full py-3.5 px-4 rounded-2xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-sm shadow-md flex items-center justify-center gap-2 active:scale-[0.98] transition-transform disabled:opacity-50"
        >
          {isProcessing ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              <span>{t('processing')}</span>
            </>
          ) : (
            <>
              <Files className="w-4 h-4" />
              <span>{language === 'hi' ? 'पीडीएफ फाइलें जोड़ें (Merge)' : `Merge ${pdfFiles.length} PDFs into 1`}</span>
            </>
          )}
        </button>
      )}

      {/* Result Card */}
      {mergedPdfBytes && (
        <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200 space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <span className="font-bold text-sm block">{mergedName}</span>
              <span className="text-xs text-emerald-700 dark:text-emerald-300">
                {(mergedPdfBytes.byteLength / 1024).toFixed(1)} KB · {totalPages} Pages Combined
              </span>
            </div>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-emerald-200 dark:bg-emerald-900 text-emerald-800 dark:text-emerald-200">
              Merged
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2 pt-2">
            <button
              onClick={handleDownload}
              className="py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs flex items-center justify-center gap-2 shadow-sm transition"
            >
              <FileDown className="w-4 h-4" />
              {t('download')}
            </button>
            <button
              onClick={handleSaveToDocs}
              className="py-2.5 px-3 rounded-xl bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 font-semibold text-xs border border-emerald-300 dark:border-emerald-800 flex items-center justify-center gap-2 transition"
            >
              <FolderPlus className="w-4 h-4 text-emerald-600" />
              {t('saveToDocs')}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
