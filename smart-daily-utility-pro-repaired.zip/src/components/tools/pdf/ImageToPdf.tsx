import React, { useState } from 'react';
import { useApp } from '../../../context/AppContext';
import { PDFDocument, rgb } from 'pdf-lib';
import {
  Upload,
  ArrowUp,
  ArrowDown,
  Trash2,
  FileDown,
  FolderPlus,
  Loader2,
  Settings,
  Sparkles,
} from 'lucide-react';

interface SelectedImage {
  id: string;
  name: string;
  dataUrl: string;
  file: File;
}

export const ImageToPdf: React.FC = () => {
  const { t, addDocument, showToast, language } = useApp();
  const [images, setImages] = useState<SelectedImage[]>([]);
  const [orientation, setOrientation] = useState<'portrait' | 'landscape'>('portrait');
  const [pageSize, setPageSize] = useState<'a4' | 'fit'>('a4');
  const [isProcessing, setIsProcessing] = useState(false);
  const [generatedPdfBytes, setGeneratedPdfBytes] = useState<Uint8Array | null>(null);
  const [generatedPdfName, setGeneratedPdfName] = useState<string>('');

  const handleFilesSelected = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files) return;
    const files = Array.from(e.target.files);
    const validFiles = files.filter(
      file => file.type.startsWith('image/') || /\.(jpg|jpeg|png|webp|bmp|gif|svg)$/i.test(file.name)
    );

    if (validFiles.length === 0) {
      showToast(language === 'hi' ? 'कृपया मान्य छवि फाइलें चुनें' : 'Please select valid image files');
      return;
    }

    try {
      const loadedImages = await Promise.all(
        validFiles.map(
          file =>
            new Promise<SelectedImage>((resolve, reject) => {
              const reader = new FileReader();
              reader.onload = () => {
                resolve({
                  id: Math.random().toString(36).substring(2, 9),
                  name: file.name,
                  dataUrl: reader.result as string,
                  file,
                });
              };
              reader.onerror = reject;
              reader.readAsDataURL(file);
            })
        )
      );

      setImages(prev => [...prev, ...loadedImages]);
      setGeneratedPdfBytes(null);
    } catch (err) {
      console.error('Error reading images:', err);
      showToast(language === 'hi' ? 'छवियां लोड करने में त्रुटि' : 'Error reading selected images');
    } finally {
      e.target.value = '';
    }
  };

  const moveImage = (index: number, direction: 'up' | 'down') => {
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= images.length) return;
    const updated = [...images];
    const temp = updated[index];
    updated[index] = updated[targetIndex];
    updated[targetIndex] = temp;
    setImages(updated);
    setGeneratedPdfBytes(null);
  };

  const removeImage = (index: number) => {
    setImages(prev => prev.filter((_, i) => i !== index));
    setGeneratedPdfBytes(null);
  };

  const convertImagesToPdf = async () => {
    if (images.length === 0) return;
    setIsProcessing(true);

    try {
      const pdfDoc = await PDFDocument.create();

      for (const item of images) {
        // Convert image to PNG / JPG canvas buffer to ensure maximum format compatibility
        const img = new Image();
        img.src = item.dataUrl;
        await new Promise((resolve, reject) => {
          img.onload = resolve;
          img.onerror = reject;
        });

        const canvas = document.createElement('canvas');
        canvas.width = img.naturalWidth;
        canvas.height = img.naturalHeight;
        const ctx = canvas.getContext('2d')!;
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(img, 0, 0);

        const jpegDataUrl = canvas.toDataURL('image/jpeg', 0.92);
        const jpegBytes = await fetch(jpegDataUrl).then(res => res.arrayBuffer());
        const embeddedImg = await pdfDoc.embedJpg(jpegBytes);

        let pageWidth = 595.28; // A4 standard pt
        let pageHeight = 841.89;

        if (pageSize === 'fit') {
          pageWidth = embeddedImg.width;
          pageHeight = embeddedImg.height;
        } else if (orientation === 'landscape') {
          pageWidth = 841.89;
          pageHeight = 595.28;
        }

        const page = pdfDoc.addPage([pageWidth, pageHeight]);

        // Scale image within page bounds preserving aspect ratio
        const scale = Math.min(
          (pageWidth - 40) / embeddedImg.width,
          (pageHeight - 40) / embeddedImg.height
        );
        const drawWidth = embeddedImg.width * scale;
        const drawHeight = embeddedImg.height * scale;
        const xPos = (pageWidth - drawWidth) / 2;
        const yPos = (pageHeight - drawHeight) / 2;

        page.drawImage(embeddedImg, {
          x: xPos,
          y: yPos,
          width: drawWidth,
          height: drawHeight,
        });
      }

      const pdfBytes = await pdfDoc.save();
      const filename = `Document_${Date.now()}.pdf`;
      setGeneratedPdfBytes(pdfBytes);
      setGeneratedPdfName(filename);
      showToast(language === 'hi' ? 'पीडीएफ सफलतापूर्वक बन गया!' : 'PDF Generated Successfully!');
    } catch (err) {
      console.error(err);
      showToast(language === 'hi' ? 'पीडीएफ बनाने में त्रुटि' : 'Error generating PDF');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDownload = () => {
    if (!generatedPdfBytes) return;
    const blob = new Blob([generatedPdfBytes as unknown as BlobPart], { type: 'application/pdf' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = generatedPdfName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleSaveToDocs = () => {
    if (!generatedPdfBytes) return;
    const blob = new Blob([generatedPdfBytes as unknown as BlobPart], { type: 'application/pdf' });
    const reader = new FileReader();
    reader.onload = () => {
      addDocument({
        name: generatedPdfName,
        type: 'pdf',
        size: generatedPdfBytes.byteLength,
        dataUrl: reader.result as string,
        category: 'PDF Tools',
        tags: ['ImageToPdf', `${images.length} pages`],
      });
    };
    reader.readAsDataURL(blob);
  };

  return (
    <div className="space-y-6">
      {/* Title & Instructions */}
      <div>
        <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">
          {t('tool_image_to_pdf')}
        </h3>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
          {t('tool_image_to_pdf_desc')}
        </p>
      </div>

      {/* Upload Zone */}
      <div className="relative border-2 border-dashed border-slate-300 dark:border-slate-700 hover:border-blue-500 rounded-3xl p-6 sm:p-8 text-center bg-white dark:bg-slate-900 transition-colors">
        <input
          type="file"
          accept="image/*"
          multiple
          onChange={handleFilesSelected}
          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
        />
        <div className="flex flex-col items-center justify-center">
          <div className="w-12 h-12 rounded-2xl bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 flex items-center justify-center mb-3">
            <Upload className="w-6 h-6" />
          </div>
          <span className="text-sm font-semibold text-slate-800 dark:text-slate-200">
            {t('dropFilesHere')}
          </span>
          <span className="text-xs text-slate-400 mt-1">
            PNG, JPG, JPEG, WEBP ({images.length} {images.length === 1 ? 'image' : 'images'} selected)
          </span>
        </div>
      </div>

      {/* Configuration Strip */}
      {images.length > 0 && (
        <div className="grid grid-cols-2 gap-3 p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
          <div>
            <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1.5">
              Orientation
            </label>
            <div className="flex rounded-lg bg-slate-200 dark:bg-slate-700 p-0.5 text-xs font-medium">
              <button
                type="button"
                onClick={() => setOrientation('portrait')}
                className={`flex-1 py-1.5 rounded-md transition ${
                  orientation === 'portrait' ? 'bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 font-semibold shadow-sm' : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                Portrait
              </button>
              <button
                type="button"
                onClick={() => setOrientation('landscape')}
                className={`flex-1 py-1.5 rounded-md transition ${
                  orientation === 'landscape' ? 'bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 font-semibold shadow-sm' : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                Landscape
              </button>
            </div>
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1.5">
              Page Size
            </label>
            <div className="flex rounded-lg bg-slate-200 dark:bg-slate-700 p-0.5 text-xs font-medium">
              <button
                type="button"
                onClick={() => setPageSize('a4')}
                className={`flex-1 py-1.5 rounded-md transition ${
                  pageSize === 'a4' ? 'bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 font-semibold shadow-sm' : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                A4 Page
              </button>
              <button
                type="button"
                onClick={() => setPageSize('fit')}
                className={`flex-1 py-1.5 rounded-md transition ${
                  pageSize === 'fit' ? 'bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 font-semibold shadow-sm' : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                Fit Image
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Selected Images Reorder Grid */}
      {images.length > 0 && (
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>Arrange Page Order ({images.length} pages)</span>
            <button
              onClick={() => setImages([])}
              className="text-rose-600 hover:text-rose-700 font-medium"
            >
              Clear All
            </button>
          </div>

          <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
            {images.map((item, idx) => (
              <div
                key={item.id}
                className="flex items-center justify-between p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 gap-3"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <span className="w-6 h-6 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-bold text-xs flex items-center justify-center shrink-0">
                    {idx + 1}
                  </span>
                  <img
                    src={item.dataUrl}
                    alt={item.name}
                    className="w-10 h-10 object-cover rounded-lg border border-slate-200 dark:border-slate-700 shrink-0"
                  />
                  <span className="text-xs font-medium text-slate-800 dark:text-slate-200 truncate">
                    {item.name}
                  </span>
                </div>

                <div className="flex items-center gap-1 shrink-0">
                  <button
                    onClick={() => moveImage(idx, 'up')}
                    disabled={idx === 0}
                    className="p-1.5 rounded hover:bg-slate-100 dark:hover:bg-slate-800 disabled:opacity-30 text-slate-600 dark:text-slate-300"
                    title="Move Up"
                  >
                    <ArrowUp className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => moveImage(idx, 'down')}
                    disabled={idx === images.length - 1}
                    className="p-1.5 rounded hover:bg-slate-100 dark:hover:bg-slate-800 disabled:opacity-30 text-slate-600 dark:text-slate-300"
                    title="Move Down"
                  >
                    <ArrowDown className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => removeImage(idx)}
                    className="p-1.5 rounded hover:bg-rose-50 dark:hover:bg-rose-950 text-rose-500"
                    title="Remove"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Convert Trigger */}
      {images.length > 0 && !generatedPdfBytes && (
        <button
          onClick={convertImagesToPdf}
          disabled={isProcessing}
          className="w-full py-3.5 px-4 rounded-2xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-sm shadow-md flex items-center justify-center gap-2 active:scale-[0.98] transition-transform disabled:opacity-50"
        >
          {isProcessing ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              <span>{t('processing')}</span>
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4" />
              <span>{language === 'hi' ? 'पीडीएफ बनाएं' : 'Generate PDF'}</span>
            </>
          )}
        </button>
      )}

      {/* Result Actions */}
      {generatedPdfBytes && (
        <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200 space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <span className="font-bold text-sm block">{generatedPdfName}</span>
              <span className="text-xs text-emerald-700 dark:text-emerald-300">
                {(generatedPdfBytes.byteLength / 1024).toFixed(1)} KB · {images.length} Pages
              </span>
            </div>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-emerald-200 dark:bg-emerald-900 text-emerald-800 dark:text-emerald-200">
              Ready
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2 pt-2">
            <button
              onClick={handleDownload}
              className="py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs flex items-center justify-center gap-2 shadow-sm transition"
            >
              <FileDown className="w-4 h-4" />
              {t('download')}
            </button>
            <button
              onClick={handleSaveToDocs}
              className="py-2.5 px-3 rounded-xl bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 font-semibold text-xs border border-emerald-300 dark:border-emerald-800 flex items-center justify-center gap-2 transition"
            >
              <FolderPlus className="w-4 h-4 text-emerald-600" />
              {t('saveToDocs')}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
