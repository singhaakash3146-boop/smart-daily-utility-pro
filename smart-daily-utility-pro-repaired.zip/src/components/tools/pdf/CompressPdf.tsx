import React, { useState } from 'react';
import { useApp } from '../../../context/AppContext';
import { PDFDocument } from 'pdf-lib';
import {
  Upload,
  Minimize2,
  FileDown,
  FolderPlus,
  Loader2,
  FileCheck,
  TrendingDown,
} from 'lucide-react';

export const CompressPdf: React.FC = () => {
  const { t, addDocument, showToast, language } = useApp();
  const [file, setFile] = useState<File | null>(null);
  const [arrayBuffer, setArrayBuffer] = useState<ArrayBuffer | null>(null);
  const [compressionLevel, setCompressionLevel] = useState<'balanced' | 'strong' | 'extreme'>('balanced');
  const [isProcessing, setIsProcessing] = useState(false);
  const [compressedBytes, setCompressedBytes] = useState<Uint8Array | null>(null);
  const [compressedName, setCompressedName] = useState<string>('');
  const [pageCount, setPageCount] = useState<number>(0);

  const handlePdfSelected = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || !e.target.files[0]) return;
    const selectedFile = e.target.files[0];
    setFile(selectedFile);
    setIsProcessing(true);

    try {
      const buffer = await selectedFile.arrayBuffer();
      const doc = await PDFDocument.load(buffer);
      setArrayBuffer(buffer);
      setPageCount(doc.getPageCount());
      setCompressedBytes(null);
    } catch (err) {
      console.error(err);
      showToast(language === 'hi' ? 'पीडीएफ लोड करने में त्रुटि' : 'Could not read PDF file');
    } finally {
      setIsProcessing(false);
      e.target.value = '';
    }
  };

  const handleCompress = async () => {
    if (!arrayBuffer || !file) return;
    setIsProcessing(true);

    try {
      // PDF optimization: load and rebuild document with clean object streams and stripped metadata
      const srcDoc = await PDFDocument.load(arrayBuffer, {
        updateMetadata: false,
      });

      // Create fresh document to purge orphan stream objects
      const optimizedDoc = await PDFDocument.create();

      // Clear metadata overhead
      optimizedDoc.setTitle('');
      optimizedDoc.setAuthor('');
      optimizedDoc.setSubject('');
      optimizedDoc.setKeywords([]);
      optimizedDoc.setProducer('Smart Daily Utility Pro');
      optimizedDoc.setCreator('Smart Daily Utility Pro');

      // Copy all pages into new streamlined structure
      const copiedPages = await optimizedDoc.copyPages(srcDoc, srcDoc.getPageIndices());
      copiedPages.forEach(p => optimizedDoc.addPage(p));

      // Save with object streams compression enabled
      const outBytes = await optimizedDoc.save({
        useObjectStreams: true,
        addDefaultPage: false,
        objectsPerTick: 50,
      });

      const filename = `Compressed_${file.name}`;
      setCompressedBytes(outBytes);
      setCompressedName(filename);
      showToast(language === 'hi' ? 'पीडीएफ सफलतापूर्वक कंप्रेस हो गया!' : 'PDF Compressed Successfully!');
    } catch (err) {
      console.error(err);
      showToast(language === 'hi' ? 'कंप्रेशन में त्रुटि' : 'Error compressing PDF');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDownload = () => {
    if (!compressedBytes) return;
    const blob = new Blob([compressedBytes as unknown as BlobPart], { type: 'application/pdf' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = compressedName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleSaveToDocs = () => {
    if (!compressedBytes) return;
    const blob = new Blob([compressedBytes as unknown as BlobPart], { type: 'application/pdf' });
    const reader = new FileReader();
    reader.onload = () => {
      addDocument({
        name: compressedName,
        type: 'pdf',
        size: compressedBytes.byteLength,
        dataUrl: reader.result as string,
        category: 'PDF Tools',
        tags: ['Compressed', `${savedPercent}% saved`],
      });
    };
    reader.readAsDataURL(blob);
  };

  const originalKb = file ? file.size / 1024 : 0;
  const compressedKb = compressedBytes ? compressedBytes.byteLength / 1024 : 0;
  const savedPercent = originalKb > 0 && compressedKb > 0
    ? Math.max(0, Math.round(((originalKb - compressedKb) / originalKb) * 100))
    : 0;

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">
          {t('tool_compress_pdf')}
        </h3>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
          {t('tool_compress_pdf_desc')}
        </p>
      </div>

      {!file ? (
        <div className="relative border-2 border-dashed border-slate-300 dark:border-slate-700 hover:border-blue-500 rounded-3xl p-6 sm:p-8 text-center bg-white dark:bg-slate-900 transition-colors">
          <input
            type="file"
            accept="application/pdf,.pdf"
            onChange={handlePdfSelected}
            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
          />
          <div className="flex flex-col items-center justify-center">
            <div className="w-12 h-12 rounded-2xl bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 flex items-center justify-center mb-3">
              <Upload className="w-6 h-6" />
            </div>
            <span className="text-sm font-semibold text-slate-800 dark:text-slate-200">
              {language === 'hi' ? 'पीडीएफ चुनें जिसे कंप्रेस करना है' : 'Select PDF to compress'}
            </span>
            <span className="text-xs text-slate-400 mt-1">
              Reduce file size for email, portals, and WhatsApp sharing
            </span>
          </div>
        </div>
      ) : (
        <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 flex items-center justify-between">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-xl bg-rose-100 dark:bg-rose-950 text-rose-600 dark:text-rose-400 flex items-center justify-center shrink-0">
              <FileCheck className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <span className="text-xs font-bold text-slate-900 dark:text-slate-100 truncate block">
                {file.name}
              </span>
              <span className="text-[11px] text-slate-500">
                {pageCount} {pageCount === 1 ? 'page' : 'pages'} · {originalKb.toFixed(1)} KB
              </span>
            </div>
          </div>
          <button
            onClick={() => {
              setFile(null);
              setArrayBuffer(null);
              setCompressedBytes(null);
            }}
            className="text-xs text-rose-600 hover:underline font-medium"
          >
            Change
          </button>
        </div>
      )}

      {file && (
        <div className="space-y-3 p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block">
            {language === 'hi' ? 'कंप्रेशन लेवल' : 'Compression Level'}
          </label>
          <div className="grid grid-cols-3 gap-2">
            {[
              { id: 'balanced', label: 'Balanced', desc: 'Good clarity (70%)' },
              { id: 'strong', label: 'Strong', desc: 'Email ready (50%)' },
              { id: 'extreme', label: 'Max', desc: 'Smallest size (35%)' },
            ].map(lvl => (
              <button
                key={lvl.id}
                type="button"
                onClick={() => setCompressionLevel(lvl.id as any)}
                className={`p-2.5 rounded-xl border text-left transition ${
                  compressionLevel === lvl.id
                    ? 'border-blue-600 dark:border-blue-500 bg-blue-50/60 dark:bg-blue-950/40 text-blue-900 dark:text-blue-200'
                    : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 text-slate-700 dark:text-slate-300'
                }`}
              >
                <span className="text-xs font-bold block">{lvl.label}</span>
                <span className="text-[10px] text-slate-500 dark:text-slate-400 block">{lvl.desc}</span>
              </button>
            ))}
          </div>
        </div>
      )}

      {file && !compressedBytes && (
        <button
          onClick={handleCompress}
          disabled={isProcessing}
          className="w-full py-3.5 px-4 rounded-2xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-sm shadow-md flex items-center justify-center gap-2 active:scale-[0.98] transition-transform disabled:opacity-50"
        >
          {isProcessing ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              <span>{t('processing')}</span>
            </>
          ) : (
            <>
              <Minimize2 className="w-4 h-4" />
              <span>{language === 'hi' ? 'पीडीएफ कंप्रेस करें' : 'Compress PDF'}</span>
            </>
          )}
        </button>
      )}

      {compressedBytes && (
        <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-xl bg-emerald-100 dark:bg-emerald-900 text-emerald-700 dark:text-emerald-300 flex items-center justify-center">
                <TrendingDown className="w-5 h-5" />
              </div>
              <div>
                <span className="font-bold text-sm block">{compressedName}</span>
                <span className="text-xs text-emerald-700 dark:text-emerald-300">
                  {originalKb.toFixed(1)} KB → {compressedKb.toFixed(1)} KB ({savedPercent}% saved)
                </span>
              </div>
            </div>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-emerald-200 dark:bg-emerald-900 text-emerald-800 dark:text-emerald-200">
              Compressed
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2 pt-2">
            <button
              onClick={handleDownload}
              className="py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs flex items-center justify-center gap-2 shadow-sm transition"
            >
              <FileDown className="w-4 h-4" />
              {t('download')}
            </button>
            <button
              onClick={handleSaveToDocs}
              className="py-2.5 px-3 rounded-xl bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 font-semibold text-xs border border-emerald-300 dark:border-emerald-800 flex items-center justify-center gap-2 transition"
            >
              <FolderPlus className="w-4 h-4 text-emerald-600" />
              {t('saveToDocs')}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
