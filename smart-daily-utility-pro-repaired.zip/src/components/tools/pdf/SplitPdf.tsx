import React, { useState } from 'react';
import { useApp } from '../../../context/AppContext';
import { PDFDocument } from 'pdf-lib';
import {
  Upload,
  Scissors,
  FileDown,
  FolderPlus,
  Loader2,
  FileCheck,
} from 'lucide-react';

export const SplitPdf: React.FC = () => {
  const { t, addDocument, showToast, language } = useApp();
  const [file, setFile] = useState<File | null>(null);
  const [arrayBuffer, setArrayBuffer] = useState<ArrayBuffer | null>(null);
  const [totalPages, setTotalPages] = useState<number>(0);
  const [splitMode, setSplitMode] = useState<'range' | 'extract'>('range');
  const [pageRange, setPageRange] = useState<string>('1-2');
  const [isProcessing, setIsProcessing] = useState(false);
  const [resultPdfBytes, setResultPdfBytes] = useState<Uint8Array | null>(null);
  const [resultName, setResultName] = useState<string>('');

  const handlePdfSelected = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || !e.target.files[0]) return;
    const selectedFile = e.target.files[0];
    setFile(selectedFile);
    setIsProcessing(true);

    try {
      const buffer = await selectedFile.arrayBuffer();
      const doc = await PDFDocument.load(buffer);
      const count = doc.getPageCount();
      setArrayBuffer(buffer);
      setTotalPages(count);
      setPageRange(count > 1 ? `1-${Math.min(2, count)}` : '1');
      setResultPdfBytes(null);
    } catch (err) {
      console.error(err);
      showToast(language === 'hi' ? 'पीडीएफ लोड करने में त्रुटि' : 'Could not read PDF file');
    } finally {
      setIsProcessing(false);
      e.target.value = '';
    }
  };

  const parsePageIndices = (inputStr: string, maxPages: number): number[] => {
    const indices = new Set<number>();
    const parts = inputStr.split(',').map(s => s.trim()).filter(Boolean);

    for (const part of parts) {
      if (part.includes('-')) {
        const [startStr, endStr] = part.split('-');
        const start = parseInt(startStr, 10);
        const end = parseInt(endStr, 10);
        if (!isNaN(start) && !isNaN(end)) {
          const from = Math.max(1, Math.min(start, end));
          const to = Math.min(maxPages, Math.max(start, end));
          for (let p = from; p <= to; p++) {
            indices.add(p - 1); // 0-indexed
          }
        }
      } else {
        const pageNum = parseInt(part, 10);
        if (!isNaN(pageNum) && pageNum >= 1 && pageNum <= maxPages) {
          indices.add(pageNum - 1);
        }
      }
    }

    return Array.from(indices).sort((a, b) => a - b);
  };

  const handleSplit = async () => {
    if (!arrayBuffer || totalPages === 0) return;
    setIsProcessing(true);

    try {
      const srcDoc = await PDFDocument.load(arrayBuffer);
      const targetIndices = parsePageIndices(pageRange, totalPages);

      if (targetIndices.length === 0) {
        showToast(language === 'hi' ? 'मान्य पेज संख्या या रेंज दर्ज करें' : 'Please enter valid page numbers');
        setIsProcessing(false);
        return;
      }

      const newDoc = await PDFDocument.create();
      const copiedPages = await newDoc.copyPages(srcDoc, targetIndices);
      copiedPages.forEach(p => newDoc.addPage(p));

      const pdfBytes = await newDoc.save();
      const filename = `Split_pages_${pageRange.replace(/[^0-9-]/g, '_')}_${Date.now()}.pdf`;
      setResultPdfBytes(pdfBytes);
      setResultName(filename);
      showToast(language === 'hi' ? 'पेज सफलतापूर्वक अलग हो गए!' : 'Pages extracted successfully!');
    } catch (err) {
      console.error(err);
      showToast(language === 'hi' ? 'पीडीएफ अलग करने में त्रुटि' : 'Error splitting PDF');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDownload = () => {
    if (!resultPdfBytes) return;
    const blob = new Blob([resultPdfBytes as unknown as BlobPart], { type: 'application/pdf' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = resultName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleSaveToDocs = () => {
    if (!resultPdfBytes) return;
    const blob = new Blob([resultPdfBytes as unknown as BlobPart], { type: 'application/pdf' });
    const reader = new FileReader();
    reader.onload = () => {
      addDocument({
        name: resultName,
        type: 'pdf',
        size: resultPdfBytes.byteLength,
        dataUrl: reader.result as string,
        category: 'PDF Tools',
        tags: ['Split', `Pages: ${pageRange}`],
      });
    };
    reader.readAsDataURL(blob);
  };

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">
          {t('tool_split_pdf')}
        </h3>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
          {t('tool_split_pdf_desc')}
        </p>
      </div>

      {/* Upload Zone */}
      {!file ? (
        <div className="relative border-2 border-dashed border-slate-300 dark:border-slate-700 hover:border-blue-500 rounded-3xl p-6 sm:p-8 text-center bg-white dark:bg-slate-900 transition-colors">
          <input
            type="file"
            accept="application/pdf,.pdf"
            onChange={handlePdfSelected}
            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
          />
          <div className="flex flex-col items-center justify-center">
            <div className="w-12 h-12 rounded-2xl bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 flex items-center justify-center mb-3">
              <Upload className="w-6 h-6" />
            </div>
            <span className="text-sm font-semibold text-slate-800 dark:text-slate-200">
              {language === 'hi' ? 'पीडीएफ चुनें जिसे अलग करना है' : 'Select PDF to split or extract'}
            </span>
            <span className="text-xs text-slate-400 mt-1">
              Supports any multi-page PDF document
            </span>
          </div>
        </div>
      ) : (
        <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 flex items-center justify-between">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-xl bg-rose-100 dark:bg-rose-950 text-rose-600 dark:text-rose-400 flex items-center justify-center shrink-0">
              <FileCheck className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <span className="text-xs font-bold text-slate-900 dark:text-slate-100 truncate block">
                {file.name}
              </span>
              <span className="text-[11px] text-slate-500">
                {totalPages} {totalPages === 1 ? 'page' : 'pages'} · {(file.size / 1024).toFixed(1)} KB
              </span>
            </div>
          </div>
          <button
            onClick={() => {
              setFile(null);
              setArrayBuffer(null);
              setTotalPages(0);
              setResultPdfBytes(null);
            }}
            className="text-xs text-rose-600 hover:underline font-medium"
          >
            Change
          </button>
        </div>
      )}

      {/* Page Selection Controls */}
      {totalPages > 0 && (
        <div className="space-y-3 p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block">
            {language === 'hi' ? 'पेज रेंज या विशिष्ट पृष्ठ (उदा. 1-3, 5)' : 'Page Range or Specific Pages (e.g. 1-3, 5)'}
          </label>
          <div className="flex items-center gap-2">
            <input
              type="text"
              value={pageRange}
              onChange={e => setPageRange(e.target.value)}
              placeholder="e.g. 1-3, 5"
              className="flex-1 px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-mono focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <span className="text-xs text-slate-400 font-mono whitespace-nowrap">
              of {totalPages}
            </span>
          </div>

          <div className="flex flex-wrap gap-1.5 pt-1">
            <button
              type="button"
              onClick={() => setPageRange('1')}
              className="px-2.5 py-1 text-[11px] rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200"
            >
              First Page
            </button>
            <button
              type="button"
              onClick={() => setPageRange(totalPages.toString())}
              className="px-2.5 py-1 text-[11px] rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200"
            >
              Last Page
            </button>
            {totalPages >= 2 && (
              <button
                type="button"
                onClick={() => setPageRange(`1-${Math.ceil(totalPages / 2)}`)}
                className="px-2.5 py-1 text-[11px] rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200"
              >
                First Half (1-{Math.ceil(totalPages / 2)})
              </button>
            )}
          </div>
        </div>
      )}

      {/* Extract Button */}
      {totalPages > 0 && !resultPdfBytes && (
        <button
          onClick={handleSplit}
          disabled={isProcessing}
          className="w-full py-3.5 px-4 rounded-2xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-sm shadow-md flex items-center justify-center gap-2 active:scale-[0.98] transition-transform disabled:opacity-50"
        >
          {isProcessing ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              <span>{t('processing')}</span>
            </>
          ) : (
            <>
              <Scissors className="w-4 h-4" />
              <span>{language === 'hi' ? 'पेज अलग करें (Extract)' : 'Extract Selected Pages'}</span>
            </>
          )}
        </button>
      )}

      {/* Result Card */}
      {resultPdfBytes && (
        <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200 space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <span className="font-bold text-sm block">{resultName}</span>
              <span className="text-xs text-emerald-700 dark:text-emerald-300">
                {(resultPdfBytes.byteLength / 1024).toFixed(1)} KB · Extracted from {file?.name}
              </span>
            </div>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-emerald-200 dark:bg-emerald-900 text-emerald-800 dark:text-emerald-200">
              Ready
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2 pt-2">
            <button
              onClick={handleDownload}
              className="py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs flex items-center justify-center gap-2 shadow-sm transition"
            >
              <FileDown className="w-4 h-4" />
              {t('download')}
            </button>
            <button
              onClick={handleSaveToDocs}
              className="py-2.5 px-3 rounded-xl bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 font-semibold text-xs border border-emerald-300 dark:border-emerald-800 flex items-center justify-center gap-2 transition"
            >
              <FolderPlus className="w-4 h-4 text-emerald-600" />
              {t('saveToDocs')}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
