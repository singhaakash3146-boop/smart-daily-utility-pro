import React, { useEffect, useState } from 'react';
import { WifiOff } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const OfflineBanner: React.FC = () => {
  const [isOnline, setIsOnline] = useState(
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );
  const { language } = useApp();

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  if (isOnline) return null;

  return (
    <div className="fixed top-12 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2 rounded-full bg-slate-900/90 dark:bg-slate-100/90 text-white dark:text-slate-900 px-3.5 py-1.5 text-xs font-semibold shadow-lg backdrop-blur-md animate-in slide-in-from-top-4">
      <WifiOff className="w-3.5 h-3.5 text-amber-400 dark:text-amber-600" />
      <span>{language === 'hi' ? 'ऑफलाइन मोड सक्रिय है - सभी टूल्स काम कर रहे हैं' : 'Offline Mode Active — All local tools work'}</span>
    </div>
  );
};
