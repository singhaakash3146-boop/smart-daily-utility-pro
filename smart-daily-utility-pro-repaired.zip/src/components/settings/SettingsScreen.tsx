import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  Moon,
  Sun,
  Globe,
  Smartphone,
  ShieldCheck,
  Sparkles,
  HelpCircle,
  RotateCcw,
  ExternalLink,
  Code2,
} from 'lucide-react';

export const SettingsScreen: React.FC = () => {
  const {
    language,
    setLanguage,
    theme,
    toggleTheme,
    isPremium,
    setShowPremiumModal,
    setShowApkModal,
    setShowAdmobInfoModal,
    t,
    showToast,
  } = useApp();

  const handleResetData = () => {
    if (window.confirm('Reset local app preferences and test cache?')) {
      localStorage.clear();
      showToast(language === 'hi' ? 'कैश रीसेट हो गया' : 'Local storage cleared');
      window.location.reload();
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">
          {t('settingsTitle')}
        </h3>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
          {language === 'hi' ? 'ऐप की भाषा, थीम और एंड्रॉइड सेटिंग्स' : 'Manage theme, language, and Android build settings'}
        </p>
      </div>

      {/* Pro Membership Card */}
      <div className="p-5 rounded-3xl bg-gradient-to-br from-slate-900 to-blue-950 text-white shadow-xl border border-slate-800">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-amber-500 text-slate-950 flex items-center justify-center font-extrabold text-base shadow-md">
              <Sparkles className="w-6 h-6 fill-slate-950" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-sm">Smart Daily Utility</span>
                <span className="text-[10px] font-black uppercase tracking-wider px-1.5 py-0.5 rounded bg-amber-500 text-black">
                  PRO
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                {isPremium
                  ? language === 'hi' ? 'प्रो संस्करण सक्रिय है' : 'Pro Ad-Free Status Active'
                  : language === 'hi' ? 'विज्ञापन हटाएं और हाई-रेजोल्यूशन टूल्स अनलॉक करें' : 'Remove all ads & unlock unlimited tools'}
              </p>
            </div>
          </div>

          {!isPremium && (
            <button
              onClick={() => setShowPremiumModal(true)}
              className="px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md transition active:scale-95 whitespace-nowrap"
            >
              Upgrade
            </button>
          )}
        </div>
      </div>

      {/* Settings Options Group */}
      <div className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 divide-y divide-slate-100 dark:divide-slate-800 text-xs">
        {/* Theme */}
        <div className="flex items-center justify-between py-3">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
              {theme === 'dark' ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
            </div>
            <div>
              <span className="font-bold text-slate-900 dark:text-slate-100 block">
                {t('theme')}
              </span>
              <span className="text-[11px] text-slate-400">
                {theme === 'dark' ? t('themeDark') : t('themeLight')}
              </span>
            </div>
          </div>

          <button
            onClick={toggleTheme}
            className="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100"
          >
            {theme === 'dark' ? 'Switch to Light' : 'Switch to Dark'}
          </button>
        </div>

        {/* Language */}
        <div className="flex items-center justify-between py-3">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-blue-600 dark:text-blue-400">
              <Globe className="w-4 h-4" />
            </div>
            <div>
              <span className="font-bold text-slate-900 dark:text-slate-100 block">
                {t('language')}
              </span>
              <span className="text-[11px] text-slate-400">
                {language === 'en' ? 'English' : 'हिन्दी (Hindi)'}
              </span>
            </div>
          </div>

          <div className="flex gap-1">
            <button
              onClick={() => setLanguage('en')}
              className={`px-2.5 py-1.5 rounded-lg font-semibold transition ${
                language === 'en'
                  ? 'bg-blue-600 text-white'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
              }`}
            >
              EN
            </button>
            <button
              onClick={() => setLanguage('hi')}
              className={`px-2.5 py-1.5 rounded-lg font-semibold transition ${
                language === 'hi'
                  ? 'bg-blue-600 text-white'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
              }`}
            >
              हिन्दी
            </button>
          </div>
        </div>

        {/* Android APK Instructions */}
        <div className="flex items-center justify-between py-3">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400">
              <Smartphone className="w-4 h-4" />
            </div>
            <div>
              <span className="font-bold text-slate-900 dark:text-slate-100 block">
                {t('buildApkBtn')}
              </span>
              <span className="text-[11px] text-slate-400">
                Capacitor & Google TWA packaging instructions
              </span>
            </div>
          </div>

          <button
            onClick={() => setShowApkModal(true)}
            className="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 font-semibold"
          >
            Guide
          </button>
        </div>

        {/* AdMob Configuration Guide */}
        <div className="flex items-center justify-between py-3">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400">
              <Code2 className="w-4 h-4" />
            </div>
            <div>
              <span className="font-bold text-slate-900 dark:text-slate-100 block">
                {t('admobDevGuide')}
              </span>
              <span className="text-[11px] text-slate-400">
                Official Test IDs & production readiness
              </span>
            </div>
          </div>

          <button
            onClick={() => setShowAdmobInfoModal(true)}
            className="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 font-semibold"
          >
            AdMob Info
          </button>
        </div>
      </div>

      {/* Privacy & Offline Guarantee */}
      <div className="p-4 rounded-3xl bg-blue-50/60 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-900/40 flex items-start gap-3">
        <ShieldCheck className="w-5 h-5 text-blue-600 dark:text-blue-400 shrink-0 mt-0.5" />
        <div className="space-y-0.5">
          <span className="text-xs font-bold text-blue-950 dark:text-blue-200 block">
            {t('privacyBadge')}
          </span>
          <p className="text-[11px] text-blue-900/80 dark:text-blue-300/80 leading-relaxed">
            {t('privacyDesc')}
          </p>
        </div>
      </div>

      {/* App Version & Reset */}
      <div className="flex items-center justify-between text-xs text-slate-400 px-2 pt-2">
        <span>Smart Daily Utility Pro · v1.0.0</span>
        <button
          onClick={handleResetData}
          className="hover:text-rose-500 flex items-center gap-1 transition"
        >
          <RotateCcw className="w-3 h-3" />
          <span>Reset Cache</span>
        </button>
      </div>
    </div>
  );
};
