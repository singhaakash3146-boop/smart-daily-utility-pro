import React from 'react';
import { useApp } from '../../context/AppContext';
import { ExternalLink, Sparkles } from 'lucide-react';

export const AdMobNative: React.FC = () => {
  const { isPremium, setShowPremiumModal, setShowAdmobInfoModal, language } = useApp();

  if (isPremium) return null;

  return (
    <div className="my-4 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-gradient-to-br from-slate-50 to-blue-50/40 dark:from-slate-900 dark:to-blue-950/20 shadow-sm transition-all">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          <span className="text-[10px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300 border border-amber-300/50">
            {language === 'hi' ? 'विज्ञापन' : 'Ad'}
          </span>
          <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">
            Native Ad Placement Preview
          </span>
        </div>
        <button
          onClick={() => setShowAdmobInfoModal(true)}
          className="text-xs text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
          title="AdChoices Info"
        >
          <ExternalLink className="w-3.5 h-3.5" />
        </button>
      </div>

      <div className="flex items-start gap-3">
        <div className="w-12 h-12 rounded-xl bg-blue-600 text-white flex items-center justify-center font-bold text-lg shadow-md shrink-0">
          PRO
        </div>
        <div className="flex-1 min-w-0">
          <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100 truncate">
            {language === 'hi' ? 'स्मार्ट डेली यूटिलिटी प्रो अनलॉक करें' : 'Unlock Smart Daily Utility Pro'}
          </h4>
          <p className="text-xs text-slate-600 dark:text-slate-400 line-clamp-2 mt-0.5">
            {language === 'hi'
              ? 'विज्ञापन मुक्त उपयोग, असीमित हाई-क्वालिटी पीडीएफ व इमेज टूल्स पाएं।'
              : 'Enjoy zero advertisements, unlimited batch tools, and offline high-res utilities.'}
          </p>
        </div>
      </div>

      <div className="mt-3 flex items-center justify-between pt-2 border-t border-slate-200/60 dark:border-slate-800/80">
        <span className="text-[11px] text-slate-500 dark:text-slate-400">
          {language === 'hi' ? 'विज्ञापन प्लेसमेंट का डेमो' : 'Ad placement demo — SDK not connected'}
        </span>
        <button
          onClick={() => setShowPremiumModal(true)}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold shadow-sm transition-all"
        >
          <Sparkles className="w-3 h-3" />
          {language === 'hi' ? 'प्रो देखें' : 'Learn More'}
        </button>
      </div>
    </div>
  );
};
