import React from 'react';
import { useApp } from '../../context/AppContext';
import { X, ShieldCheck, Copy, Check, Terminal, ExternalLink, AlertCircle } from 'lucide-react';

export const AdMobInfoModal: React.FC = () => {
  const { showAdmobInfoModal, setShowAdmobInfoModal, language } = useApp();
  const [copiedKey, setCopiedKey] = React.useState<string | null>(null);

  if (!showAdmobInfoModal) return null;

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const adUnits = [
    {
      format: 'App ID (Sample)',
      id: 'ca-app-pub-3940256099942544~3347511713',
      desc: 'Configured in AndroidManifest.xml <meta-data>',
    },
    {
      format: 'Banner Ad (Adaptive 320x50)',
      id: 'ca-app-pub-3940256099942544/6300978111',
      desc: 'Shown at bottom of home & utilities',
    },
    {
      format: 'Native Advanced Ad',
      id: 'ca-app-pub-3940256099942544/2247690483',
      desc: 'Seamlessly embedded between tool suites',
    },
    {
      format: 'Rewarded Video Ad',
      id: 'ca-app-pub-3940256099942544/5224354917',
      desc: 'Unlocks 24 hours of free Pro access',
    },
    {
      format: 'Interstitial Ad',
      id: 'ca-app-pub-3940256099942544/1033173712',
      desc: 'Between heavy PDF/image batch exports',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
      <div className="relative w-full max-w-lg max-h-[90vh] overflow-y-auto rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl p-6 text-slate-900 dark:text-slate-100">
        <button
          onClick={() => setShowAdmobInfoModal(false)}
          className="absolute top-4 right-4 p-2 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-blue-100 dark:bg-blue-950 text-blue-600 dark:text-blue-400 flex items-center justify-center font-bold">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-lg font-bold">AdMob Setup Status</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Configuration references — SDK not connected
            </p>
          </div>
        </div>

        <div className="p-3.5 mb-4 rounded-xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900/60 text-xs text-blue-900 dark:text-blue-200 flex gap-2.5">
          <AlertCircle className="w-4 h-4 shrink-0 text-blue-600 dark:text-blue-400 mt-0.5" />
          <div>
            <strong>Google Policy Notice:</strong> Important: the current project does not include a working native AdMob SDK integration. The IDs below are reference values only; no real test ads are currently being requested or displayed.
          </div>
        </div>

        <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-2">
          AdMob reference IDs (not active)
        </h4>
        <div className="space-y-2 mb-6">
          {adUnits.map((u, i) => (
            <div
              key={i}
              className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 flex items-center justify-between gap-2"
            >
              <div className="min-w-0">
                <span className="text-xs font-semibold text-slate-900 dark:text-slate-100">
                  {u.format}
                </span>
                <p className="text-[11px] font-mono text-slate-500 dark:text-slate-400 truncate">
                  {u.id}
                </p>
                <span className="text-[10px] text-slate-600 dark:text-slate-300">
                  {u.desc}
                </span>
              </div>
              <button
                onClick={() => copyToClipboard(u.id, u.id)}
                className="shrink-0 p-2 rounded-lg bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 hover:bg-slate-100 dark:hover:bg-slate-600 text-slate-600 dark:text-slate-200 text-xs transition"
                title="Copy ID"
              >
                {copiedKey === u.id ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
            </div>
          ))}
        </div>

        <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-2">
          How to Deploy to Google Play with Live Ads
        </h4>
        <div className="space-y-2 text-xs text-slate-600 dark:text-slate-300">
          <p>
            1. Create an account at <strong>apps.admob.com</strong> and click <strong>Add App</strong> (Android).
          </p>
          <p>
            2. Create your live Banner, Native, and Rewarded Ad Units.
          </p>
          <p>
            3. Replace the test unit IDs in the Android project's strings/config.
          </p>
          <p>
            4. In `AndroidManifest.xml`, replace the test App ID with your real AdMob App ID.
          </p>
        </div>

        <button
          onClick={() => setShowAdmobInfoModal(false)}
          className="mt-6 w-full py-2.5 rounded-xl bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 font-semibold text-xs transition"
        >
          {language === 'hi' ? 'समझ गया' : 'Got it'}
        </button>
      </div>
    </div>
  );
};
