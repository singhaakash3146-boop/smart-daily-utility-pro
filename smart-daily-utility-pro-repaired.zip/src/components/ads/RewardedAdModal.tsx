import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { X, Play, CheckCircle2, ShieldCheck, Sparkles, Volume2 } from 'lucide-react';

export const RewardedAdModal: React.FC = () => {
  const { showRewardedAdModal, setShowRewardedAdModal, language } = useApp();
  const [countdown, setCountdown] = useState(5);
  const [isCompleted, setIsCompleted] = useState(false);

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (showRewardedAdModal) {
      setCountdown(5);
      setIsCompleted(false);

      timer = setInterval(() => {
        setCountdown(prev => {
          if (prev <= 1) {
            clearInterval(timer);
            setIsCompleted(true);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [showRewardedAdModal]);

  if (!showRewardedAdModal) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-sm overflow-hidden rounded-3xl bg-slate-900 border border-slate-800 text-white shadow-2xl">
        {/* Top Header */}
        <div className="flex items-center justify-between px-4 py-3 bg-slate-950/80 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded bg-amber-500 text-black">
              Ad
            </span>
            <span className="text-xs font-mono text-slate-300">
              Rewarded Ad Preview (not connected)
            </span>
          </div>
          {isCompleted ? (
            <button
              onClick={() => setShowRewardedAdModal(false)}
              className="p-1 rounded-full text-slate-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          ) : (
            <div className="flex items-center gap-1.5 text-xs font-mono text-amber-400 bg-amber-950/60 px-2 py-0.5 rounded-full border border-amber-800/40">
              <span>Reward in</span>
              <span className="font-bold">{countdown}s</span>
            </div>
          )}
        </div>

        {/* UI preview only: no real AdMob SDK is connected in this web build. */}
        <div className="relative aspect-video w-full bg-slate-950 flex flex-col items-center justify-center p-6 text-center overflow-hidden">
          {/* Animated Background Pulse */}
          <div className="absolute inset-0 bg-radial from-blue-900/40 via-transparent to-transparent animate-pulse" />

          {isCompleted ? (
            <div className="relative z-10 flex flex-col items-center animate-in zoom-in-90 duration-300">
              <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center justify-center mb-3">
                <CheckCircle2 className="w-9 h-9" />
              </div>
              <h3 className="text-base font-bold text-white">
                {language === 'hi' ? 'डेमो पूरा हुआ' : 'Preview Complete'}
              </h3>
              <p className="text-xs text-slate-300 mt-1 max-w-xs">
                {language === 'hi'
                  ? 'यह केवल डेमो है। असली विज्ञापन SDK जुड़ने तक रिवॉर्ड उपलब्ध नहीं है।'
                  : 'This is only a preview. Rewards are disabled until a real ad SDK is integrated.'}
              </p>
            </div>
          ) : (
            <div className="relative z-10 flex flex-col items-center">
              <div className="w-14 h-14 rounded-2xl bg-blue-600 text-white flex items-center justify-center shadow-lg mb-3 animate-bounce">
                <Play className="w-7 h-7 fill-white translate-x-0.5" />
              </div>
              <p className="text-sm font-semibold text-slate-200">
                Rewarded Ad Preview
              </p>
              <p className="text-xs text-slate-400 mt-1">
                This is a visual demo, not a real advertisement.
              </p>
              <div className="mt-4 w-48 h-1.5 bg-slate-800 rounded-full overflow-hidden">
                <div
                  className="h-full bg-blue-500 transition-all duration-1000 ease-linear"
                  style={{ width: `${((5 - countdown) / 5) * 100}%` }}
                />
              </div>
            </div>
          )}

          {/* Sound & Compliance Badges */}
          <div className="absolute bottom-2 left-3 flex items-center gap-1.5 text-[10px] text-slate-500">
            <Volume2 className="w-3 h-3" />
            <span>Demo only</span>
          </div>
          <div className="absolute bottom-2 right-3 text-[10px] text-slate-500">
            Not an actual ad
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-slate-900 border-t border-slate-800 flex items-center justify-end gap-2">
          {isCompleted ? (
            <button
              onClick={() => setShowRewardedAdModal(false)}
              className="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 font-bold text-white text-sm shadow-lg flex items-center justify-center gap-2 transition-all active:scale-[0.98]"
            >
              <Sparkles className="w-4 h-4" />
              {language === 'hi' ? 'डेमो बंद करें' : 'Close Preview'}
            </button>
          ) : (
            <p className="text-center w-full text-xs text-slate-400">
              {language === 'hi'
                ? `रिवॉर्ड पाने के लिए ${countdown} सेकंड प्रतीक्षा करें`
                : `Please watch ${countdown} more seconds to receive reward`}
            </p>
          )}
        </div>
      </div>
    </div>
  );
};
