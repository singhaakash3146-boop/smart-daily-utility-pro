import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Info, X, ExternalLink } from 'lucide-react';

export const AdMobBanner: React.FC<{ inline?: boolean }> = ({ inline = false }) => {
  const { isPremium, setShowPremiumModal, setShowAdmobInfoModal } = useApp();
  const [isDismissed, setIsDismissed] = useState(false);

  if (isPremium || isDismissed) {
    return null;
  }

  return (
    <div
      className={`relative z-20 mx-auto w-full max-w-lg transition-all ${
        inline ? 'my-4' : 'fixed bottom-16 left-0 right-0 px-3 pb-1'
      }`}
    >
      <div className="relative overflow-hidden rounded-xl border border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md shadow-sm p-2 flex items-center justify-between gap-3">
        {/* AdMob Test Tag */}
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="flex flex-col items-center justify-center shrink-0 w-8 h-8 rounded-lg bg-blue-50 dark:bg-blue-950/60 border border-blue-200 dark:border-blue-900 text-blue-600 dark:text-blue-400">
            <span className="text-[9px] font-bold tracking-wider uppercase leading-none">Ad</span>
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-semibold text-slate-800 dark:text-slate-200 truncate">
                Ad Placement Preview
              </span>
              <button
                onClick={() => setShowAdmobInfoModal(true)}
                className="text-[10px] text-slate-600 hover:text-blue-700 dark:text-slate-300 dark:hover:text-blue-300 font-mono"
                title="View AdMob Integration details"
              >
                (ca-app-pub.../6300978111)
              </button>
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
              AdMob is not connected yet. This is a layout preview only.
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-1.5 shrink-0">
          <button
            onClick={() => setShowPremiumModal(true)}
            className="px-2.5 py-1 text-[11px] font-semibold text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950 hover:bg-blue-100 dark:hover:bg-blue-900 rounded-md transition-colors whitespace-nowrap"
          >
            Remove Ads
          </button>
          <button
            onClick={() => setIsDismissed(true)}
            className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded"
            aria-label="Dismiss banner"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
