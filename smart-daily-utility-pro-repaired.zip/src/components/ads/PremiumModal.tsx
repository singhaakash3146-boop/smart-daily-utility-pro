import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { X, Check, Sparkles, Shield, Zap, Video, Star } from 'lucide-react';

export const PremiumModal: React.FC = () => {
  const {
    showPremiumModal,
    setShowPremiumModal,
    isPremium,
    activatePremium,
    setShowRewardedAdModal,
    rewardedExpiry,
    language,
    t,
  } = useApp();

  const [selectedPlan, setSelectedPlan] = useState<'monthly' | 'yearly' | 'lifetime'>('yearly');

  if (!showPremiumModal) return null;

  const plans = [
    {
      id: 'monthly',
      title: language === 'hi' ? 'मासिक पास' : 'Monthly Pass',
      price: language === 'hi' ? '₹49 / माह' : '$0.99 / mo',
      badge: null,
      desc: language === 'hi' ? 'माह दर माह फ्लेक्सिबल प्लान' : 'Flexible month-to-month access',
    },
    {
      id: 'yearly',
      title: language === 'hi' ? 'वार्षिक प्रो' : 'Annual Pro',
      price: language === 'hi' ? '₹299 / वर्ष' : '$3.99 / yr',
      badge: language === 'hi' ? 'लोकप्रिय (60% छूट)' : 'Popular (60% Off)',
      desc: language === 'hi' ? 'केवल ₹25/माह, सबसे किफायती' : 'Just $0.33/mo, best value',
    },
    {
      id: 'lifetime',
      title: language === 'hi' ? 'लाइफटाइम प्रो' : 'Lifetime Access',
      price: language === 'hi' ? '₹699 एक बार' : '$9.99 once',
      badge: language === 'hi' ? 'एक बार भुगतान' : 'Pay Once',
      desc: language === 'hi' ? 'हमेशा के लिए सभी सुविधाएं अनलॉक' : 'Never pay again, lifetime updates',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
      <div className="relative w-full max-w-md max-h-[90vh] overflow-y-auto rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl p-6 text-slate-900 dark:text-slate-100">
        {/* Close Button */}
        <button
          onClick={() => setShowPremiumModal(false)}
          className="absolute top-4 right-4 p-2 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="text-center pt-2 pb-4">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-gradient-to-tr from-amber-500 to-amber-300 text-slate-950 shadow-lg mb-3">
            <Sparkles className="w-8 h-8 fill-slate-950" />
          </div>
          <h3 className="text-xl font-bold tracking-tight">
            Smart Daily Utility <span className="text-amber-500">PRO</span>
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-xs mx-auto">
            {language === 'hi'
              ? 'बिना किसी रुकावट के तेज, विज्ञापन-मुक्त और शक्तिशाली टूल्स का आनंद लें।'
              : 'Supercharge your daily productivity with zero ads and unlocked high-performance tools.'}
          </p>
        </div>

        {/* Feature List */}
        <div className="space-y-2.5 my-4 bg-slate-50 dark:bg-slate-800/60 p-4 rounded-2xl border border-slate-200 dark:border-slate-700/60">
          <div className="flex items-center gap-2.5 text-xs font-medium">
            <div className="w-5 h-5 rounded-full bg-emerald-100 dark:bg-emerald-950/80 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
              <Check className="w-3.5 h-3.5" />
            </div>
            <span>{t('proBenefit1')}</span>
          </div>
          <div className="flex items-center gap-2.5 text-xs font-medium">
            <div className="w-5 h-5 rounded-full bg-emerald-100 dark:bg-emerald-950/80 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
              <Check className="w-3.5 h-3.5" />
            </div>
            <span>{t('proBenefit2')}</span>
          </div>
          <div className="flex items-center gap-2.5 text-xs font-medium">
            <div className="w-5 h-5 rounded-full bg-emerald-100 dark:bg-emerald-950/80 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
              <Check className="w-3.5 h-3.5" />
            </div>
            <span>{t('proBenefit3')}</span>
          </div>
          <div className="flex items-center gap-2.5 text-xs font-medium">
            <div className="w-5 h-5 rounded-full bg-emerald-100 dark:bg-emerald-950/80 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
              <Check className="w-3.5 h-3.5" />
            </div>
            <span>{language === 'hi' ? '100% ऑफलाइन गोपनीयता और डेटा सुरक्षा' : '100% offline security & local storage'}</span>
          </div>
        </div>

        {/* Status if already pro or reward */}
        {isPremium && (
          <div className="mb-4 p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 text-xs flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Star className="w-4 h-4 fill-emerald-500 text-emerald-500" />
              <span className="font-semibold">
                {rewardedExpiry
                  ? `${language === 'hi' ? 'रिवॉर्डेड प्रो सक्रिय' : '24h Rewarded Pro Active'}`
                  : `${language === 'hi' ? 'प्रो लाइफटाइम सक्रिय है' : 'Pro Subscription Active'}`}
              </span>
            </div>
            <span className="text-[11px] font-mono">
              {rewardedExpiry ? `${Math.ceil((rewardedExpiry - Date.now()) / (1000 * 60 * 60))}h left` : 'Active'}
            </span>
          </div>
        )}

        {/* Plan Selectors */}
        <div className="space-y-2.5">
          {plans.map(plan => {
            const isSelected = selectedPlan === plan.id;
            return (
              <div
                key={plan.id}
                onClick={() => setSelectedPlan(plan.id as any)}
                className={`relative cursor-pointer p-3.5 rounded-2xl border transition-all flex items-center justify-between ${
                  isSelected
                    ? 'border-blue-600 dark:border-blue-500 bg-blue-50/60 dark:bg-blue-950/40 ring-2 ring-blue-500/20'
                    : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
                }`}
              >
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-bold text-slate-900 dark:text-slate-100">
                      {plan.title}
                    </span>
                    {plan.badge && (
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300 border border-amber-300/40">
                        {plan.badge}
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                    {plan.desc}
                  </p>
                </div>
                <div className="text-right shrink-0">
                  <span className="text-sm font-bold text-slate-900 dark:text-slate-100">
                    {plan.price}
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Subscribe Action Button */}
        <button
          onClick={() => {
            activatePremium();
            setShowPremiumModal(false);
          }}
          className="mt-5 w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold text-sm shadow-lg shadow-blue-500/20 flex items-center justify-center gap-2 active:scale-[0.98] transition-transform"
        >
          <Zap className="w-4 h-4 fill-white" />
          {t('activatePro')}
        </button>

        {/* Free Alternative: Rewarded Ad */}
        <div className="mt-4 pt-4 border-t border-slate-200 dark:border-slate-800 text-center">
          <p className="text-xs text-slate-500 dark:text-slate-400 mb-2">
            {language === 'hi' ? 'विज्ञापन सुविधा अभी जुड़ी नहीं है।' : 'Ad rewards are not connected yet.'}
          </p>
          <button
            onClick={() => {
              setShowPremiumModal(false);
              setShowRewardedAdModal(true);
            }}
            className="w-full py-2.5 px-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700/80 text-xs font-semibold text-slate-700 dark:text-slate-200 flex items-center justify-center gap-2 transition"
          >
            <Video className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
            {language === 'hi' ? 'विज्ञापन डेमो देखें (रिवॉर्ड नहीं)' : 'Preview ad layout (no reward)'}
          </button>
        </div>

        {/* Google Play Billing Assurance */}
        <div className="mt-4 flex items-center justify-center gap-2 text-[11px] text-slate-400">
          <Shield className="w-3.5 h-3.5" />
          <span>Google Play Billing not connected yet</span>
        </div>
      </div>
    </div>
  );
};
