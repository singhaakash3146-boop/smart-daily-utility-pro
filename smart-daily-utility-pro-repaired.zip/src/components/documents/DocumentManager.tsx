import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { UserDocument } from '../../types';
import {
  FolderArchive,
  Search,
  Upload,
  FileDown,
  Trash2,
  FileText,
  FileImage,
  Files,
  QrCode,
  Eye,
  X,
  Plus,
} from 'lucide-react';

export const DocumentManager: React.FC = () => {
  const { documents, addDocument, removeDocument, t, language, showToast } = useApp();
  const [filterType, setFilterType] = useState<string>('all');
  const [search, setSearch] = useState<string>('');
  const [previewDoc, setPreviewDoc] = useState<UserDocument | null>(null);

  const filteredDocs = documents
    .filter(doc => filterType === 'all' || doc.type === filterType)
    .filter(doc => doc.name.toLowerCase().includes(search.toLowerCase()) || doc.category.toLowerCase().includes(search.toLowerCase()))
    .sort((a, b) => b.createdAt - a.createdAt);

  const handleUploadFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || !e.target.files[0]) return;
    const file = e.target.files[0];
    const reader = new FileReader();

    reader.onload = () => {
      let type: UserDocument['type'] = 'other';
      if (file.type.includes('pdf')) type = 'pdf';
      else if (file.type.startsWith('image/')) type = 'image';

      addDocument({
        name: file.name,
        type,
        size: file.size,
        dataUrl: reader.result as string,
        category: 'Imported',
        tags: [type.toUpperCase(), 'Uploaded'],
      });
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const handleDownload = (doc: UserDocument) => {
    if (!doc.dataUrl) {
      showToast(language === 'hi' ? 'डाउनलोड लिंक अनुपलब्ध' : 'File content not found');
      return;
    }
    const a = document.createElement('a');
    a.href = doc.dataUrl;
    a.download = doc.name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const getDocIcon = (type: string) => {
    switch (type) {
      case 'pdf':
        return <Files className="w-5 h-5 text-rose-500" />;
      case 'image':
        return <FileImage className="w-5 h-5 text-indigo-500" />;
      case 'qr':
        return <QrCode className="w-5 h-5 text-emerald-500" />;
      case 'note':
        return <FileText className="w-5 h-5 text-amber-500" />;
      default:
        return <FolderArchive className="w-5 h-5 text-blue-500" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header & Upload */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">
            {t('catDoc')}
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            {t('tool_doc_manager_desc')}
          </p>
        </div>

        <div className="relative">
          <input
            type="file"
            onChange={handleUploadFile}
            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
          />
          <button className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-sm transition">
            <Plus className="w-4 h-4" />
            <span>Import File</span>
          </button>
        </div>
      </div>

      {/* Search & Filter Strip */}
      <div className="space-y-3">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search documents by name..."
            className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-xs focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
          {[
            { id: 'all', label: 'All Files' },
            { id: 'pdf', label: 'PDFs' },
            { id: 'image', label: 'Images' },
            { id: 'qr', label: 'QR Codes' },
          ].map(f => (
            <button
              key={f.id}
              onClick={() => setFilterType(f.id)}
              className={`px-3 py-1.5 rounded-xl font-semibold transition whitespace-nowrap ${
                filterType === f.id
                  ? 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 shadow-sm'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {/* Documents List */}
      <div className="space-y-2">
        {filteredDocs.length === 0 ? (
          <div className="p-8 text-center rounded-3xl border border-dashed border-slate-300 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-400 space-y-2">
            <FolderArchive className="w-8 h-8 mx-auto text-slate-300 dark:text-slate-700" />
            <p className="text-xs">No documents stored in My Documents yet.</p>
            <p className="text-[11px] text-slate-500">
              Files created using Image to PDF, Merge PDF, Compressor, or QR tools will appear here.
            </p>
          </div>
        ) : (
          filteredDocs.map(doc => (
            <div
              key={doc.id}
              className="p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:bg-slate-50/50 dark:hover:bg-slate-800/50 shadow-sm transition flex items-center justify-between gap-3"
            >
              <div className="flex items-center gap-3 min-w-0">
                <div className="p-2 rounded-xl bg-slate-50 dark:bg-slate-800 shrink-0">
                  {getDocIcon(doc.type)}
                </div>
                <div className="min-w-0">
                  <span className="text-xs font-bold text-slate-900 dark:text-slate-100 truncate block">
                    {doc.name}
                  </span>
                  <div className="flex items-center gap-2 text-[10px] text-slate-400 mt-0.5">
                    <span>{(doc.size / 1024).toFixed(1)} KB</span>
                    <span>·</span>
                    <span>{new Date(doc.createdAt).toLocaleDateString()}</span>
                    <span>·</span>
                    <span className="capitalize">{doc.category}</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-1 shrink-0">
                {doc.dataUrl && (
                  <button
                    onClick={() => setPreviewDoc(doc)}
                    className="p-2 rounded-lg text-slate-500 hover:text-blue-600 hover:bg-slate-100 dark:hover:bg-slate-800"
                    title="Preview"
                  >
                    <Eye className="w-4 h-4" />
                  </button>
                )}
                <button
                  onClick={() => handleDownload(doc)}
                  className="p-2 rounded-lg text-slate-500 hover:text-emerald-600 hover:bg-slate-100 dark:hover:bg-slate-800"
                  title="Download File"
                >
                  <FileDown className="w-4 h-4" />
                </button>
                <button
                  onClick={() => removeDocument(doc.id)}
                  className="p-2 rounded-lg text-slate-400 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950"
                  title="Delete File"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Preview Modal */}
      {previewDoc && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
          <div className="w-full max-w-lg rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-800 dark:text-slate-200 truncate max-w-xs">
                {previewDoc.name}
              </span>
              <button
                onClick={() => setPreviewDoc(null)}
                className="p-1 rounded-full text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="max-h-80 overflow-auto flex items-center justify-center bg-slate-950 rounded-2xl p-4">
              {previewDoc.dataUrl?.startsWith('data:image/') ? (
                <img
                  src={previewDoc.dataUrl}
                  alt={previewDoc.name}
                  className="max-h-72 object-contain rounded-lg"
                />
              ) : previewDoc.dataUrl?.startsWith('data:text/') || previewDoc.type === 'qr' ? (
                <div className="w-full text-left space-y-2">
                  <div className="flex items-center justify-between text-xs text-slate-400">
                    <span className="font-semibold uppercase tracking-wider text-emerald-400">Decoded Text</span>
                    <button
                      onClick={() => {
                        const rawText = previewDoc.dataUrl.startsWith('data:text/')
                          ? decodeURIComponent(previewDoc.dataUrl.split(',')[1] || '')
                          : previewDoc.dataUrl;
                        navigator.clipboard.writeText(rawText);
                        showToast(language === 'hi' ? 'टेक्स्ट कॉपी हो गया' : 'Text copied to clipboard');
                      }}
                      className="text-xs text-blue-400 hover:underline"
                    >
                      Copy Text
                    </button>
                  </div>
                  <pre className="p-3 bg-slate-900 rounded-xl text-xs font-mono text-slate-200 whitespace-pre-wrap break-all max-h-56 overflow-y-auto select-all border border-slate-800">
                    {previewDoc.dataUrl.startsWith('data:text/')
                      ? decodeURIComponent(previewDoc.dataUrl.split(',')[1] || '')
                      : previewDoc.dataUrl}
                  </pre>
                </div>
              ) : (
                <div className="text-center py-12 text-slate-400 text-xs">
                  <Files className="w-12 h-12 mx-auto text-rose-500 mb-2" />
                  <p className="font-semibold text-slate-200">PDF Document</p>
                  <p className="text-[11px] text-slate-500 mt-1">
                    {(previewDoc.size / 1024).toFixed(1)} KB • Ready for download
                  </p>
                </div>
              )}
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
              <button
                onClick={() => setPreviewDoc(null)}
                className="px-3 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100"
              >
                Close
              </button>
              <button
                onClick={() => handleDownload(previewDoc)}
                className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-sm flex items-center gap-1.5"
              >
                <FileDown className="w-4 h-4" />
                <span>Download</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
