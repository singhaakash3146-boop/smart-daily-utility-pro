import React from 'react';
import {
  FileImage,
  Files,
  Scissors,
  Minimize2,
  Shrink,
  Maximize2,
  RefreshCw,
  Crop,
  Calendar,
  Landmark,
  Receipt,
  Tag,
  Percent,
  Calculator,
  ScanLine,
  QrCode,
  FileText,
  Bell,
  Ruler,
  Coins,
  KeyRound,
  FolderArchive,
  LucideIcon,
} from 'lucide-react';

interface ToolIconProps {
  name: string;
  category: string;
  className?: string;
}

const ICON_MAP: Record<string, LucideIcon> = {
  FileImage,
  Files,
  Scissors,
  Minimize2,
  Shrink,
  Maximize2,
  RefreshCw,
  Crop,
  Calendar,
  Landmark,
  Receipt,
  Tag,
  Percent,
  Calculator,
  ScanLine,
  QrCode,
  FileText,
  Bell,
  Ruler,
  Coins,
  KeyRound,
  FolderArchive,
};

export const ToolIcon: React.FC<ToolIconProps> = ({ name, category, className = 'w-5 h-5' }) => {
  const IconComponent = ICON_MAP[name] || Calculator;

  // Domain specific color classes
  const getCategoryStyles = () => {
    switch (category) {
      case 'pdf':
        return 'text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/60 border-rose-200 dark:border-rose-900/60';
      case 'image':
        return 'text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/60 border-indigo-200 dark:border-indigo-900/60';
      case 'calc':
        return 'text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/60 border-blue-200 dark:border-blue-900/60';
      case 'qr':
        return 'text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 border-emerald-200 dark:border-emerald-900/60';
      case 'daily':
        return 'text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/60 border-amber-200 dark:border-amber-900/60';
      case 'doc':
        return 'text-teal-600 dark:text-teal-400 bg-teal-50 dark:bg-teal-950/60 border-teal-200 dark:border-teal-900/60';
      default:
        return 'text-slate-600 dark:text-slate-400 bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700';
    }
  };

  return (
    <div
      className={`flex items-center justify-center rounded-xl border p-2 shrink-0 transition-transform ${getCategoryStyles()}`}
    >
      <IconComponent className={className} />
    </div>
  );
};
