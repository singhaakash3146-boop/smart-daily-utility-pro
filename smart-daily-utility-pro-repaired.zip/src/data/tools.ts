import { ToolDefinition } from '../types';

export const ALL_TOOLS: ToolDefinition[] = [
  // PDF Tools
  {
    id: 'image_to_pdf',
    titleKey: 'tool_image_to_pdf',
    descKey: 'tool_image_to_pdf_desc',
    category: 'pdf',
    iconName: 'FileImage',
  },
  {
    id: 'merge_pdf',
    titleKey: 'tool_merge_pdf',
    descKey: 'tool_merge_pdf_desc',
    category: 'pdf',
    iconName: 'Files',
  },
  {
    id: 'split_pdf',
    titleKey: 'tool_split_pdf',
    descKey: 'tool_split_pdf_desc',
    category: 'pdf',
    iconName: 'Scissors',
  },
  {
    id: 'compress_pdf',
    titleKey: 'tool_compress_pdf',
    descKey: 'tool_compress_pdf_desc',
    category: 'pdf',
    iconName: 'Minimize2',
  },

  // Image Tools
  {
    id: 'img_compressor',
    titleKey: 'tool_img_compressor',
    descKey: 'tool_img_compressor_desc',
    category: 'image',
    iconName: 'Shrink',
  },
  {
    id: 'img_resizer',
    titleKey: 'tool_img_resizer',
    descKey: 'tool_img_resizer_desc',
    category: 'image',
    iconName: 'Maximize2',
  },
  {
    id: 'img_converter',
    titleKey: 'tool_img_converter',
    descKey: 'tool_img_converter_desc',
    category: 'image',
    iconName: 'RefreshCw',
  },
  {
    id: 'img_cropper',
    titleKey: 'tool_img_cropper',
    descKey: 'tool_img_cropper_desc',
    category: 'image',
    iconName: 'Crop',
  },

  // Calculators
  {
    id: 'age_calc',
    titleKey: 'tool_age_calc',
    descKey: 'tool_age_calc_desc',
    category: 'calc',
    iconName: 'Calendar',
  },
  {
    id: 'emi_calc',
    titleKey: 'tool_emi_calc',
    descKey: 'tool_emi_calc_desc',
    category: 'calc',
    iconName: 'Landmark',
  },
  {
    id: 'gst_calc',
    titleKey: 'tool_gst_calc',
    descKey: 'tool_gst_calc_desc',
    category: 'calc',
    iconName: 'Receipt',
  },
  {
    id: 'discount_calc',
    titleKey: 'tool_discount_calc',
    descKey: 'tool_discount_calc_desc',
    category: 'calc',
    iconName: 'Tag',
  },
  {
    id: 'percentage_calc',
    titleKey: 'tool_percentage_calc',
    descKey: 'tool_percentage_calc_desc',
    category: 'calc',
    iconName: 'Percent',
  },
  {
    id: 'scientific_calc',
    titleKey: 'tool_scientific_calc',
    descKey: 'tool_scientific_calc_desc',
    category: 'calc',
    iconName: 'Calculator',
  },

  // QR Tools
  {
    id: 'qr_scanner',
    titleKey: 'tool_qr_scanner',
    descKey: 'tool_qr_scanner_desc',
    category: 'qr',
    iconName: 'ScanLine',
  },
  {
    id: 'qr_generator',
    titleKey: 'tool_qr_generator',
    descKey: 'tool_qr_generator_desc',
    category: 'qr',
    iconName: 'QrCode',
  },

  // Daily Tools
  {
    id: 'notes',
    titleKey: 'tool_notes',
    descKey: 'tool_notes_desc',
    category: 'daily',
    iconName: 'FileText',
  },
  {
    id: 'reminders',
    titleKey: 'tool_reminders',
    descKey: 'tool_reminders_desc',
    category: 'daily',
    iconName: 'Bell',
  },
  {
    id: 'unit_converter',
    titleKey: 'tool_unit_converter',
    descKey: 'tool_unit_converter_desc',
    category: 'daily',
    iconName: 'Ruler',
  },
  {
    id: 'currency_converter',
    titleKey: 'tool_currency_converter',
    descKey: 'tool_currency_converter_desc',
    category: 'daily',
    iconName: 'Coins',
  },
  {
    id: 'password_gen',
    titleKey: 'tool_password_gen',
    descKey: 'tool_password_gen_desc',
    category: 'daily',
    iconName: 'KeyRound',
  },
  {
    id: 'doc_manager',
    titleKey: 'tool_doc_manager',
    descKey: 'tool_doc_manager_desc',
    category: 'doc',
    iconName: 'FolderArchive',
  },
];
