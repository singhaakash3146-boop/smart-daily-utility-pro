import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { Language, Theme, UserDocument, NoteItem, ReminderItem, SaveNoteInput, SaveReminderInput } from '../types';
import { translations } from '../i18n/translations';

interface AppContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: keyof typeof translations.en | string) => string;
  theme: Theme;
  toggleTheme: () => void;
  activeTab: 'home' | 'tools' | 'docs' | 'settings';
  setActiveTab: (tab: 'home' | 'tools' | 'docs' | 'settings') => void;
  activeToolId: string | null;
  openTool: (toolId: string) => void;
  closeTool: () => void;
  favorites: string[];
  toggleFavorite: (toolId: string) => void;
  isFavorite: (toolId: string) => boolean;
  recentlyUsed: string[];
  documents: UserDocument[];
  addDocument: (doc: Omit<UserDocument, 'id' | 'createdAt'>) => void;
  removeDocument: (id: string) => void;
  notes: NoteItem[];
  saveNote: (note: SaveNoteInput) => void;
  deleteNote: (id: string) => void;
  reminders: ReminderItem[];
  saveReminder: (reminder: SaveReminderInput) => void;
  toggleReminder: (id: string) => void;
  deleteReminder: (id: string) => void;
  isPremium: boolean;
  activatePremium: () => void;
  rewardedExpiry: number | null;
  grantRewardedAccess: () => void;
  showPremiumModal: boolean;
  setShowPremiumModal: (show: boolean) => void;
  showRewardedAdModal: boolean;
  setShowRewardedAdModal: (show: boolean) => void;
  showApkModal: boolean;
  setShowApkModal: (show: boolean) => void;
  showAdmobInfoModal: boolean;
  setShowAdmobInfoModal: (show: boolean) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  toast: string | null;
  showToast: (msg: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const STORAGE_KEYS = {
  LANG: 'sdu_lang',
  THEME: 'sdu_theme',
  FAVORITES: 'sdu_favs',
  RECENT: 'sdu_recent',
  DOCUMENTS: 'sdu_docs',
  NOTES: 'sdu_notes',
  REMINDERS: 'sdu_reminders',
  PREMIUM: 'sdu_is_pro',
  REWARD_EXPIRY: 'sdu_reward_expiry',
};

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Language
  const [language, setLanguageState] = useState<Language>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.LANG);
    return (saved === 'hi' || saved === 'en') ? saved : 'en';
  });

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    localStorage.setItem(STORAGE_KEYS.LANG, lang);
  };

  const t = useCallback((key: keyof typeof translations.en | string): string => {
    const langDict = translations[language] || translations.en;
    // @ts-expect-error fallback lookup
    return langDict[key] || translations.en[key as keyof typeof translations.en] || key;
  }, [language]);

  // Theme
  const [theme, setThemeState] = useState<Theme>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.THEME);
    if (saved === 'dark' || saved === 'light') return saved;
    return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  });

  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    localStorage.setItem(STORAGE_KEYS.THEME, theme);
  }, [theme]);

  const toggleTheme = () => {
    setThemeState(prev => (prev === 'dark' ? 'light' : 'dark'));
  };

  // Navigation
  const [activeTab, setActiveTab] = useState<'home' | 'tools' | 'docs' | 'settings'>('home');
  const [activeToolId, setActiveToolId] = useState<string | null>(null);

  // Favorites
  const [favorites, setFavorites] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.FAVORITES);
      return saved ? JSON.parse(saved) : ['image_to_pdf', 'img_compressor', 'age_calc', 'qr_scanner'];
    } catch {
      return ['image_to_pdf', 'img_compressor', 'age_calc', 'qr_scanner'];
    }
  });

  const toggleFavorite = (toolId: string) => {
    setFavorites(prev => {
      const updated = prev.includes(toolId) ? prev.filter(id => id !== toolId) : [...prev, toolId];
      localStorage.setItem(STORAGE_KEYS.FAVORITES, JSON.stringify(updated));
      return updated;
    });
  };

  const isFavorite = (toolId: string) => favorites.includes(toolId);

  // Recently Used Tools
  const [recentlyUsed, setRecentlyUsed] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.RECENT);
      return saved ? JSON.parse(saved) : ['image_to_pdf', 'emi_calc', 'qr_generator'];
    } catch {
      return ['image_to_pdf', 'emi_calc', 'qr_generator'];
    }
  });

  const openTool = (toolId: string) => {
    setActiveToolId(toolId);
    setRecentlyUsed(prev => {
      const filtered = prev.filter(id => id !== toolId);
      const updated = [toolId, ...filtered].slice(0, 8);
      localStorage.setItem(STORAGE_KEYS.RECENT, JSON.stringify(updated));
      return updated;
    });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const closeTool = () => {
    setActiveToolId(null);
  };

  // Documents Local Vault
  const [documents, setDocuments] = useState<UserDocument[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.DOCUMENTS);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const addDocument = (doc: Omit<UserDocument, 'id' | 'createdAt'>) => {
    const newDoc: UserDocument = {
      ...doc,
      id: 'doc_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      createdAt: Date.now(),
    };
    setDocuments(prev => {
      const updated = [newDoc, ...prev];
      localStorage.setItem(STORAGE_KEYS.DOCUMENTS, JSON.stringify(updated));
      return updated;
    });
    showToast(t('savedSuccess'));
  };

  const removeDocument = (id: string) => {
    setDocuments(prev => {
      const updated = prev.filter(d => d.id !== id);
      localStorage.setItem(STORAGE_KEYS.DOCUMENTS, JSON.stringify(updated));
      return updated;
    });
    showToast(language === 'hi' ? 'दस्तावेज़ हटा दिया गया' : 'Document deleted');
  };

  // Notes
  const [notes, setNotes] = useState<NoteItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.NOTES);
      if (saved) return JSON.parse(saved);
      return [
        {
          id: 'note_demo_1',
          title: 'Welcome to Daily Utility Pro! 🎉',
          content: 'Here you can save quick tasks, passwords, project ideas, and grocery items safely on your phone.',
          color: 'blue',
          pinned: true,
          updatedAt: Date.now(),
        },
      ];
    } catch {
      return [];
    }
  });

  const saveNote = (note: SaveNoteInput) => {
    const now = Date.now();
    setNotes(prev => {
      let updated: NoteItem[];
      if (note.id) {
        updated = prev.map(n => n.id === note.id ? { ...n, ...note, updatedAt: now } : n);
      } else {
        const newNote: NoteItem = {
          title: note.title,
          content: note.content,
          color: note.color,
          pinned: note.pinned,
          id: 'note_' + now,
          updatedAt: now,
        };
        updated = [newNote, ...prev];
      }
      localStorage.setItem(STORAGE_KEYS.NOTES, JSON.stringify(updated));
      return updated;
    });
    showToast(language === 'hi' ? 'नोट सहेज लिया गया' : 'Note saved');
  };

  const deleteNote = (id: string) => {
    setNotes(prev => {
      const updated = prev.filter(n => n.id !== id);
      localStorage.setItem(STORAGE_KEYS.NOTES, JSON.stringify(updated));
      return updated;
    });
  };

  // Reminders
  const [reminders, setReminders] = useState<ReminderItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.REMINDERS);
      if (saved) return JSON.parse(saved);
      return [
        {
          id: 'rem_demo_1',
          title: 'Review monthly utility bills',
          time: '18:00',
          date: new Date().toISOString().split('T')[0],
          category: 'bills',
          repeat: 'weekly',
          completed: false,
          createdAt: Date.now(),
        },
      ];
    } catch {
      return [];
    }
  });

  const saveReminder = (reminder: SaveReminderInput) => {
    const now = Date.now();
    setReminders(prev => {
      let updated: ReminderItem[];
      if (reminder.id) {
        updated = prev.map(r => r.id === reminder.id ? { ...r, ...reminder } : r);
      } else {
        const newReminder: ReminderItem = {
          title: reminder.title,
          notes: reminder.notes,
          time: reminder.time,
          date: reminder.date,
          category: reminder.category,
          repeat: reminder.repeat,
          completed: reminder.completed,
          id: 'rem_' + now,
          createdAt: now,
        };
        updated = [newReminder, ...prev];
      }
      localStorage.setItem(STORAGE_KEYS.REMINDERS, JSON.stringify(updated));
      return updated;
    });
    showToast(language === 'hi' ? 'रिमाइंडर सेट किया गया' : 'Reminder created');
  };

  const toggleReminder = (id: string) => {
    setReminders(prev => {
      const updated = prev.map(r => r.id === id ? { ...r, completed: !r.completed } : r);
      localStorage.setItem(STORAGE_KEYS.REMINDERS, JSON.stringify(updated));
      return updated;
    });
  };

  const deleteReminder = (id: string) => {
    setReminders(prev => {
      const updated = prev.filter(r => r.id !== id);
      localStorage.setItem(STORAGE_KEYS.REMINDERS, JSON.stringify(updated));
      return updated;
    });
  };

  // Monetization & Pro State
  const [isProSubscriber, setIsProSubscriber] = useState<boolean>(() => {
    return localStorage.getItem(STORAGE_KEYS.PREMIUM) === 'true';
  });

  const [rewardedExpiry, setRewardedExpiry] = useState<number | null>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.REWARD_EXPIRY);
    if (!saved) return null;
    const time = parseInt(saved, 10);
    return time > Date.now() ? time : null;
  });

  const isPremium = isProSubscriber || (rewardedExpiry !== null && rewardedExpiry > Date.now());

  const activatePremium = () => {
    setIsProSubscriber(true);
    localStorage.setItem(STORAGE_KEYS.PREMIUM, 'true');
    showToast(language === 'hi' ? 'स्मार्ट यूटिलिटी प्रो सक्रिय!' : 'Smart Daily Utility Pro Activated!');
  };

  const grantRewardedAccess = () => {
    const expiry = Date.now() + 24 * 60 * 60 * 1000; // 24 hours
    setRewardedExpiry(expiry);
    localStorage.setItem(STORAGE_KEYS.REWARD_EXPIRY, expiry.toString());
    showToast(t('rewardClaimed'));
  };

  // Modals
  const [showPremiumModal, setShowPremiumModal] = useState(false);
  const [showRewardedAdModal, setShowRewardedAdModal] = useState(false);
  const [showApkModal, setShowApkModal] = useState(false);
  const [showAdmobInfoModal, setShowAdmobInfoModal] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Toast Notification
  const [toast, setToast] = useState<string | null>(null);
  const showToast = useCallback((msg: string) => {
    setToast(msg);
    setTimeout(() => {
      setToast(prev => (prev === msg ? null : prev));
    }, 2800);
  }, []);

  return (
    <AppContext.Provider
      value={{
        language,
        setLanguage,
        t,
        theme,
        toggleTheme,
        activeTab,
        setActiveTab,
        activeToolId,
        openTool,
        closeTool,
        favorites,
        toggleFavorite,
        isFavorite,
        recentlyUsed,
        documents,
        addDocument,
        removeDocument,
        notes,
        saveNote,
        deleteNote,
        reminders,
        saveReminder,
        toggleReminder,
        deleteReminder,
        isPremium,
        activatePremium,
        rewardedExpiry,
        grantRewardedAccess,
        showPremiumModal,
        setShowPremiumModal,
        showRewardedAdModal,
        setShowRewardedAdModal,
        showApkModal,
        setShowApkModal,
        showAdmobInfoModal,
        setShowAdmobInfoModal,
        searchQuery,
        setSearchQuery,
        toast,
        showToast,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
